# Wickhold brand materials

This folder holds the material for Wickhold, a fictional company made up for this assignment. It is not a real business, so there is nothing to look up.

- `brand/`: the company's documents
- `images/`: the image library, with `metadata.json` describing each file
- `briefs/`: three campaign briefs
