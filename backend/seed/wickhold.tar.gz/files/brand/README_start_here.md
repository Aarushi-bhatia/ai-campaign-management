# Brand folder: start here

last edit Nov 2025, Noor

Welcome to Wickhold marketing. Anything that leaves the building (posts, emails, decks, booth graphics) should start from what's in this folder, so please read this before you ask for a logo.

**Current guidelines: `guidelines/Brand_Guidelines_v3_FINAL.md`.** It's the 2024 version and the one to follow. Logo, colors, fonts, company story and how we describe ourselves are all in there. Plan on your first morning for it.

After that:

- Product info: we sell Quenchline and Tallowatch. Overviews and release notes sit in `products/`.
- Boilerplate and messaging: `messaging/`.
- If you're writing a claim about security or compliance, check `legal/` first and ask if it isn't there.
- `archive/` has old blogs, emails and landing pages. Handy for seeing how something was done before, and the fastest way to learn what we sound like.

Logos and photos are shared from the design drive. Ask in #marketing-design and someone will send you the link.

Questions: noor@wickhold.example

TODO: voice doc is still being written, add it here when it lands
