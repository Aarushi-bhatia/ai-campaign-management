---
title: "The Wickhold Field Report 2023 Is Here!"
author: Wickhold Security Team
date: 2023-04-18
category: Reports
---

# The Wickhold Field Report 2023 Is Here!

The wait is over! Today we are thrilled to release the Wickhold Field Report 2023, our annual, deep-dive look at what is really happening inside production Kubernetes environments. If you run containers at any scale, this is the one report you can't afford to skip.

Attackers aren't waiting for your next sprint planning session. Every minute a risky container runs unwatched is a minute they can use against you. Our researchers spent months talking to the teams on the front lines, and the headline finding should make every security leader sit up:

**68% of runtime incidents began with a misconfigured workload.**

Read that again. Before anyone wrote a clever exploit, somebody shipped a container running as root, a service account with cluster-admin, or a hostPath mount nobody remembered approving. The call was coming from inside the house!

## Three takeaways from this year's report

**1. Misconfiguration is the new perimeter.** With 68% of runtime incidents began with a misconfigured workload, config review can no longer be a once-a-quarter activity. It has to run all the time.

**2. Visibility gaps are everywhere.** Most teams we spoke with could not say with confidence what was running in their clusters last Tuesday, much less right now. Spreadsheets and quarterly audits will not save you.

**3. Security and platform teams still speak different languages.** Security teams file tickets. Platform teams close them without reading them. Everyone is frustrated, and the attacker doesn't care.

## Why we run this research

Maren Tolliver, our CEO and co-founder, puts it this way: "Dov and I spent years on call before we started this company, and the thing that always surprised us was how ordinary the root cause turned out to be. We wanted hard data on that, so teams could stop chasing movie-plot attacks and fix what's really hurting them."

We publish the Field Report every year, and it keeps getting bigger. We spoke with platform engineers, security leaders and SREs at companies of every size, from startups with a single cluster to global enterprises with hundreds. We asked what broke, how they found out, and what they wish they had done differently. Many of the answers were painful to read!

## The top misconfigurations we saw

Wondering what's hiding in your own environment? These are the mistakes that came up again and again:

- Containers running as root for no good reason
- Service accounts with far more permissions than the workload needs
- Dashboards and debug endpoints exposed to the internet
- Secrets sitting in plain text environment variables
- Missing resource limits, which let one noisy pod take down its neighbors
- Clusters with no network policies whatsoever

Any one of these can be the first domino. Most clusters we looked at had more than one.

## How Wickhold Security can help

That's why we built a platform that offers a single pane of glass across your clusters and clouds:

- **Wickhold Tallowatch** continuously scans cloud accounts and clusters for risky configuration, so you catch the mistake before an attacker does.
- **Wickhold Quenchline** uses a lightweight eBPF agent to watch every process, every connection, and every file in real time, and stops threats in their tracks.

Together they give you seamless, end-to-end protection from build to runtime, without slowing your developers down. It's next-gen security for the way modern teams actually ship software.

## Get your copy today

The full report includes more charts, more analysis, and a checklist your team can start using this week. Don't wait until your cluster makes the news!

[Click here to download the Wickhold Field Report 2023](https://wickhold.example/field-report-2023)

Want to see how your environment measures up? Our team would love to show you a demo. Reach out to hello@wickhold.example and mention this post, and we'll run a free Tallowatch assessment on one of your clusters. Spots are limited, so act fast!

*Every workload. Always watched.*
