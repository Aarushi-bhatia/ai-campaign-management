---
title: Tallowatch is now Wickhold Evenburn
date: 2026-03-02
author: Wickhold product team
---

# Tallowatch is now Wickhold Evenburn

As of today, Wickhold Tallowatch has a new name: Wickhold Evenburn. It's the same cloud and cluster posture management product you already use, with a name that fits what it does.

## Why rename it

"Tallowatch" was all about watching. Customers kept telling us that watching wasn't the problem. Their queues were full of things they had already seen. What they wanted was help deciding what to fix first and an honest picture of how a mistake could actually be reached from outside.

An even burn is what you want from a candle: steady, predictable, nothing flaring up. That's the goal for your clusters.

## What Evenburn does

The core concepts are the ones you know, with clearer names in the console:

- **Drift:** when a running cluster or cloud account no longer matches what you declared.
- **Exposure path:** the route by which a misconfiguration could actually be reached, step by step, from the outside to something that matters.
- **Fix order:** a ranked list of what to do first, based on which fixes close the most exposure paths.

We keep coming back to the same finding, because it keeps being true: 68% of runtime incidents began with a misconfigured workload. Long lists of findings don't help with that. A short list in the right order does.

## What you need to do

Nothing. There's no agent upgrade and no change to your integrations. Specifically:

- Your existing Tallowatch policies, exceptions and reports carry over as they are.
- The console will show the Evenburn name from today. A few help articles and PDF exports will say Tallowatch for a while as we work through them.
- Your contract and your pricing don't change as a result of the rename. Pricing questions go to your account team.
- API paths stay as they are for now. We will give plenty of notice before anything moves.

## A quick example

Say a team has a public load balancer, a pod running as root behind it, and a service account that can read secrets across the cluster. The old findings list showed those as three separate items in three separate sections. Evenburn draws them as one exposure path and puts the service account change at the top of the fix order, because that one change closes the path fastest.

## Frequently asked questions

**Will my reports still say Tallowatch?** Scheduled reports switch to the new name on their next run. Reports you already saved keep the old name. If an auditor asks, the release notes record the date of the change.

**Does this change what the product scans?** No. Evenburn covers the same cloud accounts and clusters as before, with the same checks.

**Do I need to update my infrastructure code or Helm values?** No. Resource names, chart names and agent labels stay as they are for now.

**What about my training materials?** Replace the name when it suits you. We'd suggest writing "Wickhold Evenburn (formerly Tallowatch)" for the next few months, so nobody thinks you've bought a new tool.

**Why not just keep the old name?** We tried. Over the past year the word "watch" kept pulling our messaging back toward alerts and dashboards, and the product had moved on from that. The rebrand was the right moment to fix it.

## What's next

Wickhold Security has always believed posture and runtime belong together, and this year we'll bring Evenburn and Wickhold Quenchline closer. When Quenchline contains something in a cluster, Evenburn should be able to show the exposure path that led there, so the fix doesn't get lost after the incident review. We'll share more at Slow Burn Summit in Denver this September.

We're very excited about this next chapter for the product!

Questions? Talk to your account team or write to hello@wickhold.example.

*Wickhold Security keeps every workload watched. Our platform gives over 80+ teams continuous visibility into cloud and Kubernetes risk. Founded in 2019, Wickhold Security is headquartered in Denver.*
