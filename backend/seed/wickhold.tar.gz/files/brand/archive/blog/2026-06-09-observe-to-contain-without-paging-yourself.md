# Moving a namespace from observe to contain without paging yourself

Dov Achterberg, June 9, 2026

Across the 412 platform and security leaders we surveyed this year, the median time to contain a runtime incident is 7.4 hours [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]. A good share of that is humans deciding whether they are allowed to press the button. Contain mode exists so the decision is made once, on a Tuesday afternoon, by people who have slept.

Teams still leave Wickhold Quenchline in observe mode for months. They are not lazy. They have seen an automated control take down a healthy service once, and once is plenty. This post is how to roll out contain mode one namespace at a time, and how each containment action fails, since the failure modes are what actually keep people in observe mode.

## Before you touch anything

Pick one namespace. Choose something that matters a little: a stateless API with more than one replica and a PodDisruptionBudget. Your batch system with a weekend-only owner is a bad first choice, and so is the payments database.

Then check three things.

```bash
# every workload has an owner
kubectl get deploy -n checkout -L team,tier

# see what the liveness probes actually do
kubectl get deploy -n checkout -o yaml | grep -A4 livenessProbe

# budgets exist and are not set to zero disruptions
kubectl get pdb -n checkout
```

If the first command shows blanks, stop and fix that. A containment action on a workload with no owner produces a page nobody can answer.

## Read the decision records

In observe mode, Quenchline writes a decision record for what it would have done. Most teams need two to four weeks of these. Pull them for the namespace and go through them by hand.

```bash
kubectl get containmentdecisions -n checkout \
  --sort-by=.metadata.creationTimestamp
```

You are sorting them into three piles:

- Real problems. Rare, and congratulations.
- Legitimate behavior that looks strange. A migration job that shells out, a sidecar that writes to `/tmp` and runs what it wrote, a debug container someone attached during an outage.
- Things nobody can explain. Treat these as the first pile until someone can.

The second pile becomes exemptions with an `until` date. The field is mandatory because a permanent exemption is a hole with a nice comment on it.

## Turn on one action at a time

Mode is set per policy, so write a policy for this namespace and leave the default containment policy in observe mode everywhere else. Start with one rule and one action.

```yaml
apiVersion: quenchline.wickhold.example/v1
kind: ContainmentPolicy
metadata:
  name: checkout-api
  namespace: checkout
spec:
  mode: contain
  selector:
    matchLabels:
      app: checkout-api
  rules:
    - detection: egress-to-new-destination
      action: isolateNetwork
      keepDNS: true
```

Run a week on each step, adding the next action only when the last one has been dull. Here is how each action can hurt you.

### Isolate a pod's network

This is the safest action and the one to start with. The failure mode is your own liveness probe. If the probe handler calls a downstream dependency, an isolated pod fails it, the kubelet restarts the container, and the evidence goes with it. Keep liveness checks local to the pod. Pods with `hostNetwork: true` cannot be isolated at all: the action is refused and the decision record says so, which is a poor thing to learn at 3am.

Second failure: a Service still routes to the isolated pod until readiness fails. For a few seconds some requests go nowhere. A multi-replica deployment absorbs that. A single replica does not, which is why you picked a namespace with replicas.

### Freeze a process

Freezing keeps memory intact for forensics, which is why you want it. The failure mode is anything the process was holding. A frozen process does not release its database lock or its leader lease. Peers wait for a lock that will not clear until someone acts. If your service uses leases, check that lease expiry is shorter than the patience of whatever is waiting.

A frozen process also fails its probes, and the kubelet will eventually destroy what you froze. Set `holdProbes: true` so the agent answers HTTP and gRPC probes during the investigation window. Exec probes run inside the container and cannot be held, so `grep` for them first. Page the on-call engineer at the same moment. A freeze is a request for a human, with the evidence preserved for them.

### Drain a node

Drain is the blunt one, and the chart leaves it off unless you set `rbac.nodeDrain=true`. Keep it off for your first quarter unless you have a reason. It respects PodDisruptionBudgets, so a tight budget will block eviction and the drain sits there. That is correct behavior and an awful thing to discover during an incident. Run `kubectl drain --dry-run=server <node>` on a sample of nodes before enabling it. Also note what drain does to noisy neighbors: their pods move through no fault of their own, and the owners will want to know why.

## Numbers to expect

In Wickhold lab benchmarks, 2026, Quenchline contains a known-bad process in a median of 38 seconds and runs at under 2% CPU overhead on a typical node. Your production numbers will differ. A lab node is not running your sidecars. Measure your own before you quote them to anyone, particularly someone with a budget.

## What contain mode does not do

Quenchline does not fix anything. It stops a process or a pod from going further and leaves the workload degraded on purpose. It will not tell you how the process got there, restart your service, or close the hole. It also will not save you from a policy you wrote badly: if you exempt the namespace's whole image, it will contain nothing in that namespace, quietly and at low overhead.

## Rolling back

Rollback is one line in the policy. Write the exact command in the runbook and make sure the on-call engineer has run it once, on a quiet day, so the first time is not 3am.

```bash
kubectl patch containmentpolicy checkout-api -n checkout \
  --type merge -p '{"spec":{"mode":"observe"}}'
```

Then put the same change through the repo, or your GitOps controller will helpfully undo it.

Do the next namespace when the first has been boring for two weeks. Boring is the target.

Dov
