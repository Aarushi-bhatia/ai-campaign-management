Title: We Raised $46M to Keep Every Workload Watched
Slug: series-b
Published: June 2024
Author: Maren Tolliver

---

When Dov and I started Wickhold Security in Denver in March 2019, we had a spreadsheet of customer ideas, two old laptops, and a strong opinion that nobody should learn about a production incident from a customer.

Today I'm excited to share that we've raised a $46M Series B led by Marlbank Partners!

I want to say why this matters to the people who actually run our software, because funding announcements are usually written for other investors.

## Where we are

Both of us came up as on-call infrastructure leads. We have been woken up at the hours you've been woken up. When we started the company, the idea was simple: if you can see what's running, you have a chance. That idea has held up. More than five years later, Wickhold Quenchline and Wickhold Tallowatch give over 80+ teams continuous visibility into cloud and Kubernetes risk.

The need keeps growing. Our own research found that 68% of runtime incidents began with a misconfigured workload, and every customer conversation I have backs it up. The clusters are getting bigger. The teams running them are not.

When we closed our Series A in March 2022, I remember telling the team we would stay focused on Kubernetes and not chase every shiny thing in cloud security. There was a lot of pressure to do otherwise. Every few months someone would tell me we needed to be a "platform for everything." We've held that line, mostly, and I think that discipline is why customers keep renewing.

I also want to name what's hard. Runtime security is not a solved problem. Agents have to run on every kind of node, kernels keep changing, and customers rightly get nervous about anything that touches production. Some weeks that means our engineers spend more time on compatibility than on the features we'd like to be talking about. That's the job.

## What the money is for

Three things.

First, more engineering on Quenchline. Our eBPF agent is the heart of what we do, and I want it to be the best-in-class runtime sensor on the market. Our team will keep raising the bar on what it can catch, on more kernels and more distributions.

Second, a deeper Tallowatch. Customers keep telling us they want fewer findings and better ones. We hear you.

Third, people. Ilse Varga-Holm joined us this year to lead marketing, and we'll be growing field engineering under Tomas Beaulieu-Kerr so that when you call us, you reach someone who has actually been in a war room.

We'll also keep investing in the Field Report, which has become one of the most-read things we publish, and in Slow Burn Summit, which started as a handful of customers in a borrowed room in Denver and has grown into our favorite week of the year.

## What won't change

We are still run by people who have carried a pager. We will still pick up the phone. And I will still read every support escalation that lands on a weekend, a habit my board finds strange and my team finds annoying.

A quick note on Marlbank Partners, since people will ask. They didn't ask us to change what we are. Their first question at our first meeting was how many times I had personally been paged that year. I knew then that we'd get along.

To our customers: thank you for trusting a small company in Denver with your production clusters. To the team: I'm proud of you, and now the real work starts. To Marlbank Partners: thanks for betting on us.

We're hiring across engineering, field, and marketing. If you've ever been paged at 3am and thought "there has to be a better way," come talk to us at careers@wickhold.example.

Onward!

Maren Tolliver
CEO and co-founder

*Wickhold Security keeps every workload watched. Our platform gives over 80+ teams continuous visibility into cloud and Kubernetes risk. Founded in 2019, Wickhold Security is headquartered in Denver.*
