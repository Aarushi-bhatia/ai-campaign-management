# Anatomy of a Cryptominer Incident: What Really Happened in One Kubernetes Cluster

*By Dov Achterberg, CTO, Wickhold Security. Posted October 2023.*

The company in this story asked us not to name them, so we won't. They run a mid-sized logistics platform on a managed Kubernetes service. Details below are changed where they could identify anyone. The timeline is real.

**Saturday, 02:10.** A node in the batch pool reports sustained high CPU. The cluster autoscaler does what it was told and adds two nodes. Nobody is paged, because the alert threshold was set for the API pool and the batch pool is expected to run hot.

**Saturday, 06:40.** The autoscaler has added more nodes. The on-call engineer sees a cost anomaly email on her phone and decides it can wait for coffee. Reasonable. It was a Saturday.

**Saturday, 08:15.** She opens the Quenchline console. There is a process named `kworkerd` running inside a pod in the `reports` namespace. Real kernel workers do not live inside containers. The process is connecting out to a host on port 3333, and the pod's image has no reason to speak to anything but the database.

## How it got in

The `reports` deployment had been copied from an old internal chart a year earlier. It exposed a debug endpoint on a Service of type LoadBalancer. Somebody had meant to remove that before go-live. The endpoint accepted a file upload and executed it, because in development that was a convenient way to run sample jobs.

No zero-day and no nation-state, just a forgotten debug port. This is the pattern we keep finding. Our Field Report 2023 found that 68% of runtime incidents began with a misconfigured workload, and this one is a textbook case.

## How it spread

From the pod, the miner read the mounted service account token. That service account could list and create pods cluster-wide, a leftover from a batch scheduler migration. So the miner deployed copies of itself to the batch pool, where high CPU wouldn't look strange. Five hours of free compute, paid for by the autoscaler.

## What contained it

Quenchline was running in observe mode because the team had installed it only three weeks earlier and wanted to learn normal behavior before enforcing anything. So there was detection but no action until a human looked. Once she did, the sequence took under an hour:

1. Isolated the network on the affected pods, which cut the outbound mining traffic.
2. Revoked the service account token and removed the cluster-wide role binding.
3. Scaled `reports` to zero and deleted the LoadBalancer Service.
4. Drained the batch nodes and let the autoscaler replace them.

Wickhold Tallowatch, running in the same account, had already listed the exposed Service and the overbroad role binding as findings. Those findings had been sitting in a queue for two weeks. Nobody had triaged them, which is not a tooling problem.

## Reading the audit log afterwards

The Kubernetes audit log told the rest of the story, and it is worth saying how, because many teams don't keep it long enough to be useful. The first `create pods` call from the `reports` service account came at 01:52. There were eleven more before the on-call engineer logged in. All of them succeeded, and all of them came from an identity that had not created a pod in months. A simple alert on "service account does something it has never done" would have fired eighteen minutes before the CPU alert that nobody saw.

The customer kept audit logs for seven days. Had this been discovered a week later, there would have been no timeline to write up.

## What we would do differently

- **Alert on egress from pods that have never had egress.** A reports job talking to port 3333 is a stronger signal than CPU.
- **Set a limit on the autoscaler.** A hard cap on the batch pool would have turned a five-hour bill into a page.
- **Treat debug endpoints as production code.** If it ships, it gets reviewed.
- **Move from observe mode to contain mode on a schedule.** Three weeks of learning is fine. Having no date for turning on containment is how you end up reading a cost email at breakfast.

The financial damage here was a modest cloud bill. The same path, with a different payload, could have been a very different weekend. With our platform, you can catch these threats before they become headlines! Book a demo and see how Wickhold Security can help protect your clusters today.

*Dov is CTO and co-founder of Wickhold Security. Before that he carried a pager for longer than he cares to admit.*
