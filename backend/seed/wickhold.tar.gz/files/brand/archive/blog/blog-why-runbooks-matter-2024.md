# Why Your Team Needs a Container Escape Runbook (and How to Write One)

April 16, 2024 | Tomas Beaulieu-Kerr, VP Field Engineering

I've sat in a lot of war rooms over the years, and the worst moment in any of them is the same. Someone says "okay, so what do we do?" and everybody looks at each other.

Our new Wickhold Field Report 2024 puts a number on that silence: 52% of teams have no runbook for container escape. These are serious engineering organizations. They have runbooks for failed deploys and full disks. They do not have one for the day a process breaks out of a container onto the host, which is the day they will need it the most!

Add last year's finding that 68% of runtime incidents began with a misconfigured workload, and the picture is clear. Mistakes get made, somebody will find them, and most teams are improvising when it happens.

Here's how my field engineers help customers put a basic runbook together. You can get a first version done in an afternoon.

## Step 1: Agree who can make the call

Write down the names and roles of the people allowed to isolate a pod, cordon a node, or pull a workload out of production without asking for permission. If the answer is "the VP, once we reach him," fix that first.

## Step 2: Define your signals

List what counts as a suspected escape in your environment. Good starting points:

- A process in a container calling `nsenter` or `mount`
- Writes to host paths from a container that shouldn't have any
- A privileged pod nobody can account for
- Access to the container runtime socket

## Step 3: Script the first ten minutes

Don't write an essay. Write commands your most tired engineer can paste.

```bash
# stop new pods landing on the node
kubectl cordon <node>

# capture what's running before anything changes
kubectl get pods -A -o wide --field-selector spec.nodeName=<node> > pods-<node>.txt

# cut the pod's network (assumes a default-deny policy keyed on this label)
kubectl label pod <pod> -n <ns> quarantine=true
```

## Step 4: Preserve evidence before you clean up

Everyone wants to delete the pod. Don't, not yet. Snapshot the node's disk, grab the logs, and save the audit log window. If you delete first, you will be guessing at root cause for the next month.

## Step 5: Practice it

A runbook nobody has run is just a document. Put a game day on the calendar every quarter. Use a test cluster, have someone play the attacker, and time how long it takes to get to isolation. The first run is always humbling. That's the point.

## Step 6: Fill in the boring parts

The parts of a runbook that save you are rarely technical. Add these before you call it done:

| Item | Example |
|---|---|
| Who declares the incident | On-call SRE, no approval needed |
| Where people gather | A pinned incident channel, plus a bridge line |
| Who talks to legal | Named person and a backup |
| Who updates customers | Named person and a backup |
| When to wake the CISO | Any confirmed host access |

One customer told me their first game day stalled for twenty minutes because nobody knew the password to the bridge line. It's always something like that.

## What a good one looks like

The best runbook I've seen fit on two pages. It lived in the same repo as the cluster config, so it got reviewed whenever the cluster changed. Every command had been run by someone in the past ninety days. The worst one I've seen was forty pages, written by a consultant, and stored on a laptop that had left the company.

## How Wickhold Security fits in

Runbooks work a lot better when your tools are doing the heavy lifting. Wickhold Quenchline can trigger containment actions automatically, and Wickhold Tallowatch helps you find the risky privileged workloads before anyone can abuse them. Together they empower your team to respond with confidence.

If you'd like my team's runbook template, or want a field engineer to walk through it with you, [click here](https://wickhold.example/runbook-template) and we'll be in touch!

*Every workload. Always watched.*
