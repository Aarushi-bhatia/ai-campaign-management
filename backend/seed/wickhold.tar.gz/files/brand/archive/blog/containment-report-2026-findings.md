# What 412 platform and security leaders told us about containment

April 14, 2026

41% of platform teams need more than six hours to contain a runtime incident [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]. The same report puts the median at 7.4 hours: the median time to contain a runtime incident is 7.4 hours.

Those are the two figures from this year's Wickhold Containment Report that will get quoted. The report surveyed 412 platform and security leaders, and this post covers what sits behind the headline numbers, what the survey cannot tell you, and what a team could change this quarter.

## Why the report measures containment

Editions before 2025, published as the Wickhold Field Report, asked where incidents started. That was useful for a few years. It also pushed the conversation toward the first mistake, which every team makes and no team fully removes.

This year's survey asks a different question: once someone knows something is wrong, how long until it can no longer spread? Containment is the part of an incident a team controls. It is also the part most incident reviews skip, since the timeline usually jumps from "detected" to "resolved" with a long gap in the middle.

## How the survey defined the clock

Respondents reported the time between the first confirmed signal and the moment the affected workload could no longer reach anything it should not reach. Full recovery was excluded. So was root cause. A pod with its network isolated and a process frozen counts as contained, even if the application is still down and the postmortem has not started.

That definition matters when comparing these numbers with internal metrics. Many teams track mean time to resolve, which folds in repair, rollback and customer communication. Mean time to resolve will always look worse than time to contain, and it tells a team less about whether a failure was still spreading.

## Where the hours go

Respondents described their slowest incidents in free text, and the themes were consistent. Few of them blamed detection. The hours went to three kinds of waiting.

**Waiting for authority.** The engineer on call could see the problem but needed someone else's approval to isolate a production workload. At night, that someone else was asleep or on a plane.

**Waiting for context.** Nobody on the call knew what the workload did, who owned it, or what would break if it lost network access. A label or an owner annotation would have answered the question in seconds. Often neither existed.

**Waiting for the second team.** Platform engineers could act on the cluster, security engineers could read the alert, and the two groups were in different channels. The handoff between them could take longer than the fix.

None of those is a sensor problem. A faster alert does not shorten any of them. The teams that described short containments tended to have settled these questions before the incident, and several said so in almost those words.

## What a team can change this quarter

The report's recommendations are unglamorous, which is why they are likely to work.

1. **Name who may contain, in writing.** Give the on-call engineer standing authority to isolate a pod or freeze a process in production without approval. Reversible actions should not need a meeting.
2. **Make ownership queryable.** Require `team` and `tier` labels at admission, then reject workloads without them. At 3am, `kubectl get pod -L team,tier` should answer the first two questions on the call.
3. **Time your drills on containment.** Run a game day and stop the clock when the workload is contained. Most teams time resolution, then learn nothing about the first hour. Keep the result and compare it quarter over quarter.
4. **Put both teams in one incident channel.** One channel, opened automatically, with the platform and security on-call engineers paged together.

## What the survey cannot tell you

The figures are self-reported, by leaders, and leaders tend to remember their incidents as shorter than the logs do. Treat 7.4 hours as a floor for planning purposes, and measure your own number from your own incident timelines. The survey also cannot separate a contained credential leak from a contained crypto miner, which are very different events. The sample covers platform and security leaders at organizations running Kubernetes in production, so it says little about teams at the very start of adoption.

## Where Wickhold Quenchline fits

Wickhold Quenchline is built for the last of those gaps: it can take a containment action, under a default containment policy the team has agreed in advance, without waiting for a human to approve it. In Wickhold lab benchmarks, 2026, Quenchline contains a known-bad process in a median of 38 seconds. Lab results are not production results, and the number that counts is the one on your own timeline.

Quenchline does not do the first two things on the list above. It cannot decide who holds authority in your organization, and it will not write your ownership labels for you. Those are yours, and they probably account for more of your 7.4 hours than any tool does.

The full report, with the survey method and the full question set, is free and has no form in front of it.

[Read the report](https://wickhold.example/containment-report)

*Wickhold is the runtime security company for teams that run Kubernetes. Its products contain failures early, so small fires stay small. Founded in 2019 and based in Denver, Wickhold serves more than 140 customers.*
