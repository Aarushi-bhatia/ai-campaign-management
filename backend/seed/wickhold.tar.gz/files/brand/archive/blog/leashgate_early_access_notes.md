---
title: Wickhold Leashgate enters early access
date: 2026-05
author: Wickhold product marketing
tags: [leashgate, ai-agents, product-news]
---

# Wickhold Leashgate enters early access

The median time to contain a runtime incident is 7.4 hours [Wickhold Containment Report, 2026, https://wickhold.example/containment-report], and that figure comes from incidents involving ordinary workloads with ordinary service accounts. AI agents with tool access are now arriving in the same clusters, and they move faster than the humans on call.

Wickhold Leashgate, our runtime policy product for AI agents and their tool calls, is now in early access. This post explains what early access includes, how the product works, and what it does not do.

## The problem with agents in production

An agent in a production cluster is a workload that makes its own decisions about what to call next. Platform teams are being asked to run these agents, often with credentials that were copied from a developer's laptop during a pilot. The agent can reach a database, a ticketing system and a deployment pipeline, because during the pilot that was convenient.

Most of the time this works fine. When it does not, the failure is hard to reason about. A model may be manipulated by content it read, or it may simply make a poor decision. Either way, the question for the on-call engineer is the same as for any other incident: how far can this get?

The term we use for that is the blast radius of an agent. It is set by what the agent is allowed to do at runtime, and that is what Leashgate controls.

## What Leashgate does

Leashgate sits between an agent and the tools it calls. It works with three concepts.

**Agent identity.** Each agent gets its own identity, separate from the human who launched it and from the service account of the pod it runs in. Logs and policies refer to that identity, so "which agent did this" has an answer.

**Tool-call policy.** A team writes down which tools an agent may call, with which arguments, on which targets. A support agent may read a customer record but may not export a table. A deployment agent may restart a service in staging but may not touch production. Calls outside the policy are blocked and logged.

**Containment.** A call that breaks policy can trigger the same kind of response platform teams already use with Quenchline. If an agent starts behaving badly, it can be cut off from its tools while a human takes a look, and the rest of the application keeps running.

Put simply, Leashgate limits what a compromised agent can do.

A short example of a tool-call policy, in the shape early access customers are using:

```yaml
agent: support-triage
tools:
  - name: crm.read_record
    allow: true
  - name: crm.export
    allow: false
  - name: tickets.update
    allow: true
    when:
      field: status
on_violation: suspend_agent
```

The format may change during early access. We will tell participants before it does.

## What Leashgate does not do

Leashgate does not read prompts and it does not judge whether a model has been manipulated. It has no opinion on the quality of an agent's output, and it will not catch an agent that gives a customer bad advice through a tool it is allowed to use. What it controls is the set of actions available to the agent. A permitted action that happens to be a poor decision will still go through, so policy needs the same care you would give any access review.

## How it relates to what teams already run

Leashgate does not replace network policy, RBAC or Wickhold Quenchline, and it should be added to them. Network policy decides which hosts a pod can reach. RBAC decides what a service account can do in the cluster. Quenchline watches processes and connections on the node. None of them can tell that a permitted HTTPS call to the ticketing system was an agent closing every open ticket. That is the layer Leashgate works at: the named tool, its arguments and the identity making the call.

Because the agent's tool calls pass through Leashgate, every call is also logged with the agent identity attached. Several teams in our design conversations cared more about this record than about blocking. When a security reviewer asks what an agent did last Thursday, the team can answer without searching application logs.

## What early access includes

Wickhold Leashgate (early access) is available to customers on the Enterprise tier. Participants work directly with our engineering team and get:

- Support for deploying Leashgate alongside an existing Quenchline installation
- Help writing first tool-call policies for one or two agents
- A direct channel to the engineers building the product
- Input on the policy format before it settles

Early access means what it says. Features will change, there will be rough edges, and it should not be the only control around an agent that can reach something critical. We would rather have a small number of teams using it on real agents than a large number of teams trying it in a sandbox.

## Who should apply

Early access suits platform and security teams that already have at least one agent in production, or are about to, and have someone who can own policy. Teams still deciding whether to run agents at all should wait. There will be plenty to read as we learn more.

Your account team can tell you more, or you can apply directly.

[Request early access](https://wickhold.example/leashgate)

*Wickhold is the runtime security company for teams that run Kubernetes. Its products contain failures early, so small fires stay small. Founded in 2019 and based in Denver, Wickhold serves more than 140 customers.*
