# I stopped saying "prevent," and it cost us a deal

*September 29, 2026*

41% of platform teams need more than six hours to contain a runtime incident [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]. I have been one of those teams. Long before Wickhold existed, I ran infrastructure on-call at a company I won't name, and the longest night of my working life was a containment that took eleven hours because nobody could agree who was allowed to turn something off.

I want to write about a word, because I spent about five years using it badly.

In our early days, I said "prevent" constantly. It was on our website, in our decks, and in my mouth on every sales call. Buyers liked it. Investors liked it more. I knew it was not true the way a customer would hear it, and I said it anyway, because everyone in our market said it and I was worried about what would happen if we didn't.

Here is what would happen, as it turns out. Last winter, about a month before we changed our name, I was on a final call with a security leader at a large company. Good person, sharp questions. Near the end he asked, "Can you guarantee this stops an attacker from getting into my cluster?"

I said no.

I said our product does not do that, that no product does, and that anyone who told him otherwise was selling him something he would be disappointed by later. I told him what we do: when something goes wrong, we limit how far it gets and how long it lasts. He thanked me politely. We lost the deal, and I later heard he had signed with someone whose website promised exactly what I had refused to.

I went home in a foul mood. I am telling you this so you don't think I enjoyed being honest. It cost us real money and my head of sales did not speak to me for a day.

I still think it was the right answer, and here is why.

## The promise changes how people build

When a vendor promises prevention, the buyer plans as if the failure will not happen. No runbook, no drill, no argument about who may isolate a workload at 3am, because the product handles it. The promise removes the preparation, so the first incident lands harder than it needed to.

I have read a lot of incident reviews from teams like that. They have all kinds of alerts. What they lack is an agreed plan for the worst hour. Their contracts promised they would never need one.

When you buy containment instead, you have to accept up front that something will get through. That is an unpleasant conversation. It is also the conversation that gets a runbook written. Customers who take it seriously end up with a different kind of incident. Lowmoor Credit Union went from 4 hours to contain down to 11 minutes on 220 nodes. I would love to say that was all our software. Much of it was their team deciding, ahead of time, who could act and what they could do.

## What I ask our people to say now

Inside Wickhold we use three verbs: contain, limit, slow. I chose them because each one can be checked. You can measure how long containment took. You can point to what a pod could no longer reach. "Prevented" is a claim about something that didn't happen, so nobody can ever check it, which is exactly why it is so comfortable to say.

We also tell people what we can't do. Wickhold Quenchline will not stop someone from getting in. It does not find every misconfiguration. It does not repair what it contains. Our salespeople find this awkward at first and then, usually within a quarter, tell me it has made their calls easier, because the buyer stops looking for the catch.

I don't want to make this sound braver than it is. Plenty of companies were honest before we were. We got here late, after years of using the same word as everyone else, and I'm sure you can still find it in old posts of ours. I have left those up. Deleting them would be its own kind of dishonesty.

## Where I still get it wrong

I still catch myself. A couple of weeks ago, on stage at Slow Burn Summit, I started a sentence with "we make sure that never" and had to stop and take it back in front of a room of customers. They laughed, which was generous. Habits like this are slow to die, especially when the true sentence is longer and less exciting than the false one.

There is also a fair argument against me. Some controls do prevent things. A default-deny network policy really does stop a connection. I have no quarrel with that. My quarrel is with selling the whole of a company's safety as if it were one of those controls. A single rule can be absolute. A production system run by people cannot.

If you are a founder in this market, you will be tempted, and the temptation will come with a forecast attached. I can't tell you it pays off on any particular timeline. We lost that deal and I can't prove we won another because of it.

What I can tell you is that I sleep better, and I carried a pager long enough to know how much that is worth.

Maren
