# Why we took the word "Security" out of our name

February 10, 2026

Starting today, our company is called Wickhold.

I'll explain why, because a rebrand with no reason behind it is just an expensive logo. And I know what most of you were thinking when you saw the announcement: did they really need to do this?

Dov and I named the company Wickhold Security in 2019, in a hurry, because we needed something for the incorporation papers. "Wickhold" came from a joke about candle holders. "Security" was there so people would know what we sold. Then for years our shield-and-flame logo and a blue website told customers roughly what every other vendor in this market told them: we are watching, you are safe, be afraid of everything else.

The longer I run this company, the less I believe that story. Nobody I respect in this industry thinks incidents can be made to go away. Things fail at 3am. What matters is how far the failure gets.

A wick is a good picture of that. It's the place where a fire is allowed to exist. Fire on a wick is useful and it stays where you put it. The same fire on the curtains is a different kind of evening. That's what our customers actually hire us for. They don't need us to promise there will never be a flame. They need the flame to stay small.

So our new tagline is **Small fires stay small.** Our new mission is to keep small failures from becoming big ones. It's what we have been doing all along, and we finally got around to saying so.

## What's changing today

- The name: Wickhold, everywhere, as of this morning. The legal entity is Wickhold, Inc.
- The logo: a geometric W whose center stroke rises as a wick, with one dot of Ember at the top.
- The look: warmer, quieter, less blue. You'll see it on the site this week and in the product over the coming months.

## What isn't changing

The team and the people you call. Wickhold Quenchline does the same job it has done since 2020. Wickhold Tallowatch is still Tallowatch for now, and we'll have more to say about product naming very soon.

Contracts, invoices and support channels all stay the same. If your procurement team needs a letter about the name change, email hello@wickhold.example and we'll send one.

## Questions we've already been asked

**Are you still a security company?** Yes. Dropping the word doesn't change what we sell. It was doing less work than we thought. Nobody buys a runtime agent from us because of the second word in our name.

**Why not keep the shield?** A shield says that nothing gets through. We have never been able to promise that, and it took me too long to admit it. Several of our longest-standing customers told us in interviews that the old look felt like everyone else's, and one of them could not pick our logo out of a row of four.

**What should I call you?** Wickhold. It's pronounced WICK-hold. If your finance system still says Wickhold Security for a while, nothing bad will happen.

**Is this because of an acquisition, or a new owner?** No. Dov and I still run the company. Nothing has changed about who owns or funds us.

**How much did it cost?** Less than you'd guess, and more than I enjoyed approving.

## The reason the work matters

I'll repeat a number you've heard from us before: 68% of runtime incidents began with a misconfigured workload. Mistakes are ordinary. They happen on good teams with good engineers. What separates a bad week from a bad year is how quickly a small failure gets contained. We want to be the company that helps with that part, and we want our name and our words to match.

Ilse Varga-Holm and the marketing team did this in under a year on top of their normal work, and they deserve the credit. We are so excited for you to see it!

Thank you for coming along.

Maren

*Every workload. Always watched.*
