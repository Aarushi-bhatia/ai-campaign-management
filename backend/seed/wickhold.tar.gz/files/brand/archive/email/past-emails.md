# past emails

Copied out of the send tool for reference. Body text as sent, images dropped. Notes at the bottom of each are from whoever ran the send.

---

## Field Report launch

Sent: April 2024
List: all prospects + customers
From: Wickhold Security <news@wickhold.example>
Subject: NEW Field Report: Is Your Cluster Next?!

Hi {{first_name}},

Our brand-new Wickhold Field Report 2024 is here, and the findings are eye-opening!

Our researchers surveyed teams running Kubernetes in production, and what they found should concern every security leader:

- 52% of teams have no runbook for container escape
- Misconfiguration remains the top way in. Remember, 68% of runtime incidents began with a misconfigured workload

Every day your team runs without a plan is another day attackers have the advantage. The threat landscape is moving fast, and the clock is ticking. Think about it: if a process broke out of a container on your busiest node tonight, would your on-call engineer know what to do? Would they even know it had happened?

That's where Wickhold Security comes in. With Wickhold Quenchline and Wickhold Tallowatch, you get a single pane of glass for cloud and Kubernetes risk, so nothing slips through the cracks. Our robust platform helps you find misconfigurations early and stop threats in real time, all without slowing your developers down.

Inside the report you'll find:

- The full survey findings
- A maturity model to benchmark your team
- Five things you can do this quarter
- A container escape runbook template from our field engineers

**Why does this matter now?** Clusters are growing faster than the teams who run them. One misconfigured deployment can spread across namespaces in minutes, and without a plan, your people will be improvising under pressure while the damage piles up. Our field engineers see it every week: smart teams, great tools, and nobody sure who is allowed to pull the plug.

The good news is that it doesn't have to be this way. Teams who invest in a tested runbook, continuous posture checks and real-time runtime protection are far better placed when the worst happens. It takes less time than you'd think, and the Field Report shows you where to begin.

We've also added a section on what the teams with the fewest incidents do differently. Share it with your CISO, your platform lead, or anyone else who needs a wake-up call!

**[Click here to download the report]**

Stay safe out there!

The Wickhold Security Team

P.S. Want to know how your own clusters would score? Ask about a free Tallowatch assessment. One of our field engineers will walk you through the results, and there's no obligation. Our last round of assessments filled up quickly, so reply today to reserve your spot!

Every workload. Always watched.

*Wickhold Security keeps every workload watched. Our platform gives over 80+ teams continuous visibility into cloud and Kubernetes risk. Founded in 2019, Wickhold Security is headquartered in Denver.*

Notes: gated download. Sales asked for the subject with the question in it. Two unsubscribe replies complaining about the tone, forwarded to Ilse.

---

## Webinar invite: Tomas

Sent: October 2024
List: prospects, platform + security titles
From: Tomas Beaulieu-Kerr <tomas@wickhold.example>
Subject: Live demo: catching a container escape in real time!

Hi {{first_name}},

I've spent the past year in customers' war rooms, and I keep hearing the same thing: "We have the alerts. We just don't know what to do with them."

So on Thursday, November 7, my team and I are running a free live session. We'll break out of a container in a test cluster, on purpose, and show you how Wickhold Quenchline catches it and how Wickhold Tallowatch would have flagged the misconfiguration that made it possible. Remember, 68% of runtime incidents began with a misconfigured workload, so we'll start there.

You'll learn:

- What a real escape looks like in your logs
- How to go from alert to containment in minutes
- How to leverage eBPF for deep runtime visibility without slowing your apps down
- Three questions to ask any runtime security vendor

There'll be plenty of time for Q&A with real field engineers, no sales pitch. Okay, maybe a small one.

Here's the rough agenda, since people always ask:

- 10 minutes: how container escapes actually happen, with a real (anonymized) customer story
- 20 minutes: the live demo, from first process to contained pod
- 15 minutes: building your own runbook, with our template
- 15 minutes: your questions, as many as we can get through

We'll keep the session to one hour, and yes, we know what happens to live demos. If it breaks, you'll get to see how we debug it, which might be the more useful show anyway.

If you're bringing a colleague, bring the person who'd get paged. They're the one who needs this. We'll send everyone who attends a copy of our runbook template and the exact commands we use in the demo.

Can't make it live? Register anyway and we'll send you the recording.

**[Learn more and register]**

See you there,
Tomas

Tomas Beaulieu-Kerr
VP Field Engineering, Wickhold Security

Every workload. Always watched.

Notes: sent from Tomas's address as a test, replies went to his inbox and he answered most of them himself. Reminder went out the morning of. Demo cluster fell over for ten minutes, recording edited.

---

## Summer product update

Sent: June 2025
List: customers
From: Wickhold Security <product@wickhold.example>
Subject: What's New at Wickhold Security: Summer Edition

Hi {{first_name}},

We've been busy! Here's a look at what shipped this quarter and what's coming to help you get even more from the platform.

**Tallowatch: findings you can act on.** Tallowatch now groups related findings, so one bad base image no longer shows up as hundreds of separate alerts. Your clients and auditors will thank you, too. Reports export more cleanly for SOC 2 reviews, and you can now assign a finding to an owner directly from the console.

**Quenchline: smarter containment.** You can now scope containment actions by namespace. Start in observe mode and turn on contain mode where you're ready. We've also added support for more node images, so the agent installs cleanly on more of the managed Kubernetes services you're running.

**Upgrade to the Scale tier.** Customers running across multiple clusters tell us the Scale tier has been a game-changing step for their teams, with cross-cluster reporting and a named field engineer. Talk to your account manager about what's included.

**New in the docs.** We've rewritten the Helm install guide from the ground up, with a troubleshooting section for the most common agent errors. Thanks to everyone who sent in corrections.

**Coming next quarter.** We're working on cross-cluster policy templates for Quenchline, so you can define a containment policy once and roll it out everywhere, and on a cleaner way to map Tallowatch findings to the CIS Benchmarks. Want early access? Tell your account manager and we'll add you to the list.

**A customer tip.** One of our customers runs a monthly "findings Friday," where the platform team clears the top ten Tallowatch items over pizza. They tell us it's the most popular meeting on the calendar. We can't promise pizza, but we'd love to hear how your team does it. Reply to this email and tell us!

**Save the date: Slow Burn Summit.** We're back in Denver this September with customer talks, labs, and time with our engineers. Early registration is open now, and last year's event sold out, so don't wait!

**[Click here to register]**

**Customer office hours are back.** Starting in July, our field engineers will hold open office hours every other Wednesday. Bring your noisiest policy, your strangest finding, or your upgrade plan. No slides, no sales people, just engineers. Sign-up details are coming in a separate note from Tomas's team.

Thanks for being a customer,

The Wickhold Security Team

Every workload. Always watched.

Notes: quarterly send. Summer Edition naming was a one-off.

---

## Tallowatch rename notice

Sent: March 2, 2026
List: customers
From: Wickhold <product@wickhold.example>
Subject: Tallowatch is now Evenburn!

Hi {{first_name}},

Last month Wickhold Security became Wickhold. Today our posture product takes its new name too: Wickhold Tallowatch is now Wickhold Evenburn.

You don't need to do anything. Your policies, exceptions, reports and integrations all carry over. The console shows the new name from today, and a few help articles will catch up over the next few weeks. API paths and chart names are not changing for now, and we will give notice before they do.

The name is changing because customers told us they didn't need more watching. They needed to know what to fix first. Evenburn's fix order and exposure paths are built for that, and they are the same features you already have.

Questions go to your account team or hello@wickhold.example.

**[Read the announcement]**

Thank you,
The Wickhold team

Small fires stay small.

Notes: subject exclamation mark was a last-minute swap. Help center links checked by Kofi before send.

---

## Containment Report 2026

Sent: April 14, 2026
List: all prospects + customers
From: Wickhold <news@wickhold.example>
Subject: Contain time: new survey of 412 leaders
Preheader: The median is 7.4 hours. Most of it is waiting.

Hi {{first_name}},

41% of platform teams need more than six hours to contain a runtime incident [Wickhold Containment Report, 2026, https://wickhold.example/containment-report].

We surveyed 412 platform and security leaders. Few of them pointed at detection. The hours went to waiting for approval, waiting for someone who knew the workload, and waiting for the other team to join the call.

The report covers how we defined the clock, where the time goes, and four changes a team can make this quarter. The first needs no tooling at all: name who may contain, in writing.

The report is free and has no form.

**[Read the report]**

The Wickhold team

Notes: ungated on purpose. Subject tested against "The 2026 Containment Report", this one won.

---

## Slow Burn Summit recap

Sent: September 22, 2026
List: customers
From: Kofi Anselm <kofi@wickhold.example>
Subject: Slow Burn Summit: recordings are up
Preheader: Customer talks, Dov's session on contain mode, and the Leashgate early access lab.

Hi {{first_name}},

Thank you to everyone who came to Denver on September 15–16. If you missed it, or spent the session you wanted to see in a hallway conversation, the recordings are now up.

Three worth your time:

- A customer's walkthrough of a containment that went wrong, including the Helm value that caused it
- Dov on rolling out contain mode, one namespace at a time
- The Wickhold Leashgate (early access) lab, on writing a first tool-call policy

Slides and lab files are on the same page. If you have a failure story you would tell on stage next year, reply to this email. We read all of them.

**[Watch the recordings]**

Kofi Anselm
Head of Developer Relations, Wickhold

Notes: customers only, recordings are behind login. Kofi asked to send it himself.
