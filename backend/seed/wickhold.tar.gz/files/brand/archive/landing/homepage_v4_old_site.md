old homepage, saved from the CMS before the February cutover. Last edit was fall 2025.

```html
<!-- home v4 -->
<html>
<head>
<title>Wickhold Security | Every Workload. Always Watched.</title>
<link href="https://fonts.example/inter.css" rel="stylesheet">
</head>
<body style="margin:0;font-family:'Inter',Arial,sans-serif;color:#0B1B3A;background:#FFFFFF;">

<div style="display:flex;justify-content:space-between;padding:20px 48px;border-bottom:1px solid #E6EAF2;">
  <img src="/img/shield-flame-wordmark.svg" alt="Wickhold Security" height="32">
  <a href="/demo" style="background:#1F4FD8;color:#FFFFFF;padding:10px 18px;border-radius:6px;text-decoration:none;">Book a Demo</a>
</div>

<div style="background:#0B1B3A;color:#FFFFFF;padding:96px 48px;text-align:center;">
  <h1 style="font-size:52px;font-weight:800;margin:0;">Every Workload. Always Watched.</h1>
  <p style="font-size:20px;color:#6CA8FF;max-width:640px;margin:20px auto;">
    The next-gen platform for cloud and Kubernetes security. Find every risk, stop every threat, and sleep through the night!
  </p>
  <a href="/demo" style="background:#1F4FD8;color:#FFFFFF;padding:16px 28px;border-radius:6px;text-decoration:none;font-weight:600;">Get Started Free</a>
  <a href="/platform" style="color:#6CA8FF;margin-left:20px;">Learn More</a>
</div>

<div style="padding:64px 48px;text-align:center;">
  <h2 style="font-size:32px;color:#1F4FD8;">68% of runtime incidents began with a misconfigured workload.</h2>
  <p style="font-size:16px;">Source: Wickhold Field Report 2023. Is your team next?</p>
</div>

<div style="display:flex;gap:32px;padding:0 48px 64px;">
  <div style="flex:1;border:1px solid #E6EAF2;border-radius:8px;padding:28px;">
    <h3 style="color:#1F4FD8;">Wickhold Tallowatch</h3>
    <p>Continuous, holistic posture management across all three major public clouds and every cluster. See every misconfiguration the moment it happens.</p>
    <a href="/tallowatch" style="color:#1F4FD8;">Explore Tallowatch</a>
  </div>
  <div style="flex:1;border:1px solid #E6EAF2;border-radius:8px;padding:28px;">
    <h3 style="color:#1F4FD8;">Wickhold Quenchline</h3>
    <p>Best-in-class runtime protection for Kubernetes. Our lightweight eBPF agent watches every process and stops threats in real time.</p>
    <a href="/quenchline" style="color:#1F4FD8;">Explore Quenchline</a>
  </div>
</div>

<div style="background:#F3F6FC;padding:32px 48px;text-align:center;font-size:14px;">
  SOC 2 Type II &nbsp;|&nbsp; GDPR compliant &nbsp;|&nbsp; Trusted by 80+ teams
</div>

<div style="background:#0B1B3A;color:#FFFFFF;padding:40px 48px;font-size:13px;">
  Wickhold Security keeps every workload watched. Our platform gives over 80+ teams continuous visibility into cloud and Kubernetes risk. Founded in 2019, Wickhold Security is headquartered in Denver.
</div>

</body>
</html>
```
