Page: /products/quenchline
Title tag: Wickhold Quenchline: runtime containment for Kubernetes
Meta description: Runtime detection and containment for Kubernetes, using an eBPF agent. Decide the policy once. Quenchline acts on it at 3am.
OG image: same as hero, cropped to 1200x627.
Hero image: photo of a working room at night, two engineers at a shared desk, available light. Alt: "Two engineers reviewing an incident timeline at a shared desk."
Secondary image: screenshot of the containment timeline view, from the demo cluster. Alt: "Quenchline timeline showing a pod isolated after a process alert."
Primary CTA target: /trial. Secondary CTA target: /demo.
Canonical: https://wickhold.example/products/quenchline. Index: yes. Nav label: Quenchline. Footer: standard, with the current tagline.
Form on /trial: work email, company, node count (range). No phone field, Sales asked for one and lost that argument.
Owner: web team. Last published 2026-08-25, copy review by Legal. Changelog: replaced the Tallow panel with the photo in June; moved the numbers section above the fold on mobile in August.

---

# Runtime containment for Kubernetes, decided before the incident

Wickhold Quenchline detects bad behavior at runtime and takes the containment action your team chose in advance. Small fires stay small.

**[Start a trial]** **[See it contain]**

## Most incident hours are waiting

41% of platform teams need more than six hours to contain a runtime incident [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]. Those hours rarely go to detection. They go to finding an owner, getting approval and pulling the second team onto the call.

Quenchline takes that decision out of the worst hour of the night.

## How it works

**Observe first.** The eBPF agent starts in observe mode and logs what it would have done. Most teams spend two to four weeks here, reading decision records.

**Write the policy.** Start from the default containment policy and decide which detection leads to which containment action. Policies go through your repo like any other change. Every exemption has an expiry date.

**Turn on contain mode where you are ready.** Mode is set per policy. Going back is one line.

## Containment actions

| Action | What happens | Use it when |
|---|---|---|
| Isolate a pod's network | The pod can no longer reach anything outside it | A workload is talking to something it never has |
| Freeze a process | Execution stops and memory stays intact | You want evidence for a human to read |
| Drain a node | Pods move off the node, within your PodDisruptionBudgets | The node itself is suspect |

## The numbers

- Contains a known-bad process in a median of 38 seconds, in Wickhold lab benchmarks, 2026.
- Under 2% CPU overhead on a typical node, in Wickhold lab benchmarks, 2026.
- Lowmoor Credit Union: time to contain fell from 4 hours to 11 minutes across 220 nodes.

## What Quenchline does not do

Quenchline does not fix the cause. It holds a failure where it is, and it leaves the workload degraded on purpose until someone on your team repairs it. It also covers Kubernetes only, so workloads on plain virtual machines stay outside its view.

## For the person who has to install it

The agent installs from a Helm chart as a DaemonSet. Permissions, kernel requirements and failure behavior are all in the public docs. If the agent loses contact with its control plane, detection and containment continue on the last synced policy. Read that page before your first rollout, and read the section on liveness probes twice.

## Built to be checked

SOC 2 Type II, renewed January 2026. Wickhold is pursuing FedRAMP Moderate authorization.

Wickhold serves more than 140 customers.

**[Start a trial]**
