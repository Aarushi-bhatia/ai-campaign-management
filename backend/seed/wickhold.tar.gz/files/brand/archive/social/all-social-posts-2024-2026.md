# All social posts 2024-2026

Pulled from the scheduler in October 2026. Published posts only, oldest first. Paste-outs for the archive, nothing tidied.

**2024-01-23 | LinkedIn | company page**
Is your cluster really secure? 🔥

Most teams think so, right up until the day they find out otherwise.

In our Field Report we found that 68% of runtime incidents began with a misconfigured workload. That means the biggest risk in your environment probably isn't a sophisticated attacker. It's a YAML file somebody wrote on a Friday afternoon!

Wickhold Tallowatch continuously scans your clouds and clusters and finds those mistakes before attackers do, so your team can finally sleep at night. See it in action with a free assessment.

Every workload. Always watched.

#Kubernetes #CloudSecurity #DevSecOps

**2024-02-14 | X | @wickholdsec**
Roses are red, violets are blue, your service account has cluster-admin, and the attacker knows too! 🌹 Audit your RBAC with Tallowatch before someone else does. #Kubernetes #InfoSec #ValentinesDay

**2024-03-19 | LinkedIn | Tomas Beaulieu-Kerr**
Great turnout at our runbook workshop in Denver this week! My field engineering team walked customers through the first ten minutes of a container escape, commands and all.

Biggest lesson of the day: the hard part isn't the kubectl, and it isn't the tooling either. It's knowing who is allowed to make the call. Two teams in the room found out they each assumed it was the other one.

Second lesson: nobody had ever timed themselves. We ran the drill twice, and the second run took a fraction of the first.

If your plan is "we'll figure it out," we should talk. Grab the template at wickhold.example/runbook-template.

**2024-04-16 | X | @wickholdsec**
NEW: Wickhold Field Report 2024 is out! Our biggest survey yet on how teams really run Kubernetes in production. Are you prepared? Get the report 👉 wickhold.example/field-report #Kubernetes #ContainerSecurity

**2024-05-07 | LinkedIn | company page**
Thinking about Brannoch Security? Ask them how much that heavy agent costs you in CPU on every single node. Then ask how long the rollout took the last team who tried it.

Quenchline's eBPF agent is lightweight, purpose-built for Kubernetes, and doesn't need a team of consultants to roll out. We'll happily prove it in your cluster. Make the switch to a platform that was built for the way you ship software!

Book a demo today.

#Kubernetes #eBPF

**2024-06-18 | LinkedIn | Maren Tolliver**
Big news! Wickhold Security has raised a $46M Series B led by Marlbank Partners.

I started this company with Dov because nobody should learn about an outage from a customer. Five years later, that's still the reason I get up in the morning. Thank you to the 80+ teams who trust us with their production clusters, and to the people here who've worked so hard to earn that trust.

The money goes to more engineering on Quenchline, a deeper Tallowatch, and more people who've actually sat in a war room. We're hiring across engineering, field and marketing. Come build this with us!

**2024-09-10 | X | @wickholdsec**
See you in Denver for Slow Burn Summit! Hands-on labs, customer talks, and yes, the good coffee. Every workload. Always watched. #SlowBurnSummit #Kubernetes

**2025-01-28 | LinkedIn | company page**
New year, same problem: 68% of runtime incidents began with a misconfigured workload.

Our new guide has 10 best practices to help you unlock a stronger security posture in 2025, from RBAC and network policies to runtime monitoring. Whether you're running a single cluster or hundreds, there's something in it for your team. Share it with your developers, your platform leads, and that one person who still has cluster-admin "just in case."

Read it now on the blog!

#KubernetesSecurity #BestPractices

**2025-03-04 | X | Dov Achterberg**
Reminder that `privileged: true` is not a personality. Tallowatch will find it. So will everyone else. #Kubernetes

**2025-04-15 | LinkedIn | company page**
Our Field Report has a new name! Meet the Wickhold Containment Report 2025.

Same research team, sharper focus on what happens after detection. This year we asked teams how they respond when something goes wrong, who gets woken up, and how long it really takes to get things under control. The answers surprised even us.

A huge thank you to everyone who took the survey! Download your copy now at wickhold.example/report.

#CloudSecurity #Kubernetes #Research

**2025-06-24 | X | @wickholdsec**
Quenchline + Tallowatch = seamless protection from cloud to kernel. Stop all threats before they start! wickhold.example/platform #eBPF #CloudNative

**2025-09-16 | LinkedIn | Kofi Anselm**
Back from Slow Burn Summit with a full notebook.

Best session of the week: a customer walking through a failed node drain, slides and all, with no spin. A PodDisruptionBudget nobody remembered, a very long Tuesday, and a fix that took four lines. People were taking photos of the YAML.

This is why I like this event. Nobody up there pretended their rollout went perfectly, and everyone in the room learned more because of it. Next year I'd like twice as many of these talks.

If you run Quenchline and you've got a story like that, I want to hear it. kofi@wickhold.example

**2025-11-11 | X | @wickholdsec**
Heading to the big cloud-native conference next week? Find us at the booth and see Quenchline stop an attack live! Every workload. Always watched. #Kubernetes

**2026-01-20 | LinkedIn | company page**
Something's changing at Wickhold Security.

Same team, same mission to protect your clusters, a new way of saying it. We've been working on this for a while and we can't wait to show you. More on February 10.

Every workload. Always watched. For now.

**2026-02-10 | LinkedIn | Maren Tolliver**
Today Wickhold Security became Wickhold.

Nothing about our team or our products changes this morning. The name, the logo and the tagline do: Small fires stay small.

We spent seven years telling people we were watching everything. What customers actually hired us for was keeping a bad night from turning into a bad year. A wick is the place where a fire is allowed to exist, and I can't think of a better picture of the job.

I wrote about why we changed on the blog, including the part where we got it wrong for a long time. Thank you to Ilse and the whole marketing team, who did this on top of everything else!

Maren

**2026-02-10 | X | @wickhold**
We're Wickhold now. New name, new mark, same pager. Small fires stay small! Why we did it: wickhold.example/blog/renamed

**2026-03-02 | LinkedIn | company page**
Tallowatch is now Wickhold Evenburn!

Same product, better name. And the same old truth: 68% of runtime incidents began with a misconfigured workload. Evenburn gives you drift, exposure paths and a fix order, so you know what to do first instead of staring at a long list of findings.

No action needed for existing customers. Your policies, exceptions and reports carry over, and your account team can answer anything else. Wickhold Quenchline and Wickhold Evenburn, working better together. More at Slow Burn Summit this September!

#Kubernetes #PostureManagement

**2026-04-14 | LinkedIn | company page**
41% of platform teams need more than six hours to contain a runtime incident [Wickhold Containment Report, 2026, https://wickhold.example/containment-report].

The report surveyed 412 platform and security leaders. Few of them blamed detection. The hours went to waiting: for approval, for someone who knew the workload, for the other team to join the call.

One change needs no tooling. Write down who may isolate a production workload without asking anyone. Give that authority to the person on call.

The report is free and has no form.

**2026-04-14 | X | @wickhold**
The median time to contain a runtime incident is 7.4 hours (Wickhold Containment Report, 2026). Most of that is waiting for someone to say yes. wickhold.example/containment-report

**2026-05-19 | LinkedIn | Maren Tolliver**
This month we opened Wickhold Leashgate early access, and I want to be plain about what it is.

Agents in production need limits, the same as any workload with credentials. I have spent my career watching ordinary software with too many permissions do damage. An agent is more of that, and faster.

Leashgate limits what a compromised agent can do. It does not make an agent trustworthy, and I won't let anyone here say it does.

We're taking a small group of teams who already run agents for real and have someone to own the policy. If that's you, I'd like to hear what you've learned so far.

— Maren

**2026-06-10 | X | Dov Achterberg**
Your liveness probe calls a downstream service. You isolate the pod. The kubelet restarts it and deletes your evidence for you. Helpful. Post on rolling out contain mode: wickhold.example/blog/observe-to-contain

**2026-07-07 | LinkedIn | company page**
Lowmoor Credit Union runs Wickhold Quenchline on 220 nodes. Time to contain fell from 4 hours to 11 minutes.

The team did a lot of that work themselves. They decided ahead of time who could act at night, which workloads could be isolated without a call, and what would be left for a human in the morning. Then they wrote it into their containment policy and spent weeks in observe mode reading what it would have done.

The software needed that decision before it could help.

**2026-08-18 | X | @wickhold**
Quenchline contains a known-bad process in a median of 38 seconds, in Wickhold lab benchmarks, 2026. Lab, not your cluster. Test it on your own nodes.

**2026-09-15 | LinkedIn | Kofi Anselm**
Day one of Slow Burn Summit in Denver.

The morning session had a customer walk through a containment that went wrong, including the Helm value that caused it. Nobody flinched, which tells you who comes to this event. The hallway conversation afterward was mostly people checking their own values files on their phones.

Tomorrow is all working sessions: labs on contain mode, plus a first look at writing tool-call policies for Wickhold Leashgate (early access). Bring a laptop and a values file you are not proud of. Recordings go out to attendees next week.

**2026-10-13 | LinkedIn | company page**
Ostler Grocers cut open critical misconfigurations by 63% in 90 days across 1,900 nodes with Wickhold Evenburn.

The method was dull on purpose. Work the fix order, close the top exposure path, check for drift, repeat. Evenburn does not make the changes for you, and a store chain in peak season has reasons to go slowly. The team went slowly and kept going.
