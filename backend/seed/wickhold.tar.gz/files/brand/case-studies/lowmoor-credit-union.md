# How Lowmoor Credit Union cut time to contain from 4 hours to 11 minutes

**Customer:** Lowmoor Credit Union
**Environment:** 220 nodes of production Kubernetes
**Product:** Wickhold Quenchline
**Result:** Time to contain fell from 4 hours to 11 minutes

> "Our board used to ask how quickly we could shut something down, and I gave them a range and a lot of caveats. Now I give them a number we measured: 11 minutes."
>
> Hana Brandvold, CISO, Lowmoor Credit Union

## The starting point

Lowmoor Credit Union is a member-owned financial institution with a small security team and a smaller platform team. Over several years it had moved its member-facing services, including online banking and loan applications, onto Kubernetes. The clusters ran well. The process for dealing with a problem inside them hadn't kept up.

When Hana Brandvold's team ran a containment exercise, the clock showed about 4 hours from first alert to a contained workload. Very little of that time was technical. An analyst saw the alert and opened a ticket. The ticket waited for the on-call platform engineer, who then had to work out which workload it referred to. Someone had to approve isolating it, since the team couldn't tell what else depended on it. Only then did anyone type a command.

Regulators and auditors were starting to ask about operational resilience in plain terms, and the board wanted an answer it could understand. Brandvold's team needed a shorter path between seeing a problem and limiting it, without giving a security analyst direct access to production.

## What the team evaluated

The security team set the requirement, and the platform team held the veto. The platform lead's conditions were specific: resource limits on the agent, a tested removal path, and no automatic action on any cluster until the team had read what the tool would have done.

Lowmoor ran Quenchline in observe mode on a non-production cluster first, then on one production cluster. The platform team checked the agent's CPU and memory use on their own nodes before agreeing to go further.

## The rollout

Lowmoor moved in stages over about a quarter.

**Weeks 1 to 4: observe mode.** Quenchline ran across production and logged what it would have done. The security and platform teams met weekly to review those events. Most of the early noise came from a nightly batch job that spawned shells, and the team scoped the policy to account for it.

**Weeks 5 to 8: contain mode, narrowly.** The team turned on two containment actions for a small set of namespaces: isolate a pod's network and freeze a process. They started from the default containment policy and edited it in version control, reviewed by both teams.

**Weeks 9 to 12: wider coverage.** Contain mode reached the remaining member-facing namespaces. Node drain stayed manual. The platform team decided that draining a node should remain a person's decision, and that's still the case today.

The on-call runbook changed too. A containment action now pages the on-call engineer with the workload, the action taken and the reason, along with how to reverse it. The first job at 3am is to read that page and decide whether to keep the containment in place.

## The result

The team reran the same exercise after the rollout. Time to contain fell from 4 hours to 11 minutes across all 220 nodes.

The 11 minutes includes the time for the on-call engineer to review the action and confirm it. The containment itself happens earlier in that window. Lowmoor chose to measure to the point where a person has confirmed the workload is contained, because that's the figure its board cares about.

The change in process mattered as much as the software. The security analyst no longer needs to find the right engineer before anything happens, and the platform team no longer gets a ticket with no workload name on it.

The exercise is now a standing item. Lowmoor repeats it every quarter on a different workload, and the result goes into the report Brandvold gives the board. She has said the repetition matters to her as much as the first result, because a number from one good day is hard to defend to an examiner.

## What Quenchline didn't change

Quenchline limits how far a problem gets. It doesn't find out why a workload was misbehaving, and it doesn't fix the underlying issue. Lowmoor's teams still run a review after each event and still own the fix. Node-level response remains a manual step by their choice, so an event that needs a drain takes longer than 11 minutes.

## Details for the platform team

A few specifics came up often enough that Lowmoor's engineers asked to include them.

Some workloads can't be handled by network isolation. Pods with `hostNetwork: true` are refused, and the refusal shows up in the decision record, so Lowmoor's policies for those pods use a freeze.

Freezes need care around health checks. A frozen container fails its liveness probe, and the kubelet will eventually restart it, which destroys the state the team wanted to keep. Lowmoor's freeze policies set `holdProbes: true`, and the team reviewed which workloads rely on exec probes, since those can't be held.

Policy changes go through the same pull request process as any other cluster change, with one reviewer from security and one from platform. Exemptions are dated, and the two teams review them each month. During observe mode most exemptions were for backup agents and debug sidecars, and very few of those have needed changing since.

## What Lowmoor would tell another credit union

- Leave observe mode on long enough to be bored by it. Four weeks was right for this team.
- Get the platform team to write the policy with you. A policy written by security alone won't get turned on.
- Measure before you start, using a method you can repeat. Without the 4-hour baseline, the 11-minute result wouldn't mean much to the board.

## About Lowmoor Credit Union

Lowmoor Credit Union is a member-owned credit union serving individuals and small businesses.

## About Wickhold

Wickhold is the runtime security company for teams that run Kubernetes. Its products contain failures early, so small fires stay small. Founded in 2019 and based in Denver, Wickhold serves more than 140 customers.
