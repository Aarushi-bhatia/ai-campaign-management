Customer story · Retail · Published May 2026 · Approved for external use

# Ostler Grocers: 63% fewer open critical misconfigurations in 90 days

Ostler Grocers runs 1,900 nodes of Kubernetes, spread across central clusters and small clusters in its stores. Using Wickhold Evenburn, its infrastructure team reduced open critical misconfigurations by 63% in 90 days. Team size stayed the same, and so did the release calendar.

> "We never lacked findings. We lacked an order to fix them in. Evenburn told us which handful sat on a real path to something we care about, so my team stopped arguing and started on those."
>
> Rafe Mulcahy, VP Infrastructure, Ostler Grocers

## A fleet that had drifted

A grocery chain's infrastructure doesn't get quiet weeks to clean up. Ostler's stores depend on services for pricing, stock, pharmacy pickup and loyalty, and those have to keep working through weekend peaks and holiday weeks. Over time the team had built a standard cluster template for stores and rolled it out widely. Then real life happened: a hotfix in one region, a one-off exception for a pilot, a change that was applied by hand during a busy weekend and never went back into Git.

A typical example came from a loyalty service in one region. The template set a read-only root filesystem. An engineer turned it off with `kubectl patch` during a weekend incident to get a debug tool running, and the change stayed. Nobody did anything wrong, and nobody remembered it a month later.

Each change was reasonable on its day. Together they meant that clusters built from one template no longer matched each other or the template. The scanners the team already ran produced a long list of critical findings with no way of telling which ones mattered. Mulcahy's platform engineers picked items off the top of the list between other work, and the count hardly moved. New drift arrived about as fast as old findings closed.

PCI DSS scope added pressure, because a store cluster that had drifted could raise questions about what sat inside the payment environment.

## Why Evenburn

The team wanted to answer two questions it couldn't answer before: what had changed from what we meant to deploy, and which problems can actually be reached?

Evenburn's three concepts mapped onto that directly.

**Drift** showed where running clusters differed from the intended configuration, per cluster and per store.

**Exposure paths** showed which misconfigurations could be reached from somewhere that mattered, such as a store network segment or an internet-facing ingress, and what they led to.

**Fix order** turned that into a sequence. Instead of a long list sorted by severity, the team got a short list of what to fix first, with the reason next to each item.

## Ninety days

### First two weeks

The team connected its clusters and cloud accounts and let Evenburn build a picture of the fleet. Nothing changed in production. The first review was uncomfortable, mainly because of how many store clusters had drifted from the template in the same few ways.

### Weeks three to eight

The team worked through fix order in priority sequence. Most of the highest items traced back to a small number of root causes, so fixing the template and rolling it out closed many findings at once. Where a fix had to wait for a release window, the team recorded an exception with an owner and an end date.

They held a 30-minute review each week, attended by platform and security. Mulcahy credits that meeting with ending the old arguments about severity: the discussion was now about which path to close next.

### Weeks nine to twelve

With the worst paths closed, the team moved on to keeping them closed. Template changes now go through Git only, and drift findings go to the team that owns the region. A store-level hotfix is still allowed, and now it shows up as drift the next day, so somebody decides whether to keep it.

### What the weekly review covered

The agenda fit on an index card, and it stayed the same for the full 90 days:

1. Which exposure paths closed since last week, and did any come back?
2. What's next in fix order, and who owns it?
3. Which items are snoozed, and which snoozes expire this week?
4. Any store or region drifting in a new way?

The third item turned out to matter most. Every snoozed item carried an expiry date, so a deferred fix came back onto the agenda without anyone having to remember it. During the team's busiest trading weeks, the review shrank to items one and three, and fixes waited for the next release window.

## Results

At the end of 90 days, Ostler had 63% fewer open critical misconfigurations across its 1,900 nodes.

The team also reports a change that doesn't come with a number: security and platform now look at one list. Conversations with the payment audit team became easier too, since the team could show where each cluster stood and what had changed.

## What Evenburn didn't do

Evenburn finds drift and exposure paths and puts fixes in order. People at Ostler made every fix, in Ostler's own pipelines and release windows. Evenburn is also a posture product: it reports on configuration, and it doesn't act on a running workload. And 63% fewer doesn't mean zero. The remaining critical items are tracked, many with planned dates tied to store refreshes.

## Who did the work

The project had no dedicated staff. The platform team took the top of fix order as part of its normal sprint work, regional engineers handled store-specific items, and one security engineer ran the weekly review. Ostler's engineers looked at the proposed patch on each item, then changed the template or pipeline to suit their own conventions. Patches in Evenburn are proposals, and at Ostler they all went through the normal review.

Ignore rules got the same attention. Some drift is expected, such as replica counts changed by an autoscaler. Every ignore rule the team added has an author and a reason, so a later reviewer can tell a deliberate choice from a forgotten one.

## Advice from Ostler's team

"Start with a template if you have one," Mulcahy's team says. Fixing the source closed more findings than any amount of work on individual clusters. They also suggest holding the first review with platform and security in one room, since each will otherwise assume the list belongs to the other.

## About Wickhold

Wickhold is the runtime security company for teams that run Kubernetes. Its products contain failures early, so small fires stay small. Founded in 2019 and based in Denver, Wickhold serves more than 140 customers.
