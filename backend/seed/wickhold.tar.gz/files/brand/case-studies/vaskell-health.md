# Three weeks back: how Vaskell Health shortened audit preparation

Customer story | Healthcare | Wickhold Evenburn

Vaskell Health cut audit preparation by three weeks after moving its evidence collection for Kubernetes workloads onto Wickhold Evenburn. For a security team of its size, that's three weeks of engineers back on the work they were hired to do.

> "Audit season used to take over my team's calendar. People spent their days collecting screenshots and chasing engineers for proof that a control was still in place. This year we pulled the evidence from Evenburn and spent that time on the findings that needed attention."
>
> Temi Okereke-Voss, Director of Security, Vaskell Health

## The challenge

Vaskell Health runs clinical and patient-facing applications on Kubernetes, and those systems fall under HIPAA along with a set of customer and partner security reviews. Each audit cycle asked the same kinds of question: show that workloads handling patient data run with the expected controls, show when those controls last changed, and show who approved any exception.

The clusters were reasonably well run. Proving that was the hard part. Evidence lived in several places, and much of it was assembled by hand in the weeks before the auditors arrived. Security engineers exported configuration, took screenshots, and asked platform engineers to confirm whether a given setting was still in force. By the time a spreadsheet was complete, parts of it were out of date.

Okereke-Voss's team could see the cost clearly. For a stretch of every audit cycle, security engineering work stopped. Remediation slipped. Platform engineers resented the interruptions, and nobody felt the end result told the auditors much about how the environment looked on an ordinary day.

## What the team did

Vaskell Health connected Evenburn to its clusters and began by agreeing on a baseline for workloads in audit scope. That meant writing down what the team expected to be true, so that a difference from it would show up as drift and not as a surprise in an audit meeting.

Three things changed.

**Drift replaced the point-in-time snapshot.** Instead of checking settings once a year, the team could see when a workload stopped matching its baseline, along with when it changed and, where the audit log could show it, who changed it.

**Exceptions gained owners and end dates.** Exceptions had been recorded in tickets and in people's memories. Each one now carries a named owner and a date, so the team can show an auditor what was approved and when it ends.

**Fix order set the pre-audit work.** Before the audit window, the team used exposure paths to find which open issues touched in-scope workloads, and it worked those first.

## The result

Audit preparation was cut by three weeks. The security team went into the audit with evidence pulled from Evenburn, and engineers spent far less of that period gathering it by hand. The audit questions themselves didn't get easier, and the team still prepared its narrative and answered follow-up requests in person. The mechanical work is what went away.

[Noor, Sept 22] Holding this one, don't send it to the web team yet. Checked with Priit: Legal has NOT cleared it for external use. Their legal team never signed, so it can't go out with their name, the quote or the result until they do. Copy itself is fine and Temi's team liked the draft. Leaving it here so we don't lose the work.

## How the project ran

The work took place in four steps, with one security engineer leading and a platform engineer part-time.

First, the team installed the cluster collector and granted read-only roles in its cloud accounts. Nothing on the nodes changed, which made it an easy request for the platform team.

Second, it connected Git and Helm history so that drift had a declared source. As expected, a burst of drift appeared at first, because every undocumented hotfix since the clusters were built showed up at once. The team worked through this with cluster owners and wrote ignore rules with reasons for the expected cases.

Third, it tagged the systems in audit scope and agreed on the baseline with the compliance team. This step took the longest.

Fourth, the team generated evidence reports mapped to HIPAA and SOC 2 controls and reviewed them against the previous year's spreadsheets. Where a report and a spreadsheet disagreed, the team checked the live cluster, and the report was right more often than not. That review convinced the team to retire the spreadsheets.

## What Evenburn didn't do

Evenburn gives a security team current evidence on configuration and drift. It doesn't replace an auditor, a compliance program or the policies behind it, and it doesn't make any workload compliant by itself. Vaskell Health's team still decides what the baseline should be and still owns every fix. Evidence for controls outside Kubernetes and cloud configuration stays with the tools that already handled it.

## What changed for the people involved

For security engineers, the weeks before the audit now look much like other weeks. Evidence reports come out of Evenburn when they're needed, and the time goes to reviewing them and to the fixes that matter for in-scope workloads.

For platform engineers, the requests dropped sharply. They used to get asked one setting at a time whether something was still true. Now the security team can see the live value and the declared value, and it comes to them only when the two disagree.

For the compliance team, the main change was timing. Questions that used to surface during the audit window now surface as drift, weeks ahead, while there's still time to do something about them.

## Advice for other healthcare security teams

Okereke-Voss's team offers three pieces of advice.

Agree on the baseline before you connect anything. The technical setup was the short part of the project, and the conversation about what "correct" meant took longer.

Bring the auditors in early. Show them what the evidence will look like before the audit window opens, so that nobody is surprised by the format.

Keep the exceptions honest. An exception with no end date tends to become permanent. Reviewing them each month took little time and made the audit conversation much shorter.

## About Vaskell Health

Vaskell Health is a healthcare organization delivering clinical and patient services across its region.

## About Wickhold

Wickhold is the runtime security company for teams that run Kubernetes. Its products contain failures early, so small fires stay small. Founded in 2019 and based in Denver, Wickhold serves more than 140 customers.
