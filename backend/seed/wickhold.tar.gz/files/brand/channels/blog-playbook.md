# Writing for the Wickhold blog

*Kofi Anselm wrote the first version in May 2026 for the two contractors we brought in after the Containment Report. Noor edited it in July. Send fixes to either of us.*

The blog has one job: get a platform engineer or a security lead to trust that the people here have held the pager. Traffic is a side effect. A post that gets a staff engineer to forward it to their team beats a post that ranks for a keyword and gets skimmed.

## 1. Length

Blog posts run 900 to 1,400 words. That range counts the body, including captions and code comments you wrote yourself, but not the code output you pasted.

Under 900 words, it's probably a release note or a LinkedIn post. Over 1,400 words, split it in two or cut the history section. We all write the history section first because it's easy, and nobody needs it. The report, the docs and the rollout guide are the place for anything longer.

## 2. The intro

A blog intro must cite a market statistic. Put it in the first two sentences, in the citation format from the style guide, and follow it with one sentence that says why this post exists. The rule is there because engineers are more willing to keep reading once they know the problem is measured and someone has measured it honestly.

Statistics are subject to the age limit in the approved claims, so check the date before you reuse an intro from an older post.

Market statistics are figures about the market or a surveyed population. Our own customer results and benchmark numbers belong further down the post, and they don't satisfy this requirement.

Good:

> The median time to contain a runtime incident is 7.4 hours [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]. Most of the teams we talk to can tell you how long detection took. Far fewer can tell you what happened in the hours after. This post is about those hours.

Good:

> 41% of platform teams need more than six hours to contain a runtime incident [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]. A lot of that time goes to one question: who is allowed to touch the workload? Here is how to settle that question before the page goes off.

Bad, because it has no statistic and no reason to read on:

> Kubernetes has changed how modern teams ship software, and with that change come new security challenges.

Bad, because a customer result is doing the job of a market statistic:

> Lowmoor Credit Union cut time to contain from 4 hours to 11 minutes. Here's how your team can get the same results.

## 3. Post types

**Engineering posts.** Written by Dov, Kofi or an engineer with an editor attached. How the eBPF agent attaches, what we learned from a kernel upgrade, why a containment action took longer than it should have. These carry the blog.

**How-to posts.** A task, steps, and what it looks like when it goes wrong: rolling out contain mode, reading an exposure path, writing a first tool-call policy for Leashgate in early access.

**Report posts.** One finding from the Containment Report, argued properly. We get four or five out of each report. Do not summarize the whole report in one post. That's what the report page does.

**Customer posts.** Built from a published case study, with the customer's own words where we have approval. These need Priit's sign-off every time, even when the numbers are already public.

**Founder posts.** Maren, on company decisions and what she learned from them. They're rare and marketing does not ghostwrite them. An editor can tidy.

## 4. Shape of a post

A title that says what the reader will get. Then the intro. Then three to five sections with descriptive headings. Then an ending that tells the reader what to do on Monday.

Titles we liked:

- Contain mode, one namespace at a time
- What drift looks like after a Helm upgrade
- The six hours after detection
- Writing your first tool-call policy for Wickhold Leashgate, in early access

Titles we rewrote:

- "5 Kubernetes Security Mistakes You're Making Right Now" became "Five findings we see in most new clusters"
- "Everything You Need To Know About eBPF" became "What our eBPF agent can and can't see"

Section headings should still make sense if they're all someone reads. "Background" and "The solution" tell the reader nothing.

End on the practical next step, then one call to action to the most relevant page. Don't summarize what you just said. If the post was good, they remember. Don't add a paragraph about Wickhold at the bottom either, as the footer handles that.

## 5. Code and commands

- Every code block must run. An engineer other than the author pastes it into a test cluster before publishing. Kofi keeps a throwaway cluster for this and will give you access.
- State versions at the top of the block or in the sentence before it: Kubernetes, Helm chart, kernel where it matters.
- Show the output when the output is the point, and trim it with a visible `...`.
- Use real-looking names like `payments-api` and `checkout`. Avoid `foo` and `my-app`, and don't use a customer's actual namespace names, even with permission.
- Say what fails. If `helm upgrade` can leave the agent in `CrashLoopBackOff` on an old kernel, put that in the post.

```bash
# Good: what you ran, and what to look for
kubectl get pods -n payments-api -o wide
# ...
# payments-api-6f9c7d   0/1   Terminating   0   3m   10.2.4.17   node-a
# A pod stuck here after a drain usually has a finalizer. Check that first.
```

## 6. Review

| Step | Who | When |
|---|---|---|
| Outline | Editor (Kofi for engineering posts, Noor for the rest) | Before anyone writes 1,000 words |
| Technical read | An engineer who did not write it | Draft complete |
| Copy edit | Brand team | After the technical read |
| Claims check | Priit, for any customer, certification or number, except third-party statistics under section 5 of the approved claims | As the approved claims set out |
| Paste test | Second engineer, code posts only | Day before publish |

Allow two weeks from outline to publish. Report posts in April move faster because Legal has already checked the numbers.

## 7. Publishing details

- URL slug: lowercase, under 60 characters, no dates.
- Meta description: one plain sentence, under 155 characters.
- Author byline is always a real person. We retired "The Wickhold Team" as a byline in 2025 when we noticed those posts got half the reads.
- Hero images come from the design team. Send the request with your outline, not the day before.
- Tuesdays and Wednesdays. Never the same day as a release note, since they compete in the newsletter.

## 8. Working with engineers who don't want to write

Most of our best material is in the heads of people who would rather fix a kernel bug. Don't send them a blank doc. Book 30 minutes, ask them to walk you through the last hard thing they fixed, and record it with their permission. Write the draft from the recording and send it back for correction. An engineer who won't write 1,000 words will happily rewrite the 200 you got wrong.

Keep their phrasing where you can. If someone says the agent "falls over politely" on a read-only kernel, that goes in. Their name goes on the post, and they read the final version before it goes live. If they ask to take something out, take it out, and don't argue about it in the review thread.

Questions that tend to produce a post:

- What did you assume about this before you got paged?
- What's the command you wish you had run first?
- What does the failure look like from the outside?
- What did you change afterward, and did it hold?

## 9. Updating old posts

Older posts stay up, but they can mislead. The brand team runs through the top 30 posts by traffic every quarter. Each gets one of three outcomes: leave it, edit it in place with an "Updated" date at the top, or redirect it to a newer post.

Edit in place when a product name, a command or a figure has gone out of date. Redirect when the advice has changed. Never quietly change a claim. If a post said something that turned out to be wrong, add a line saying what changed and when. Engineers notice, and they remember how you handled it.

## 10. Tried and dropped

Guest posts from partners took more editing than writing one ourselves, and the partners wanted a link in every paragraph. Weekly "news roundups" lasted nine weeks in 2025 and nobody missed them. Keyword-led briefs from an agency produced the "Everything You Need To Know" titles above, and we stopped that contract in the spring.
