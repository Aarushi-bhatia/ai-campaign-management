# Email playbook

Owner: Ilse Varga-Holm's team (lifecycle). Rewritten for the March 2026 platform migration, revised September 2026.

## The short version

| Thing | Limit |
|---|---|
| Email length | 220 words at most, body text, including the sign-off |
| Subject line | 48 characters at most, counted with spaces |
| Links | One main action. More links are fine in a newsletter, and a second link is fine in a customer notice |
| Sends per contact | Two marketing sends a week at most, customer notices excluded |

The 48-character limit comes from the phone inbox preview, where the back half of a longer subject gets cut. We pulled a sample of opens in early 2026 and most were on phones, so the preview is the version people actually read.

## What we send

**Monthly newsletter.** Goes to everyone opted in, second Tuesday of the month. One lead item, three short items, nothing about us that we wouldn't want to read ourselves. Engineers are the bulk of this list, so it can carry a command or a config snippet.

**Nurture tracks.** Separate tracks for CISOs and platform leads, triggered by report downloads and demo requests. Four to six emails over about six weeks. Sales gets an alert on replies. If a contact opens a sales conversation, the track stops.

**Product announcements.** Goes to customers first, prospects a day later. New capabilities, deprecations, and anything that changes how a customer's agents behave. Deprecations go out at least 60 days ahead.

**Customer notices.** Security advisories, CVE guidance, scheduled maintenance. These bypass frequency caps and unsubscribe groups. Dov or a named engineer signs. Marketing can edit for clarity but never holds one back for scheduling reasons.

**Event email.** Slow Burn Summit and Field Day invites and reminders. The events team writes, lifecycle sends.

**Founder notes.** Maren writes to customers about twice a year, usually around pricing or product direction. It comes from her address. A reply goes to her, and she reads them.

## Subject lines

Say the content. People decide in about a second, on a phone, in a queue of other things.

Good:

- `Containment Report 2026: where the hours go` (43)
- `Containment Report 2026 is out` (30)
- `Wickhold Quenchline October release notes` (41)
- `Field Day is coming to your city` (32)
- `Wickhold Evenburn: reading an exposure path` (43)
- `CVE note: what to check in your clusters` (40)

Bad, cut off in the preview:

- `Everything your platform team needs to know about runtime containment this quarter`
- `Join us for an exclusive conversation on the future of Kubernetes security`

Bad, vague:

- `A quick update`
- `Thought you'd want to see this`
- `Big news from Wickhold`

Don't use the recipient's company name in a subject. It looked clever for one quarter and then started to look like a phishing test, which is a poor impression for a security vendor. For the same reason avoid `Re:` and `Fwd:` tricks, urgency words and all caps. Security teams train people to distrust that kind of thing, and a share of our list has mail filters tuned to catch it.

## Body

Most of our email has three parts.

1. **What happened or what's new.** One or two sentences.
2. **Why it matters to this reader.** Two to four sentences. Different for a CISO list and a platform list, which is why the tracks are separate.
3. **What to do.** One button or link. Then the sign-off.

The working drafts are in the email templates, and the merge fields there match the sending platform. Start from a template. A blank page tends to produce an email that's 400 words long.

Good body copy, platform track:

> You downloaded the Containment Report, so here's the practical follow-up. Our rollout guide starts with Wickhold Quenchline in observe mode on one namespace, then moves to contain mode once you've read two to four weeks of would-have-acted events.
>
> It takes about an hour, and the failure modes are listed at the end.

Good body copy, CISO track:

> Decide whether your team tracks time to contain today. Your board will ask how long a runtime incident takes to contain. In our survey of 412 platform and security leaders, the median time to contain a runtime incident is 7.4 hours [Wickhold Containment Report, 2026, https://wickhold.example/containment-report].
>
> The report sets out how teams measure that number and what they report upward. If your team doesn't track it, section two is a place to start.

Bad body copy:

> Hope you're having a great week! As a valued member of our community, we wanted to reach out and share some exciting content we think you'll love. In today's rapidly evolving threat landscape, security has never been more important.

Four sentences in and the reader has learned nothing. Cut until the first sentence is the news.

Personalization: first name in the greeting when we have it, and role-based copy through segments. Anything else, like company size, industry or recent page views, stays out of the visible copy. Being told what you browsed by a security company is unsettling.

## Plain text

Every send has a plain-text version, and we check it. Many of our engineers read mail in clients that don't render HTML, or that block images by default. An email must make sense with every image off. Button text must appear as a readable link in the plain-text part, not as `https://wickhold.example/t/8fa3c...` alone.

For the rules on header images, see the visual guidelines.

## Sender and footer

- Default from name: `Wickhold`, from `hello@wickhold.example`. Replies go to a monitored queue.
- Newsletter from name: `Kofi at Wickhold`.
- Founder notes: `Maren Tolliver`, from `maren@wickhold.example`.
- Customer notices: `Wickhold Customer Notices`, from `notices@wickhold.example`.
- Footer carries the legal entity, Wickhold, Inc., a Denver postal address and the unsubscribe link.

## Lists and segments

| Segment | Who | Tone in one line | Usual sends |
|---|---|---|---|
| Platform | Platform engineers, SREs, DevSecOps | Practical, can carry code | Newsletter, platform nurture, product announcements |
| Security leadership | CISOs, security directors | Short and plain | CISO nurture, report, Summit invite |
| Customers, technical | Named admins and on-call contacts | Facts and steps | Product announcements, customer notices |
| Customers, executive | Sponsors on the account | Short, rarely | Founder notes, Summit invite |
| Event-local | Contacts within driving distance of a Field Day | Friendly, practical | Field Day invite and reminder |

Role tags come from enrichment and are wrong about one time in ten. If a reply says "I'm not a CISO", fix the contact on the day. Never merge the platform and security leadership lists to reach a volume target. We did that for the 2025 report and the CISO list's unsubscribe rate doubled in a single send.

## Timing

Tuesday to Thursday, 9 to 11am in the recipient's time zone where the platform knows it. Customer notices go when they're ready, at any hour. Avoid the last week of a quarter for prospect sends, because sales wants clean inboxes for their own outreach, and avoid the week of the big cloud-native conference in November unless the send is about the conference.

If a customer notice is going out, hold marketing sends to the affected accounts for 48 hours. Nobody wants a newsletter in the same hour as a CVE note. Lifecycle owns the pause, and the on-call engineer writing the notice tells them in the channel.

## Deliverability

A security vendor's mail gets scanned hard, and a lot of it lands in quarantine. Keep the sending domain authenticated, and check with IT before anyone adds a new sending tool. Avoid link shorteners. Don't attach files. Link to the page instead, as PDFs from vendors are often stripped at the gateway. Contacts with no opens in a year go to the re-engagement note, and if they don't respond, off the list.

## Testing and approvals

Test one thing per send, on lists over about 5,000 contacts. Subject lines first, send time second. We no longer test emoji, since they lost every round in 2025.

Before anything goes out:

1. Send a proof to the seed list, which covers phone, desktop and text-only clients.
2. Click every link. Check that the UTM tags are in place.
3. Check word count and subject length.
4. Lifecycle reviews. Noor reviews any new template or any new claim.
5. Priit reviews customer names, new numbers, and anything about certifications.

Suppressions: exclude open opportunities from nurture, exclude churned customers from product mail, and always exclude contacts on the do-not-contact list that sales keeps. Lists are pulled the morning of the send, not the night before.

## What didn't work

- Fortnightly newsletter. Unsubscribes rose and we had nothing to say on the off weeks.
- "Webinar replay" emails after every webinar. Replaced by one line in the newsletter.
- A six-email welcome series. Most people stopped opening at the third. Now three emails.
