# Landing pages

**Noor Eskelund and the web team, April 2026.** Written the week the Containment Report page went live, while the mistakes were fresh. Revised May 2026.

This covers campaign pages, product pages, persona pages and report pages on wickhold.example. The docs site and the blog have their own conventions.

## Hard limit

A landing page is 500 words at most. That counts every word a visitor can read on the page: headline, subheads, body, proof, form labels and the FAQ. Navigation and the site footer don't count.

If the page runs over, cut sections. Don't shrink the type or tuck copy into tabs and accordions. It still counts, and the page is still doing too many things. Long-form material belongs in the report, a blog post or the docs, and the page links there.

## Every page has one job

Before anyone writes copy, the brief answers three things.

- Who lands here, and from where (paid search, a nurture email, a Field Day QR code)
- What they should do next
- What proof they need to do it

A page aimed at both a CISO and a platform engineer ends up serving neither. We build two pages and route by campaign. The rollout guide page for engineers shows commands and flags above the fold. The executive page for the same product leads with what the decision is and what it costs in time.

## Page skeleton and word budget

| Section | Budget (words) | Notes |
|---|---|---|
| Hero: headline, one sentence, CTA | 40 | Must make sense with no scrolling |
| Proof strip: customer logos or one number | 25 | One row, no carousel |
| What it does: three blocks at most | 150 | Concrete actions, not themes |
| How it works or how you roll it out | 100 | Steps. Commands if the audience is technical |
| Customer proof: one result, one quote | 70 | A full sentence with the number and the source |
| FAQ: three questions at most | 80 | Real questions from sales calls |
| Closing CTA | 15 | Same action as the hero |
| **Total** | **480** | Leaves 20 words of slack |

CTAs follow the shared CTA format in the email templates. Use one primary CTA per page, repeated at the top and bottom with the same wording. A secondary link is allowed for a technical reader who is not ready for a form, like the docs or the rollout guide.

## Hero copy

The hero says what the product does and who it's for, in that order. Lead with what happens to the reader's workload. Our tagline can sit in the hero of the brand page, but it doesn't describe a product, so product pages shouldn't rely on it.

Good, product page:

> **Contain runtime failures before they spread**
> Wickhold Quenchline detects bad behavior in Kubernetes and isolates a pod, freezes a process or drains a node, under the policy you set.
> [Book a demo]

Good, posture page:

> **Know which misconfiguration to fix first**
> Wickhold Evenburn tracks drift across cloud and cluster, finds each exposure path and gives your team a fix order.
> [See a sample report]

Good, early access page:

> **Set policy for what AI agents can call**
> Wickhold Leashgate, in early access, applies tool-call policy at runtime and limits what a compromised agent can do.
> [Request early access]

Good, report page:

> **The Wickhold Containment Report 2026**
> A survey of 412 platform and security leaders on how long containment takes, and where the hours go.
> [Read the report]

Good, brand page:

> **Small fires stay small.**
> Wickhold is the runtime security company for teams that run Kubernetes.
> [See how it works]

Bad, from a 2025 agency concept:

> **Next-level cloud security for the modern enterprise**
> One powerful platform. Total confidence. Peace of mind at every layer of your stack.

Nothing in that hero says what the software does. It would fit a mattress company if you swapped "stack" for "bed".

## Proof

Each number sits with its source in the same block, so nobody has to scroll to a footnote to check it. These are approved as written:

- Lowmoor Credit Union, 220 nodes: time to contain fell from 4 hours to 11 minutes.
- Ostler Grocers, 1,900 nodes: 63% fewer open critical misconfigurations in 90 days.
- Under 2% CPU overhead on a typical node in Wickhold lab benchmarks, 2026.

Don't round them, combine them or place two customers' numbers in one sentence. One page gets one customer story. Stacking every number we have makes the page feel like a pitch deck, and readers trust a single detailed result more.

## How-it-works blocks

This is where the two audiences differ most. For engineers, show the thing itself. A short command block costs few words and earns more trust than a paragraph:

> **Install in observe mode**
> `helm install quenchline wickhold/quenchline --set agent.mode=observe`
> The agent attaches to each node. Nothing is contained until you change the mode.

For security leaders, give steps in terms of time and ownership:

> **Week one:** Quenchline runs in observe mode on one cluster.
> **Weeks two to four:** Your team reviews what it would have done.
> **After week four:** You decide which namespaces move to contain mode.

Both describe the same rollout. Neither should use a diagram that needs a paragraph to explain it.

## FAQ

Pull questions from sales calls, not from what we wish people asked. Answer in two sentences or fewer. A good FAQ answers the objection that would otherwise stop the form.

> **Will this take down production?**
> In observe mode, Wickhold Quenchline takes no action. You choose when and where contain mode starts.

> **How much overhead does the agent add?**
> Under 2% CPU overhead on a typical node in Wickhold lab benchmarks, 2026.

## Matching the ad

Paid pages must repeat the promise of the ad that sent the visitor there, in nearly the same words. If the ad says "fix order for misconfigurations", the headline says it too. Demand gen writes the ad and the hero together, in the same doc, so they don't drift. We clone a page per ad group only when the message differs. One page per keyword produced 60 near-identical pages in 2025, and the web team spent a month consolidating them.

## Forms

- Report pages are ungated as of April 2026. We ran the 2025 report behind a form and sales complained about lead quality for months.
- Demo forms: work email, company, cluster count. Three fields. We tested five, and completions dropped enough that nobody wanted a second test.
- Don't ask for job title. Enrichment handles it.
- The thank-you page tells people exactly what happens next and when. "A solutions engineer will reply within one business day" is what we can actually keep.

## Pricing on pages

Product pages link to the pricing page and don't repeat its contents. Tiers change, and the pages that repeat them never get updated. Paid-search pages for pricing queries can show a short tier summary pulled from the pricing page, reviewed by Priit before launch.

## Build and review

1. Brief, with Noor's OK on audience and goal.
2. Copy in a shared doc with a word count at the top. Over 500 goes back.
3. Claims check by Priit, with sources pasted next to each claim.
4. Design and build. Web team needs five business days for a new layout and two for an existing one.
5. Staging review on a phone first. Most paid traffic arrives there.
6. Launch, then a check at two weeks: is anyone completing the form, and where do they drop off?

Use the existing layouts when you can. We have three (product, campaign and report) and each has been tested for load speed and for the mobile form. A page built from scratch needs a reason, and "it's a special campaign" isn't one.

## Old pages

Any page without traffic for six months gets redirected. Campaign pages get an end date at launch. In the 2026 rebrand cleanup, the web team found pages from 2023 still live and indexed, which is how you end up with a stale claim ranking above the current one. Put the end date in the brief.
