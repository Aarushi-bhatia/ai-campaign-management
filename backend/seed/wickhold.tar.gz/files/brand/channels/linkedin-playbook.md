# LinkedIn playbook

Noor Eskelund. Last edit 12 August 2026, after the Leashgate early access posts. Ask in the brand channel before you ask me by email.

LinkedIn is the one channel where CISOs, platform leads and our own hiring pipeline all look at the same feed. Most of what we post there is read on a phone, between meetings, by someone who has never heard of us. Write for that person.

## Who posts

**Company page.** Marketing runs it. Two or three posts a week, Tuesday to Thursday, usually mid-morning Mountain time. Fridays stayed on the calendar through most of 2025 and did nothing, so they came off.

**Maren and Dov.** They post from their own profiles when they have something to say. Marketing can draft, but they rewrite. Do not schedule on their behalf without a yes in writing, and do not reply to comments as them. If a draft of Maren's has been sitting for two weeks, drop it. She has decided.

**Kofi and the DevRel team.** Kofi posts from his own profile about conference talks, open-source eBPF work and whatever broke in the demo cluster. He does not need brand review for those unless a post carries a customer name, a product claim or a number.

**Everyone else.** People can share company posts however they like. We ran an employee amplification program in 2025 with a shared doc of suggested captions. Forty people posted the same sentence on the same morning and it looked exactly like that. We stopped.

## Format

- A LinkedIn post is 180 words at most. Count everything, including the link line.
- About the first 200 characters show before the "see more" cut on most phones. The news has to fit in that space.
- Short paragraphs, one to three lines each, with a blank line between them.
- One link per post, at the end, on its own line. We tested putting links in the first comment for six weeks in 2025 and could not see a difference, and it annoyed people, so links stay in the post.
- Tag a customer only after their marketing contact has seen the post. Tag people, not company pages, when a named person spoke or wrote the thing.
- Use bullets only for real lists: three containment actions, the tiers, the steps of a rollout. A post that is all bullets reads as a slide.
- Image guidance sits with the visual rules. Every company page post gets one image, except short hiring notes.

## Structure

Most company posts follow the same order.

1. **The fact.** What shipped, what was measured, what happened. Put the number here if there is one.
2. **The context.** Two or three sentences on why it matters to someone running clusters or answering for them.
3. **The way out.** One link, with a short instruction in front of it.

Then stop. If you have a second point, it is a second post next week.

## Examples

Good, report post:

> 41% of platform teams need more than six hours to contain a runtime incident [Wickhold Containment Report, 2026, https://wickhold.example/containment-report].
>
> That figure comes from the Wickhold Containment Report 2026, our survey of 412 platform and security leaders. The median time to contain a runtime incident is 7.4 hours [Wickhold Containment Report, 2026, https://wickhold.example/containment-report].
>
> 7.4 hours is most of an on-call shift, spent on one problem while everything else waits.
>
> Read the report: https://wickhold.example/containment-report

Good, customer post. The numbers are approved and the post leaves them alone:

> Lowmoor Credit Union runs Wickhold Quenchline across 220 nodes. Time to contain fell from 4 hours to 11 minutes.
>
> Quenchline is our runtime detection and containment product for Kubernetes. It uses an eBPF agent to isolate a pod's network, freeze a process or drain a node.
>
> Read the Lowmoor story: https://wickhold.example/customers/lowmoor

Good, product post:

> Wickhold Quenchline contains a known-bad process in a median of 38 seconds in Wickhold lab benchmarks, 2026.
>
> Lab conditions are kinder than your cluster on a bad night, so start in observe mode and read what it would have done. Then pick the namespaces where contain mode earns its place.
>
> See the rollout guide: https://wickhold.example/docs/rollout

Good, posture post:

> Ostler Grocers cut open critical misconfigurations by 63% in 90 days, across 1,900 nodes.
>
> Wickhold Evenburn tracks drift across cloud and cluster, maps each exposure path, and gives the team a fix order for Monday morning.
>
> Read the Ostler story: https://wickhold.example/customers/ostler

Good openers for founder posts. Only the first lines are shown here because Maren and Dov write the rest themselves:

> The worst page I ever took was for a disk that had filled up with logs about a disk filling up.

> I spent four years on call before we started this company, and I still check my phone at 3:10am.

Bad, from a 2024 draft that came back to the queue last spring:

> We're thrilled to announce an exciting new chapter in our journey! Our amazing team has been working around the clock to bring you the future of cloud security. Stay tuned, big things are coming!

Nothing happened in that post. No product, no date, no number, and a reader who stops at the cut has learned only that we are thrilled.

Bad, the post with too many jobs:

> Our report is out, we're hiring in Denver, Slow Burn Summit registration is open, and Wickhold Evenburn has a new fix order view. Links in the comments.

That is four posts. Pick the one with a deadline.

## Review

| Post contains | Who approves | Turnaround |
|---|---|---|
| No claims, no customers (hiring, event logistics) | Anyone on the brand team | Two business days |
| Product claim from the approved list | Noor | Two business days |
| Customer name or result | Noor and Priit Salonen, plus the customer's contact if we tag them | Five business days |
| Any number we haven't published before, except third-party statistics under section 5 of the approved claims | Priit Salonen | Two business days |

## Comments and DMs

Reply to real questions within one business day, from the company page, in the same plain voice. Sales inquiries go to the sales queue by DM link. Leave vendor pitches alone. If someone corrects a fact and they're right, say so and fix the post.

## Things we tried

Polls brought a lot of votes from people outside our audience and no replies worth reading. Dropped in late 2025.

Document posts and carousels are off the plan. Swipes fell away after the third page.

Paid boosting is decided per post by demand gen. A boosted post goes through the same review as paid copy, even when it started life as an organic one.
