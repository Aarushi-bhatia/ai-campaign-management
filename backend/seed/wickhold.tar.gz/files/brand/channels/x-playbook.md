X playbook
==========

Kofi Anselm / DevRel. Written June 2026 when marketing handed the account over to us. Short on purpose.

The audience on X is platform engineers, SREs and the people who maintain the projects we depend on. Nobody on there is shopping. They follow accounts that post useful things and are funny about once a week.

**Length.** An X post from any Wickhold account is 240 characters at most. The platform allows more. We stop at 240 so a post can be quoted with a comment and still read whole, and because anything longer is usually two thoughts. Count the raw text, including the link as typed.

**Who has the password.** DevRel owns the main account. Marketing queues launch posts and report posts; DevRel reviews them. Noor can pull anything at any time. Two-factor is on the shared vault, and nobody posts from a personal phone without it.

**What goes out**

- Release notes in one line, with a link
- Findings from the Containment Report, one figure per post
- Practical tips: an eBPF gotcha, a kubectl one-liner, something odd about containerd
- Clips from Slow Burn Summit talks and Field Day
- CVE notes when a CVE touches something we ship or something our customers run a lot of, with facts and the fix

About three to five posts a week. More during Summit, fewer in December. Nothing goes out just to fill a slot in the calendar.

**What a good post looks like**

One thought. A concrete noun in the first few words. If there is a link, it comes last.

Good:

> Wickhold Quenchline can drain a node for you if your policy says so. It will not write the postmortem.

> 41% of platform teams need more than six hours to contain a runtime incident [Wickhold Containment Report, 2026, https://wickhold.example/containment-report].

> Tip: run contain mode on one namespace first. Observe mode tells you what would have happened. Contain mode tells you who in that namespace forgot to mention a sidecar.

> The median time to contain a runtime incident is 7.4 hours [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]. That is one whole on-call shift, plus a sandwich.

> Wickhold Evenburn's fix order will not make the list shorter. It will tell you which line to start on.

> Wickhold Leashgate, in early access: tool-call policy for AI agents, with agent identity on every call. It limits what a compromised agent can do. Request access: https://wickhold.example/leashgate

Bad, too long and too many ideas:

> Runtime security is more important than ever as Kubernetes adoption accelerates, which is why we're excited to share that our platform gives teams everything they need across detection, posture and policy, all in one place, and we'd love to show you how it works.

Bad, reads like an ad that wandered onto the timeline:

> Is your cluster safe? Book a demo today and see the difference.

**Threads.** Four posts at most, each one under the same 240 limit, and each one has to stand alone because people will only ever see one. Threads are for walkthroughs: how a pod gets isolated, what shows up in the audit log, what happens when the agent restarts. If a thread wants to be longer, it's a blog post, and the thread links to it.

**Replies.** Answer technical questions fast and link to docs rather than pasting paragraphs. Keep support issues out of public replies: ask for a ticket number and take it to the support queue. Don't argue with anyone about eBPF versus sidecars. It has never once ended well.

**Humor.** Dry, about the work, at our own expense or at the expense of YAML. Never at the expense of a person or a team having a bad day.

**Dropped.** We ran a "Friday failure" series in spring 2026 where engineers sent in their worst outage stories. Good engagement, but it took hours of editing each week to remove anything identifying, so it ended after five rounds. If a Field Day produces a good story and the teller says yes, post it as a one-off.

**Scheduling.** Launch posts are scheduled. Everything else is posted live by whoever is on the DevRel rota, because scheduled tips have a way of going out in the middle of someone else's bad news. If something big is happening in the industry, pause the queue and ask Kofi.
