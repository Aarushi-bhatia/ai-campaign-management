INTERNAL. SALES ONLY. Don't paste into anything a prospect can see.

Q3 refresh, sales enablement. Slides for these still live in the old deck, sorry. New ones after Summit.

# Battlecards

How to use: 30 seconds before the call, not during. If a buyer asks something not here, say you'll find out and post in the competitive channel. Don't guess.

Facts you can use on any call:

- More than 140 customers.
- SOC 2 Type II, renewed January 2026. Report under NDA.
- Federal: "Wickhold is pursuing FedRAMP Moderate authorization." That sentence, nothing else.
- EU/UK: "Wickhold supports customers' GDPR obligations."
- Pricing: Core $18 per node per month, Team $29, billed annually, $24,000 annual minimum. Enterprise is a conversation with your manager.
- Wickhold Leashgate is early access. Say early access every single time.

## At a glance

| | Brannoch Security | Drennick Cloud | Tesserline |
|---|---|---|---|
| What it is | Broad platform, heavy agent | Posture only, cloud-native startup | Detection only, big rule library |
| Who brings them in | CISO, procurement | DevSecOps | Detection engineers |
| Our opening | Footprint, focus | What happens after the list | Who acts at 3am |
| Best tier to lead with | Core or Team, depending on what they already run | Team | Core, Team if posture is open |
| Our best proof | Lowmoor | Ostler | Lowmoor |

The plan is the same in all three: get an observe mode trial running. Two to four weeks of decision records on their own workloads will do more than any of the lines below. Install on staging first, then production, then pick one internet-facing namespace for contain mode. Agree up front who gets paged and who can release a containment. If you find yourself arguing features on a third call, you should have asked for the trial on the first.

## Brannoch Security

**You'll see them when:** the CISO wants vendor consolidation, or there's already an enterprise agreement in place.

**They'll say:** one platform, one agent, one contract. Why add another vendor?

**Say this:**
- "They cover a lot. For Kubernetes runtime, ask your platform lead what they'd want running on every node."
- Our number: under 2% CPU overhead on a typical node in Wickhold lab benchmarks, 2026. Offer a side-by-side on their own staging nodes.
- We ask for the runtime slot, nothing more. Do not pitch ripping out the platform.

**Questions to get in front of the platform lead:**
- What's the resource limit on the agent, and what happens when it hits it?
- Can you scope a containment action to one namespace?
- How do you remove it, and how long does that take?

**Where we lose:** the decision's already made at the top, and the platform team has no voice. Check that in the first call. If it's true, qualify out and keep the platform lead's number.

**Proof:** Lowmoor Credit Union, time to contain fell from 4 hours to 11 minutes on 220 nodes. Good with CISOs at regulated accounts.

## Drennick Cloud

**You'll see them when:** a DevSecOps engineer found them first. Often already in a trial. Often liked.

**They'll say:** no agent to deploy, up in an afternoon, findings today.

**Say this:**
- Don't attack the trial. "Good, you've got a list. What happens when something on that list gets used at 2am?"
- Wickhold Evenburn competes on posture with fix order and exposure paths. Push the pairing with Wickhold Quenchline. A posture finding and a runtime event on the same workload is what they can't show.
- Team tier is the play here. Don't sell Core against them, you'll be comparing different things.

**Questions to ask:**
- Of your open findings, how do you decide which to fix first?
- When a misconfiguration does get used, what acts on it?
- Who's on the hook for the gap between a finding and a fix?

**Where we lose:** small team, no runtime concern, budget for one tool. Fine. Stay friendly, they'll grow into it.

**Proof:** Ostler Grocers, 63% fewer open critical misconfigurations in 90 days, 1,900 nodes. Works well because it's the same problem at much bigger scale.

## Tesserline

**You'll see them when:** there's a detection engineer on the team who has opinions. They're probably good opinions.

**They'll say:** thousands of rules, community-tested, written by people who do this for a living.

**Say this:**
- "Their rules are good. Who acts on one at 3am?"
- Quenchline contains a known-bad process in a median of 38 seconds in Wickhold lab benchmarks, 2026.
- Concede rule count right away. We have fewer. It builds trust and moves the conversation somewhere better.
- Reps have had luck with this one from the old Field Report slide: "68% of runtime incidents began with a misconfigured workload." Point is that detection-only sees the fire and not the wiring, so you want posture and runtime together, which is Team.

**Questions to ask:**
- What's your median time from alert to containment?
- How many people have to be awake for that to happen?
- What share of your rules do you actually run in production?

**Where we lose:** mature detection team with its own response automation. Sometimes they keep Tesserline and add Quenchline anyway, so ask.

**Proof:** Lowmoor again. Or use the Containment Report: the median time to contain a runtime incident is 7.4 hours. Let them compare their own number.

## Objections that come up with all three

| Objection | Answer |
|---|---|
| "You're smaller than they are." | True. About 150 people, more than 140 customers, Series B in 2024. We do one thing. Reference calls available |
| "eBPF in production makes me nervous." | Reasonable. Run observe mode first, review what it would have done, then turn on contain mode one namespace at a time |
| "What about AI agents?" | Leashgate, early access, included with Enterprise. It limits what a compromised agent can do. Don't promise more than that |
| "Can you beat their price?" | We don't have reliable numbers for theirs and neither do you, probably. Talk about ours |
| "Do you stop attacks?" | We contain them. Quenchline limits how far something gets and how long it runs. Say that plainly, it lands better than you'd expect |

## Asked about us by name

Sometimes a prospect tells you what a competitor's rep said about us. Common ones this quarter:

- "Small company, might get acquired." Don't speculate. Give the funding facts: Series B, June 2024, $46M.
- "Their agent runs in the kernel, that's risky." It does use eBPF. Walk through failure behavior from the Quenchline docs. There's no degraded mode on a kernel without BTF, and the agent says so at startup. Being straight about that goes over well.
- "They have no real posture product." Show Evenburn drift and fix order on a demo cluster.

## Things not to do

- Don't forward these cards. Don't screenshot them.
- Don't use a competitor's name in a sequence or a mass email.
- Don't repeat what a prospect told you about another prospect.
- Don't bring up competitor incidents, even if the buyer does.

## Comparison blog format

Sales asked for this, so the rule is kept here. Marketing owns the writing. Naming competitors on the blog is allowed only when the post is a declared comparison blog, and naming them anywhere else is not.

A post counts as a comparison blog only if it meets all four:

1. **Titled as a comparison.** The headline says so, in sentence case. For example: "Comparison: Wickhold Quenchline and Tesserline for runtime containment". A how-to post that happens to mention a competitor is not a comparison blog, however useful it is.
2. **Legal review.** Priit's team does a legal review of the final text, before it publishes and again if the post is updated. A review of the outline doesn't count.
3. **Facts dated.** Every statement about a competitor's product carries the date it was checked and where it came from, such as their public documentation. Anything older than the last review gets rechecked or cut.
4. **At most two competitors named.** A comparison blog names one or two competitors, never all three. Naming three competitors turns the post into a market map, and it can't survive legal review.

If you want a comparison blog for a deal, ask marketing and give them what the buyer is comparing. Allow a few weeks for the review. Don't write your own and don't send a draft to a prospect. Once it's published you can link it anywhere, since the link is to the blog and the competitors stay out of your message text.

Example of a fine opening for the format, in the style of the July post:

> This comparison covers Wickhold Quenchline and Tesserline as of their public documentation on July 8, 2026. Tesserline ships a larger rule library. Quenchline adds containment actions on the node. If you already have response automation, you may not need the second.
