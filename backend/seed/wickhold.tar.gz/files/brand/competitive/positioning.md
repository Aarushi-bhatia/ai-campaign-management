# Competitive positioning

Maintained by product marketing, reviewed by Priit Salonen before each revision goes out. This version: July 2026. Questions to Ilse Varga-Holm.

Use this for how we talk about the market and the three companies we meet most often. Sales gets the detailed talk tracks elsewhere. This document covers what we believe and what we're willing to say about it.

## 1. Where we sit

Wickhold is the runtime security company for teams that run Kubernetes. The buyer's question we answer is what happens in the minutes after something goes wrong in a cluster, and how far it gets before a person is awake.

Most of the market answers a different question. Posture tools tell a team what could go wrong. Detection tools tell a team what is going wrong. Broad platforms promise to do all of it from one console. We meet each of those in deals, and each has honest strengths.

Our position in one line, for internal use: **Wickhold contains runtime failures early, on the node, with an agent a platform team will accept.**

Three parts of that line carry the weight.

- *Contains.* Containment actions are what we sell: isolate a pod's network, freeze a process, drain a node. Everyone can raise an alert.
- *On the node.* Wickhold Quenchline acts where the workload runs, through an eBPF agent, without waiting for a ticket to cross two org charts.
- *An agent a platform team will accept.* The platform lead has a veto, and overhead, removal and failure behavior decide that vote.

Wickhold Evenburn supports the same position from the other side: it works out which exposure paths to close first so there are fewer things to contain. We sell the pair on Team because the two share workload context. We don't pretend Evenburn is the widest posture product available.

Wickhold Leashgate is in early access and stays out of competitive positioning for now. None of the three has been a factor in an early access account so far, and we don't want a roadmap conversation dressed up as a comparison. If a buyer brings up AI agents in a competitive deal, label it early access and hand the question to product.

What we don't claim: to be a platform, to cover endpoint, identity or email, or to have the most detections. A competitive argument built on any of those loses, and it costs us with the platform lead when it does.

## 2. The market frame we want

When a buyer describes this market, we want them to sort vendors by what happens after detection. That framing helps us, and it's also the question they'll care about at 3am.

Useful framing questions to raise in any conversation, none of which needs a vendor's name:

- When something fires, who or what acts first, and how long does that take?
- What does the tool cost on each node, and how do you measure that yourself?
- If the tool is wrong, what's the blast radius?
- What does it do when it fails?

The market context we can cite: the median time to contain a runtime incident is 7.4 hours, and 41% of platform teams need more than six hours to contain a runtime incident [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]. Both are from our own survey of 412 platform and security leaders, so say that.

## 3. Brannoch Security

**What they are:** a broad platform with a heavy agent. Many capabilities under one contract. Strong relationships with security leadership, particularly at large enterprises.

**Where they're strong:** consolidation. A CISO who wants fewer vendors has a real reason to like them. Procurement often does too. They have breadth we won't match, and we shouldn't try.

**Where we differ:** focus and footprint. We do Kubernetes runtime, and our agent is something a platform team can measure and remove. Our overhead figure is under 2% CPU overhead on a typical node in Wickhold lab benchmarks, 2026. Invite the buyer to measure both products on their own nodes, because the comparison is more convincing when they run it.

**How to talk about it:** lean on specialization. Say what we do and let the platform lead make the footprint argument. They usually already have an opinion.

**When we should lose:** a buyer who has decided on one contract for endpoint, identity, cloud and runtime. Let that one go, and leave the door open for when the platform team starts complaining.

## 4. Drennick Cloud

**What they are:** a cloud-native startup focused on posture. Fast to try. Popular with DevSecOps teams who want a list of findings this week.

**Where they're strong:** speed to first value and a pleasant product. For a team that only wants posture today, they're a credible choice.

**Where we differ:** they stop at posture. They can't act on a running workload, because they don't run there. Evenburn's fix order and exposure paths compete directly on the posture side. The argument that wins is the pairing with Quenchline, where a finding and a runtime event sit against the same workload.

**How to talk about it:** ask what happens after the list. A team with thousands of findings and no runtime containment is carrying the same risk, better documented. Keep that tone curious. Many of these buyers chose Drennick Cloud themselves and like it.

**When we should lose:** a small team with no production runtime concern yet. They'll come back when they have one, or they won't need us.

## 5. Tesserline

**What they are:** detection only, with a big rule library. Well regarded among detection engineers, and the rule library is a real strength.

**Where they're strong:** coverage and community. A security team that wants to write and tune detections will enjoy working with them. They've been at it for a long time and we respect the work.

**Where we differ:** a detection leaves someone still holding the problem. Quenchline's default containment policy gives a team an action to take, and it contains a known-bad process in a median of 38 seconds in Wickhold lab benchmarks, 2026. We have fewer rules than Tesserline, and we say so if asked. We don't compete on rule count.

**How to talk about it:** take the conversation from what's detected to what happens next. Ask who acts on an alert at 3am and how long it takes them. Then show contain mode.

**When we should lose:** a mature detection team with its own response automation that wants raw signal and nothing else. Some of these teams run a detection product and Quenchline side by side, which is a fine outcome.

## 6. Naming competitors

Never name a competitor in paid or social content. That covers ads, sponsored posts, retargeting, LinkedIn and X, from the brand account and from employees posting on the company's behalf. It includes hashtags, handles and any logo.

Named comparisons appear only in comparison blogs. No landing page, email, deck for general use, press release or event material names a competitor. Those pieces use the category instead: "broad platforms", "posture tools", "detection tools".

Named comparisons follow the comparison blog format, which sits with the battlecards because sales asked for it first. If a piece doesn't meet that format, it isn't a comparison blog, and the names come out.

Inside a live sales conversation, reps may answer a direct question about a competitor by name, using the facts in the battlecards. That's a conversation, not published content. Nothing written down and sent in bulk qualifies.

| Situation | Name them? |
|---|---|
| LinkedIn post about detection versus containment | No. "Detection tools" |
| Paid search ad on a competitor's name | No. We don't bid on their names either |
| Email to a prospect list | No |
| One-to-one reply to a buyer who asked about Tesserline | Yes, facts only |
| Comparison blog published under the format | Yes |
| Talk at Slow Burn Summit | No |

## 7. What never to say

These apply everywhere, including conversation.

- **No insults.** Don't call anyone's product bloated, legacy, a toy, or a dinosaur. Describe what it does.
- **No attribution of incidents.** We don't discuss a competitor's outage, vulnerability, layoffs or customer losses, even when it's public and even when a buyer brings it up. Say we don't comment on other vendors' incidents and move on.
- **No claims about what they can't do without a date.** Products change. "Tesserline doesn't offer containment" goes stale, and it's a problem when it does. Say "as of their public documentation in July 2026", or don't say it.
- **No invented numbers.** We have no reliable pricing, customer counts or overhead figures for any of the three, so we quote none. If a buyer shares one, thank them and don't repeat it to anyone else.
- **No "replace" framing with Brannoch Security.** We don't ask a CISO to remove a platform. We ask for the Kubernetes runtime slot.
- **No customers as weapons.** Don't say which competitor a customer left, even if you know. Customer stories are about what the customer did.
- **No winking.** "A certain heavy agent" fools nobody and it's still naming them. Use the category or leave it out.

## 8. Examples

Good, for a landing page section:

> Detection tools tell you what fired. Wickhold Quenchline isolates the pod's network or freezes the process, then tells you what it did.

Good, for a talk abstract:

> Most teams can see a runtime incident within minutes. Containing one takes a median of 7.4 hours [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]. This session walks through where those hours go.

Bad, do not use:

> Unlike Brannoch Security's bloated agent, Quenchline just works.

Names a competitor outside the format, insults them, and offers no figure.

Bad, do not use:

> Still relying on alerts alone? The last team that did had a very bad weekend.

A hinted-at competitor, a question for an opener, and fear.

Good, for a one-to-one reply when a buyer has asked directly:

> Tesserline has a larger rule library than we do, and detection engineers like it. Wickhold Quenchline is built around what happens after a detection: isolate a pod's network, freeze a process, or drain a node if you choose to allow that. If you already have response automation you may not need the second part.

Fine because it's one person answering one question, it concedes the real strength, and it stays on what we know.

## 9. Analysts and press

Analyst firms and reporters will ask us to rank ourselves against the three. We describe our category and leave the ranking to them. Ilse or Dov handles those conversations. If an analyst report names us alongside a competitor, we can say we were included, and marketing checks the firm's quotation terms before a word of it runs. Our copy never quotes one vendor's placement against another's.

If a reporter asks about a competitor's outage or security incident, the answer is the same as in section 7. Nobody on our side comments, including founders.

## 10. Keeping this current

Product marketing rechecks the three profiles every quarter against public documentation, and after each major competitor release. Changes to section 6 or section 7 need Priit's sign-off. Field reports of something new go to the competitive channel, with a link or a screenshot. "I heard from a prospect" is a lead to check, and it doesn't go in this document until someone has.
