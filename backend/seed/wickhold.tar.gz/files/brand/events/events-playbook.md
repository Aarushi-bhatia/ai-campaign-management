# Events playbook

Maintained by the events lead in Ilse Varga-Holm's team. Updated 6 October 2026 with notes from this year's Summit. Everything here came out of something going wrong at least once.

We run two events of our own and sponsor a small number of others. Each has a different purpose, and most mistakes come from treating one like another.

| | Slow Burn Summit | Field Day | Sponsored booth |
|---|---|---|---|
| Who | Customers and invited prospects | Customers and active prospects in one region | Open conference crowd |
| Size | Few hundred | About 30 | Depends on the show |
| Purpose | Retention, roadmap, reference building | Local community, pipeline | Awareness, engineering hiring |
| Owner | Events lead, Ilse as sponsor | Events lead, field marketing | Events lead, Kofi for staffing |
| Lead time | Nine months | Six weeks | Four months |

## Slow Burn Summit

Our customer conference, in Denver each September. The 2026 edition ran September 15–16.

The name comes from the on-call joke about incidents that burn for hours before anyone notices. Keep the fire theme mild. Summit is about the work, and the sessions should feel like the good part of a postmortem.

**Format.** Day one: Maren's opening talk, Dov's roadmap talk, then customer talks. Day two: working sessions in small rooms, with a test cluster for each table. Evening one: dinner, no speeches. Nothing runs past 5:30 on day two because people have flights.

**Timeline**

- January: dates and venue signed. Budget approved by Ilse.
- March: call for customer talks, sent by customer success, not by marketing.
- April: Dov picks the roadmap themes. Product locks what can be shown.
- June: invitations go out. Registration page live.
- July: speaker drafts. Every customer talk goes through Priit, and every customer speaker gets a rehearsal with Kofi.
- August: reminder email, room assignments, badge order, dietary list.
- First week of September: full run-through on the actual AV. The test clusters get rebuilt from scratch, not restored.
- Week after: recap post, session videos to attendees, thank-you notes signed by Maren.

**Speakers.** Ask Priit before you offer anybody a slot, not after they've said yes. Speaker slides are due three weeks out. We've learned to ask for them earlier than feels polite.

**Sessions that worked in 2026.** The "read a real incident timeline" session, where tables reconstructed what happened from logs. A panel of three on-call engineers with no moderator notes. Dov's live demo of a default containment policy going wrong and being corrected on stage.

**Dropped.** The vendor expo hall (2025 only). Attendees walked through it to reach coffee. The closing keynote from an outside speaker, because people left for the airport. Printed agendas, since nobody could find a session after a room change. We now use a single web page that the team can update from a phone.

**Stage rules.** No product announcement that hasn't been through product marketing. Roadmap slides carry dates only if product has committed to them in writing.  Maren and Dov's slides use the same template as everyone else.

## Field Day

Small regional customer meetups. One afternoon, about 30 people, in a working space, not a hotel ballroom. An office borrowed from a friendly customer works best, if the customer agrees to it. Otherwise use a coworking space with a room that has a real door.

**The run of show**

1. 2:00 Arrive, coffee, name badges with first names large enough to read.
2. 2:30 Short welcome from whoever is hosting. Five minutes, no slides.
3. 2:40 Live containment session. An engineer works a seeded incident on a test cluster, narrating as they go. The room calls out what to check next.
4. 3:40 Break.
5. 4:00 Open questions, led by an engineer. Sales stays in the room but doesn't lead.
6. 4:45 Early dinner or drinks nearby. Done by 7:00.

**The kit.** One portable cluster that fits in a carry-on, a spare, a travel router, HDMI and USB-C adapters, a box of badges, stickers, and printed QR cards for the rollout guide. Kofi keeps the kit list. If you take it, check it back in, because the last two Field Days each lost an adapter.

**Staffing.** Two engineers, one field marketer, one account executive from that region. Never more Wickhold people than a quarter of the room.

**Follow-up.** A note from the host within two days, plain text, with a link to what was shown. Attendees are not added to a nurture track automatically. The account executive decides.

**What we tried.** Field Day at a brewery in 2025. Too loud to hear a kubectl output being read aloud. Field Day with a guest speaker from a partner. The audience wanted the engineers, so we dropped the guest slot.

## Booth rules

These apply to sponsored shows, mainly the big cloud-native conference in November and a few regional security events.

**Booth staffing.** Engineers outnumber salespeople. Two-hour shifts at most. Nobody on the booth has been on call the night before. Kofi sets the rota.

**The demo.** Run it on the portable cluster, never over venue wifi. We lost a full morning to that in 2024. The demo shows Wickhold Quenchline in observe mode, then a seeded process, then contain mode freezing it. If anyone asks about speed, the line is: "contains a known-bad process in a median of 38 seconds in Wickhold lab benchmarks, 2026."

**Opening line.** Ask what they run. Booth staff should not open with a pitch. Try: "What are you running these days?" An engineer with a real answer will stay for ten minutes. Someone who only wants a sticker can take one and go. Both outcomes are fine.

**Badge scanning.** Ask first, every time. Scan only people who've said yes, and record what they asked about in the notes field. Sales gets a shorter, better list that way.

**Giveaways.** Stickers and a useful thing. The 2025 pager-shaped bottle opener was popular. The branded candles were not allowed through venue safety, which was a fair decision. No raffles for electronics, since they fill the list with people who want a tablet.

**Things that stay off the booth.** Printed pricing sheets. Competitive leave-behinds. Any handout that hasn't been through Noor and Priit. Booth staff should send pricing questions to sales and hold roadmap questions for a follow-up with product.

**Hiring.** Bring the current open roles on a QR card. If someone asks about jobs, get Kofi.

**After the show.** Booth breakdown on the last day is everyone's job. The lead list goes to sales within 48 hours, and every lead has a note. A list with no notes goes to the bottom of the pile.

## Sponsored talks

If a sponsorship comes with a speaking slot, an engineer gives the talk. It's about a problem, not about us. Product appears on one slide at the end, at most. Kofi reviews abstracts, and Dov sees anything that describes the agent's internals. Practice twice in front of people who'll be rude about it. The talks that did best for us over the last two years were about things that went wrong.

Submitted abstracts follow the conference's format, but keep ours in the shared abstract log so nobody sends the same one to two shows.

## People and on-site care

Attendees are on call too. Summit has a quiet room with power and good wifi for anyone who gets paged, and a sign on the door saying so. It was the most thanked thing about the 2025 edition.

Lanyards come in two colors. A red lanyard means no photos, and the photographer works around them. Registration explains this in one line with no fuss.

Every event has a code of conduct on the registration page and a named person to contact on site, who is not the person running the stage. Dietary needs and access requirements are collected at registration, and the events lead checks them against the venue two weeks out. If a venue can't manage step-free access to every room, we move to one that can.

A named Wickhold on-call contact stays on duty during Summit. Half the engineering team is in Denver for two days, and the product doesn't stop for that. Dov's team sets the cover rota in August.

## Customer success at Summit

Each customer success manager gets a list of their attendees and books one sit-down during the event. Sales attends only when the customer success manager asks. Product managers hold 20-minute office hours on day two, and the sign-up sheet is the best feedback we get all year. Ask for it back afterward.

Prospects are limited to about one in ten of the room. Sales sends names through the events lead, and each invited prospect has a named customer to meet. A prospect sitting at a table of customers, hearing how a rollout went, does more than a month of nurture.

## Event copy

Invitations follow the normal email rules and use the event templates. Event pages use the campaign layout. Sample post for social:

> Slow Burn Summit: working sessions, test clusters and two days of people who carry the pager. Denver, September. Save your seat: https://wickhold.example/summit

Always give the event's full name on first mention. Don't call it "the Summit" in copy for anyone who hasn't been, and don't call Field Day a "roadshow." Both names stay capitalized the way they appear here.

## Events-only photos

The photo library marks some shots as events only, usually crowd shots, stage shots and anything from a Field Day host's office. Photos marked events only may appear only in promotion of that event or its recap. A 2026 Summit stage photo can run on the 2026 Summit page, in the invite and in the recap post. It can't go on the homepage, a product page, a sales deck, the careers page or an ad for something else.

The marking is in the image's `restrictions` metadata, and the filename won't always show it. Check before you use the photo. We make promises to hosts about where those pictures end up, so if you're unsure, ask the events lead.

## Budget and approvals

Sponsorships over the amount Ilse has set for the year need her sign-off, and she'll ask what we learned from the last one. Every event gets a one-page review within two weeks: who came, what was said, what we'd stop doing. These reviews are why this document exists.
