# Wickhold brand guidelines 2026

Noor Eskelund, Head of Brand. Issued February 10, 2026, with the rebrand. Revised September 2026.

These guidelines replace the 2024 guidelines in full. They cover what the brand is, what it stands for and how it looks at the level a writer, designer or marketer needs to make decisions. The detailed working rules for words, claims, channels and images sit in their own documents, and this one does not repeat them.

## 1. What changed in 2026

On February 10, 2026, Wickhold Security became Wickhold. This section records what moved and why, for the people who join after it and wonder how the folder got to look the way it does.

### Why the company rebranded

The 2024 brand made a promise about watching. It suited a company that sold visibility, and it stopped fitting as the product moved on. By 2025 the feature customers talked about in renewals was the moment Wickhold Quenchline isolated a pod's network at 3am and nobody had to get out of bed. Sales calls kept going the same way: the prospect would say every tool they owned could see a problem, and then ask what happens next.

Ilse Varga-Holm, who owns the rebrand, started the work in spring 2025 with a set of about 30 customer and on-call interviews. Maren Tolliver and Dov Achterberg sat in on most of them. The clearest finding was that nobody wanted another thing watching them. They wanted the blast of an incident to be smaller and the morning after to be shorter. That finding drove every decision below.

### What moved

| Element | 2024 | 2026 |
|---|---|---|
| Brand name | Wickhold Security | Wickhold |
| Tagline | The 2024 line, now retired | Small fires stay small. |
| Logo | Shield with a flame | Geometric W whose center stroke rises as a wick, tipped by one Ember dot |
| Primary color | Cobalt | Ember |
| Ink | Navy | Soot |
| Ground | White | Tallow |
| Secondary | Sky | Whetstone, Verdigris |
| Type | Inter | Bricolage Grotesque, IBM Plex Sans, IBM Plex Mono |

The posture product took a new name, Wickhold Evenburn, on March 2, 2026, three weeks after the company name changed. The two dates were separated on purpose. Customers had one thing to absorb at a time, and the product team needed the extra weeks to change the name in the console.

### How the change rolled out

| Date | What happened |
|---|---|
| Spring 2025 | Interviews begin |
| October 2025 | Name, mark and tagline chosen by the founders, under NDA for most of the company |
| January 2026 | Rebrand teased to customers, with no details |
| February 10, 2026 | Name, logo, tagline, site and these guidelines go live |
| March 2, 2026 | Evenburn name goes live in the console and in customer communications |
| April 14, 2026 | First Containment Report in the new identity |
| Through 2026 | Long tail of old PDFs, deck versions and supplier files |

The transition period is over. Former names are no longer used alongside current ones in new copy. The one standing case for a former name is a historical reference, such as a press archive or a customer who needs to match an old invoice.

### What was tried and dropped

The record is here so that nobody spends a month rediscovering it.

- **Keeping "Security" in the name.** It tested as clear and forgettable. The word was doing the job of a category label, and the boilerplate can do that job in its first sentence.
- **A renamed shield.** The agency's first round kept a shield and took the flame out of it. Customers could not tell it from the vendor logos on their own conference lanyards.
- **A literal candle.** It got a good laugh in the room and looked like a spa.
- **A deep green primary.** Green read as "all clear", which is a promise a security company has no business making with its color. A version of it survived as Verdigris.
- **"Contain first." as the tagline.** It was accurate and it sounded like an order. It lives on as one of the four values.
- **An animated flame in the product.** See the logo section. It is gone.

### Older material

The folder holds a lot of work from before the rebrand. Some of it is useful for reference. None of it is a pattern to copy without checking, and the fact that a document is well made or was recently touched does not make it current.

## 2. Mission

**Keep small failures from becoming big ones.**

The mission is written for the people who run production. A failed deployment, a process that should not be running, a credential in the wrong place: these happen every week in any serious cluster, and they stay dull when somebody contains them early. The company exists to keep them dull.

Three things follow from that wording, and they are the reasons it was chosen.

It accepts that failures happen. A company that claims failures will not happen has stopped talking to engineers. Founders Maren and Dov spent years as on-call infrastructure leads before starting Wickhold in Denver in March 2019, and neither of them has ever met a system that did not fail.

It measures success by size. A contained incident still gets logged, reviewed and fixed. The win is that it stayed at one pod and did not reach the node, or stayed at one node and did not reach the cluster.

It says "keep", which is ongoing work. Containment is something a team does with good tools, every week. The mission gives the product a role in that work and leaves the credit for the outcome with the customer's on-call team.

Use the mission on recruiting pages, in all-hands decks and in the opening of long-form pieces about the company. It is an internal compass first. It should not be pasted on product pages as a slogan, because the tagline already does that job.

A few sentences show the difference between using the mission and hanging it on the wall.

Good, from a recruiting page: "We build software that keeps small failures from becoming big ones. If you have been paged at 3am, you already know why that matters."

Weak: "Our mission is to revolutionize the way the world thinks about failure." It's bigger than the company, and it says nothing an on-call engineer would recognize.

## 3. Values

There are four, and they are written the way an on-call lead would say them.

**Say what happened.**
Report the event in plain order: what occurred, what was affected, what was done, what is next. This applies to incident reports, release notes, customer emails and the company's own mistakes. When a release goes badly, the customer note says so in the first sentence.

Good: "The last Wickhold Quenchline release raised CPU use on nodes running older kernels. A fix shipped on Tuesday. Here is how to check whether you were affected."

Bad: "We're always working to improve performance, and our latest update includes important enhancements."

**Contain first.**
In an incident, limit the damage before explaining it. In marketing, the same ordering applies: the first thing a reader gets is the thing that helps them, and the story of how it came about can wait. The value also sets the company's posture. Wickhold talks about containing, limiting and slowing. A promise of a world with no incidents is a promise no honest vendor can keep.

Good: "At Lowmoor Credit Union, time to contain fell from 4 hours to 11 minutes across 220 nodes."

That example gives the result with no adjectives around it and leaves the reader to decide what it means.

**Admit limits.**
Every product has edges, and engineers find them within a week. Naming a limit in advance costs less than having a customer discover it during a bad night, and it makes everything else the company says easier to believe.

Good: "Wickhold Quenchline works at runtime. It does not review code before it ships."

**Leave it better for the next on-call.**
This one comes straight from the founders. When an on-call shift ends, the next person should find the runbook updated, the noisy alert tuned and the handoff note written. Inside marketing it means naming source files sensibly, recording why a decision was made, and putting a correction in the document that was wrong and not only in a thread. It is why the "tried and dropped" list in section 1 exists.

### The values at work

| Value | What it looks like in marketing | What it rules out |
|---|---|---|
| Say what happened | A release note that names the bug | "Various improvements" |
| Contain first | The useful thing in the first line | A long wind-up about the threat landscape |
| Admit limits | A page that says which environments are unsupported | A feature table with a check in every box |
| Leave it better for the next on-call | A source file with a clear name and a note on why | A final deck that only one person can edit |

### How the values show up in hiring and reviews

The values are also used by the people team, so marketing should not rephrase them. Quote them exactly as they appear here, in this order, with the full stop after each one. They are short sentences, so treat them as sentences.

## 4. Positioning

### The brand idea

A wick is where a fire is allowed to exist. It gives the flame a place to be, and it keeps the flame there. That is the idea behind the name, the mark and the tagline. Wickhold accepts that production systems have heat in them. The job is to hold it to a small, known place.

This idea should explain design and copy decisions when a rule doesn't. When two options are both on brand, pick the one that feels calmer and more contained.

### Tagline

The current tagline is **Small fires stay small.**

It is written with sentence case and a full stop, and the full stop is part of it. Do not vary it, translate it into a campaign pun, or extend it with a second clause. It can stand alone under the logo, close a piece, or sit at the end of a deck. It does not need to appear in every piece, and one use per piece is the limit.

The retired 2024 tagline should not appear in anything new, including "then and now" pieces, without a request to Brand.

### Positioning statement

For teams that run Kubernetes in production, Wickhold is the runtime security company that contains failures early. Other tools report what they saw. Wickhold products act on it, within limits the customer's team has set, and tell the team what was done.

This statement is internal. It tells writers where the company stands, and it is not customer copy. The approved public description of the company is the current boilerplate, which is kept and owned separately.

### The market problem

The strongest evidence for this position comes from Wickhold's own research. The Wickhold Containment Report 2026, published April 14, 2026, surveyed 412 platform and security leaders. It found that "41% of platform teams need more than six hours to contain a runtime incident" and that "the median time to contain a runtime incident is 7.4 hours" [Wickhold Containment Report, 2026, https://wickhold.example/containment-report].

The gap those numbers describe is between finding something and doing something about it. Detection has become cheap and common. Containment still depends on a person with enough access waking up, reading the alert, deciding, and acting. Wickhold's position lives in those hours.

### Where the category goes wrong

Security marketing has habits that readers have learned to skip. The position is partly defined by not having them.

| Category habit | What Wickhold does |
|---|---|
| Opens with a frightening scenario | Opens with what a team can do about the problem |
| Promises total coverage | Says what is covered and names what is not |
| Sells the dashboard | Shows the containment action and its log entry |
| Treats the on-call engineer as a victim | Treats the on-call engineer as the expert |
| Uses a survey to alarm | Uses a survey to size a problem, then stops |

### Testing a campaign idea

Before a concept goes to design, Ilse's team asks four questions of it.

1. Could any other security vendor run this with their logo on it? If so, it isn't the position.
2. Does it depend on the reader being scared? If so, drop it.
3. Does it show containment, or only talk about it?
4. Would the customer's on-call lead forward it to a colleague without a sarcastic comment?

The "Quiet night" concept from the 2026 launch passed all four, and it became the opening of the launch film: a dark office, one screen, a log line reading that a pod had been isolated, and an engineer who doesn't appear because she is asleep at home.

### Good and bad expressions of the position

Good: "Wickhold Quenchline can isolate a pod's network the moment a known-bad process starts. Your team sets which actions run on their own."

Good: "Small fires stay small."

Bad: "Total protection for everything you run." This promises what no product can deliver, and it could be anyone's line.

Bad: "Attackers are already inside your cluster. Are you ready?" This is fear, and the question does nothing for the reader.

### How the position developed

The company did not change what it builds. Quenchline has offered detection and containment since September 2020. What changed is which half of that sentence the brand leads with. In the 2024 identity, the watching came first and containment was a feature. In the 2026 identity, containment is the point and detection is what makes it possible. Detection still matters to buyers and should be described accurately. It just isn't the headline.

Evenburn fits the same logic from the other direction. Posture work reduces how much there is to catch fire, and it gives the team a fix order so that the worst exposure path gets closed first. The story to tell is about keeping the fuel down, and it shouldn't be told as a second, separate product category.

Leashgate extends the idea to AI agents, which now take actions inside customers' environments. An agent with broad tools is a new kind of workload that can make a mistake quickly. Leashgate sets out what that agent may do and keeps a record of what it did. It is in early access, and the position should be described with that in mind: a direction the company is working in, with real customers trying it.

### Who it is for

Three groups share the buying decision. Their detailed profiles and the way to address each are kept in the persona documents. In brief:

- **The security leader**, who answers to a board for how long an incident lasted and how far it spread.
- **The platform lead**, who owns the clusters and will refuse any agent that slows them down or takes action without a way to control it.
- **The DevSecOps engineer**, who lives in the tooling every day and decides in practice whether a product gets used.

Wickhold has grown from a company selling to individual platform teams into one that also sells to security organizations. Brand work has to hold both audiences. The test is whether an on-call engineer would read the page without rolling their eyes and whether a security leader could forward it without apology.

### What Wickhold is and is not

| Wickhold is | Wickhold is not |
|---|---|
| A runtime security company | A general cloud security suite |
| Focused on Kubernetes | Trying to cover every kind of infrastructure |
| Built by people who have been on call | A compliance tool that happens to run in a cluster |
| Calm in an incident | A voice that raises the temperature to sell something |

### The promise at each level

| Level | What is promised |
|---|---|
| Company | Small fires stay small. |
| Quenchline | When something goes wrong at runtime, a defined containment action happens quickly and the team sees exactly what it did |
| Evenburn | The team sees where the drift and exposure paths are, and gets a fix order |
| Leashgate | AI agents work inside a tool-call policy, so the blast radius of an agent is known in advance |

## 5. Brand architecture

Wickhold is a single brand. Products, reports and events all sit under it, and none of them has a logo of its own.

### Company

The legal name is Wickhold, Inc., which appears in legal notices, contracts and the copyright line. The brand name is Wickhold, pronounced WICK-hold. "Wickhold Security" is the former brand name, and it survives only in historical references such as a press archive.

### Writing the company name

Write Wickhold, with one capital. The possessive is Wickhold's. The name is singular in American English, so "Wickhold is", and it never takes "the" in front of it. In a logo-free context such as a plain-text email or a form field, the name is simply typed out. Internal team names like "Wickhold Marketing" are descriptions and do not need any special treatment.

### Products

| Product | Job | Status |
|---|---|---|
| Wickhold Quenchline | Runtime detection and containment for Kubernetes, using an eBPF agent | Available since September 2020 |
| Wickhold Evenburn | Cloud and cluster posture management | Available. Took this name on March 2, 2026 |
| Wickhold Leashgate | Runtime policy for AI agents and their tool calls | Early access since May 2026 |

The product names came from the same idea as the company name. A quench line is the mark where hot metal is cooled and fixed. An even burn is what a well-trimmed wick gives you. A leash gate is a control point an animal has to pass through on a lead. When someone asks where the names came from, those are the answers, and they make a decent line in a founder talk. They do not belong in product copy.

Spelling and capitalization of product names are covered in the style documents.

### Vocabulary that belongs to the products

Each product has a small set of terms. Use them exactly, because customers see the same words in the console.

- **Quenchline:** containment action (isolate a pod's network, freeze a process, drain a node), default containment policy, contain mode, observe mode.
- **Evenburn:** drift, exposure path, fix order.
- **Leashgate:** tool-call policy, agent identity, blast radius of an agent.

### Reports and events

- **Wickhold Containment Report.** Annual, published in April. It was the Wickhold Field Report before 2025. Reports use the company's visual identity with no separate report logo.
- **Slow Burn Summit.** Wickhold's own customer conference, in Denver each September. The 2026 edition ran September 15 to 16. The event may have its own title treatment, set in the brand type, and it uses the Wickhold logo.
- **Field Day.** Small regional customer meetups. Field Days use a shared template and do not get individual branding.

Webinars, workshops and one-off programs are described in plain words and do not get a brand of their own. A proposal for a podcast with its own name and cover art was turned down last year for this reason. A topic that needs its own identity to be interesting probably isn't interesting.

### Partners

Wickhold does not run a sub-brand for partners, resellers or integrations. A partner may say that it works with Wickhold, once the partner agreement is in place and Priit's team has reviewed the wording. There is no "Wickhold certified" badge, and there is no plan for one.

### Naming something new

Marketing does not name features casually. Before a new name goes anywhere public:

1. The product manager and Noor agree that it needs a name. Most features do not. "Network isolation" is clearer than a coined word.
2. Priit Salonen's team runs a trademark check.
3. Kofi Anselm's developer relations team reads it aloud to a few customers' engineers. This is how a proposed feature called "Snuff" died in March.
4. Noor adds it to the product naming reference.

## 6. Logo summary

The mark is a geometric W whose center stroke rises as a wick, tipped by one Ember dot. It says the same thing as the brand idea: a straight, deliberate structure with one small, controlled point of heat at the top. The dot is the only warm thing in the mark, and that is the reason to protect it. Used alongside the wordmark "Wickhold", it forms the lockup, which is the default in most layouts.

There are four approved variants: ink on transparent, reversed on transparent, on a Tallow panel, and on a Soot panel. Exact file specifications, clear space and minimum sizes are in the logo and color addendum. How to choose among the variants for a given layout belongs to the logo-in-context guidance.

The 2024 shield-and-flame logo is retired. It still appears in the archive and in a few old files, and it should not be used in anything new.

The logo appears once in a layout, and it usually doesn't need to be large. Confidence in a mark shows in how much room it's given, so a modest logo with space around it is better than a big one crowded by other elements. In the product, the mark appears in the console header and on the sign-in page. Screens that a customer works in all day don't need it anywhere else.

Two pieces of history are worth keeping in mind. In the first month after launch, the product team shipped a loading state with a flickering dot, and customers read it as an error. It was withdrawn. The dot does not move. And early on, several people tried turning the W into a pattern for backgrounds and swag. The mark loses its meaning when it repeats, because the whole point is that there is one of it. Use it once per layout.

## 7. Color

### Palette

| Name | Value | Role |
|---|---|---|
| Ember | `#C2501F` | Primary |
| Soot | `#15181C` | Ink |
| Tallow | `#F4EFE6` | Ground |
| Whetstone | `#5E6B73` | Secondary |
| Verdigris | `#2F8F83` | Secondary |

Precise color specifications, tints and measured contrast pairs are in the logo and color addendum.

### What replaced Cobalt

Cobalt, the primary color from 2024, was retired on February 10, 2026, and **Ember `#C2501F` replaced it as the primary color**. Cobalt should not appear in any new work. Ember is not used the way Cobalt was. Cobalt covered whole slides, hero bands and booth walls. Ember is a small, deliberate point of heat, and a layout built around it should look mostly like Tallow or Soot.

The reasons for the change were practical as well as symbolic. The category is full of blue, and in side-by-side tests of competitor pages Wickhold's old pages were hard to pick out. A warm orange-brown also ties the color to the brand idea, since it is the color of a banked coal. It is deliberately neither a bright hazard orange nor an alarm red, because the brand is not trying to raise a reader's pulse.

### How the palette works

Tallow replaced White as the ground. It is warmer, it photographs well beside the current imagery, and it keeps a page from feeling like a blank dashboard. Soot replaced Navy and serves as both the ink on Tallow and the ground for dark layouts. Most pages are one or the other, and a long page can alternate the two.

Whetstone is for supporting text, rules, and quieter interface elements. Verdigris is the one cool note in the palette, useful in charts and for a second series or state when Ember is already in use. Sky has no direct successor, and nobody should try to find one.

### Color in common pieces

| Piece | Ground | Where Ember goes |
|---|---|---|
| Website page | Tallow, with Soot bands for pacing | The primary button, or one key figure |
| Sales or conference deck | Soot for title and section slides, Tallow for content | One point on a slide, or none |
| Report | Tallow pages, Soot cover | Chart highlights and one rule on the cover |
| Product documentation | Follows the docs theme | Links are not Ember on small text |
| Booth | Soot backwall, Tallow counter | The dot in the logo and one line of type |
| Swag | Soot or undyed fabric | The dot |

Dark layouts should use Soot, and pure black should not stand in for it. Soot has a slight cool cast that keeps Ember from buzzing against it. On Tallow pages, photographs and screenshots sit best with a thin Whetstone rule around them, since a light screenshot can otherwise dissolve into the page.

### Mistakes seen since launch

The single most common mistake since launch is treating Ember as the "main" color because the table calls it primary. Primary means most important, and it does not mean most area.

## 8. Typography

### The three families

| Family | Role | Why it was chosen |
|---|---|---|
| Bricolage Grotesque | Headlines | Slightly irregular, with some personality at large sizes. It looks made by a person |
| IBM Plex Sans | Body | Plain and sturdy, and easy to read over long documents |
| IBM Plex Mono | Code | Pairs with Plex Sans and has clear distinctions between similar characters such as 0 and O |

All three are open-licensed, so anyone at the company, any agency and any build pipeline can use them without a license request. Inter was retired with the 2024 identity.

### Working scale

This scale is a starting point for web and documents. Slides and print scale up from it.

| Element | Family and weight | Desktop size | Line height |
|---|---|---|---|
| Page headline | Bricolage Grotesque Bold | 48 px | 1.1 |
| Section headline | Bricolage Grotesque SemiBold | 30 px | 1.2 |
| Subhead | IBM Plex Sans SemiBold | 20 px | 1.3 |
| Body | IBM Plex Sans Regular | 17 px | 1.55 |
| Caption | IBM Plex Sans Regular | 14 px | 1.4 |
| Code | IBM Plex Mono Regular | 15 px | 1.5 |

### Using them well

Bricolage Grotesque is a display face. Below about 20 px its quirks turn into noise, so it should not be used for body text, buttons or table cells. Limit a page to the two headline weights in the table.

Plex Sans carries nearly everything else. Keep line lengths between 60 and 80 characters. On long pages a wider column is the first thing to go wrong.

Plex Mono has a job beyond code. Commands, flags, file names, YAML keys and other literal strings are set in mono inside body text, so a reader can see what to type. Node counts and timings in a table can also use it, because the digits line up. Do not use it for decoration or to make something feel technical. Engineers notice.

Email is the known exception. Mail clients ignore most web fonts, so the email stack falls back to a system sans-serif, and headlines in an email rely on weight and spacing to do the work.

Italic is for titles of reports and for the occasional stress. All caps are limited to small labels in a layout, and never to whole sentences.

### Slides and documents

Slide titles use Bricolage Grotesque at 40 pt or larger, and body text in Plex Sans never goes below 18 pt. The master deck template and the document templates have all of this built in, so start there. Fonts should come from the shared font folder, because a copy downloaded from elsewhere can be a different version and shift the line breaks in someone else's slides.

A piece of long-form writing, such as a report, can use Plex Sans for captions and pull quotes. Pull quotes stay in Plex Sans and are not an excuse for a third display style.

### A worked hierarchy

A typical landing section might read:

- Page headline, Bricolage Grotesque Bold: "Small fires stay small."
- Subhead, Plex Sans SemiBold: "Wickhold Quenchline contains runtime failures on your Kubernetes nodes, within limits your team sets."
- Body, Plex Sans Regular: one short paragraph.
- Inline literal, Plex Mono: `kubectl get containmentpolicy`.

Four levels is plenty. If a layout seems to need a fifth, the content usually needs editing.

### Dropped along the way

An early pairing set headlines in a heavy slab, which looked like a whiskey label. A single-family approach using only Plex was tested too. It was tidy, and it looked like every other developer tools company. Bricolage Grotesque was what gave the system some warmth.

## 9. Photography and illustration direction

This section sets direction only. The rules for each image type, and for each channel, live with the visual guidance.

### Photography

Photographs show real work in real places: available light, working rooms and real infrastructure, warm and slightly underexposed. The feeling to aim for is the quiet of a team that has things under control, late in the day, with the lights half on. People are shown doing what they actually do. The 2024 look of bright, staged collaboration has gone, as has its blue tint.

A useful test is to ask whether an on-call engineer would recognize the room. A cable tray with a handwritten label passes. A spotless corridor of lights does not.

### Illustration

Illustration is flat cut-paper shapes with one Ember focal element on Tallow or Soot, and no gradients. The cut-paper style was chosen because it looks made by hand and sits comfortably next to the warm photography. It also holds up small. Shapes should be simple enough to be cut with scissors, which is a good test when a design starts picking up detail.

Illustration tends to work best for ideas that have no honest photograph, such as a policy, a blast radius or an exposure path. Containment is the recurring theme: something small, held inside something that keeps it there.

The isometric style and the line graphic from the 2024 identity have been retired, along with the Cobalt gradient behind them.

### Product imagery

Screenshots and diagrams show the real product and real terms. When a choice exists between a clever visual metaphor and a clear view of what the product did, show the product.

### What fits and what doesn't

| Subject | Fits | Doesn't fit |
|---|---|---|
| A person at work | An engineer at a desk at dusk, reading a log | A team high-fiving around a laptop |
| Infrastructure | A real rack with labels and a worn floor | A computer-generated tunnel of light |
| The idea of containment | A single paper flame inside a paper ring | A digital barrier across a globe |
| AI agents | A simple cut-paper figure on a short lead | A glowing robot face |

### Commissioning imagery

A good image brief names the idea, where the image will run and its one focal point, and it leaves the style to the visual guidance. "A wick in a ring of cut paper, for a blog on containment policy" is a usable brief. "Something cool about AI security" is not.

Freelancers and agencies should get the visual guidance before their first sketch. On the launch film, the first round of location photos came back blue and spotless, because the agency had worked from a mood board built on the old identity. Reshooting took a week.

Any generated or composited image gets the same review as a commissioned one. It is held to the same direction, and a person looks at it at full size before it goes anywhere.

### Choosing between them

| If the piece is about | Lean toward |
|---|---|
| People, customers, the company | Photography |
| An idea or a risk | Illustration |
| What the product does | Product imagery |

Security imagery has a set of tired visual habits, and the brand stays well clear of them. Fear is not part of the visual language, for the same reason it is not part of the verbal one.

## 10. Accessibility summary

Accessible work is part of the brand standard, and it is checked at review alongside everything else. The reasoning is simple enough: engineers read documentation on bad monitors, on phones and at 3am, and some of them have low vision or are color-blind. Work that only functions in perfect conditions fails the people it is meant for.

In summary, four commitments apply across all marketing work:

- Text is readable against its background. The palette has been measured, and not every pairing is suitable for small text. Ember in particular needs care.
- Images carry a text description, so nobody loses the point of a piece because an image did not load or cannot be seen.
- Meaning is never carried by color alone. A chart or status needs a label, a shape or a pattern too.
- Pages work with a keyboard and at high zoom, and video has captions.

The misses that come up most at review are predictable. A chart legend that relies on Ember versus Verdigris alone is hard to read for some color-blind readers, since those two are close in lightness. An Ember link in a paragraph looks fine on a designer's monitor and is hard to read on a laptop in daylight. Text set into an image can't be read by a screen reader and can't be translated. Video exported from a webinar tool often ships with captions switched off.

Accessibility review belongs to whoever does the brand check on a piece, and it isn't a separate stage. If a template fails, Noor's team fixes the template, so the same miss doesn't come back in every piece made from it.

The specific requirements are in the visual accessibility guidance, and the measured color pairs are in the logo and color addendum. Bricolage Grotesque's limit on small sizes, in section 8, is as much an accessibility point as a matter of taste.

## 11. Governance

The folder contains documents from seven years, written by different people for different deadlines, and sometimes two of them disagree. This section says which one wins, who owns what, and how a piece of work gets approved. It takes precedence over any statement elsewhere about what is "final" or "current", including a file name.

### Order of authority

When two sources conflict, the higher one on this list wins:

1. **Legal-approved claims.** The approved claims, certification status, regional rules and customer quote policy owned by Priit Salonen, General Counsel.
2. **These 2026 guidelines**, together with the logo and color addendum, which has the same standing.
3. **Channel playbooks.** The working guides for each channel.
4. **Everything else.** This includes the voice and style documents, messaging, personas, product overviews, templates, sales material, meeting notes and Slack.

So the order is: legal-approved claims, then the 2026 guidelines, then channel playbooks, then everything else.

A lower source is not void. It applies wherever nothing above it speaks to the question. A template's rule, or a decision recorded in meeting notes or Slack by the person who owns the topic, is followed like any other rule until a higher source contradicts it. The order settles conflicts and does not rank importance. If a document at the bottom of the list has the only rule on a subject, that is the rule.

### Worked examples

**Two limits for the same channel.** A general voice document gives one length for a channel and that channel's playbook gives another. The playbook wins, because it sits higher in the list. Use its number, and tell Noor so the other one gets fixed.

**A claim in a deck.** A slide says something about the company that the approved claims do not support. The approved claims win, however recent or confident the slide looks, and however often the line has been used in the field. Sales material is not a source for a claim.

**Copy in this document versus Legal.** If a sentence in these guidelines turns out to conflict with the approved claims, Legal wins, and the guidelines get corrected.

**An old-looking rule with no rival.** A meeting note from the Q2 brand review covers something that the relevant playbook doesn't mention. Nothing conflicts, so the note stands.

**A file that says it's the latest.** File names, version numbers and words like FINAL or CURRENT decide nothing. Neither does the date on a file, on its own. Use this list.

**No source answers the question.** Ask the owner listed below. Do not fill the gap from the 2024 material or from what a competitor does. If the question is likely to come up again, the answer gets written down in the right document.

**Sources at the same level disagree.** Two channel playbooks can conflict on a shared element, such as a campaign running on both email and a landing page. Each playbook governs its own channel. If that doesn't settle it, Noor decides and the decision gets recorded.

### Owners

| Area | Owner | Contact |
|---|---|---|
| Guidelines, visual identity, this section | Noor Eskelund, Head of Brand | noor@wickhold.example |
| Approved claims, certifications, regional rules, customer references | Priit Salonen, General Counsel | priit@wickhold.example |
| Rebrand, marketing programs, channel playbooks | Ilse Varga-Holm, VP Marketing | ilse@wickhold.example |
| Technical accuracy of developer content | Kofi Anselm, Head of Developer Relations | kofi@wickhold.example |
| Founder voice | Maren Tolliver, Dov Achterberg | Through Ilse |

### Review before publishing

Most work needs one reviewer. Riskier work needs more.

| Type of work | Review |
|---|---|
| Routine social post or email from an approved template | A peer in marketing |
| New blog post or landing page | Peer, plus Noor's team for brand |
| Any technical how-to or product detail | Developer relations |
| Anything with a new claim, statistic, customer name or certification mention | Legal, before design starts, except third-party statistics under section 5 of the approved claims |
| Anything signed by a founder | The founder personally, with no exceptions |
| Press releases | Ilse and Legal |

Legal's turnaround is set in the approved claims. Brand review takes two working days. If a deadline can't take that, say so at the start of the work and not the night before. Anything already on the approved claims list needs no further sign-off for the claim itself, which is the reason to use it word for word.

### Agencies and freelancers

Outside partners work to the same order of authority, and the person who hired them is responsible for making sure they have it. At kickoff they receive these guidelines, the addendum, the relevant playbook and the current logo package. They do not receive older guidelines or old campaign files as reference, unless Brand has reviewed what's being sent. Work from outside partners goes through the same review table as anything made in-house.

### Exceptions

Exceptions are allowed and they are written down. Ask Noor by email with the piece, the rule, and the reason. If she agrees, the exception goes in the log she keeps, with an end date. Verbal approvals from a hallway don't count. Legal rules have no exception process through Brand. Those go to Priit.

Two exceptions from this year are typical. The Slow Burn Summit stage used a Soot and Ember backdrop well past the usual Ember proportion, because a stage is seen from 40 meters away. The Evenburn rename notice ran for 60 days using the previous product name in customer communications, so that people could find it.

### Raising a conflict

If two documents disagree, don't quietly pick one and move on, because the next person will hit the same thing. Follow the order of authority for the piece in hand, ship it, and then send a short note to the owner of the lower document.

A useful note says three things and takes a minute to write:

> "These two documents give different answers on the same point. I used the higher one. Can the other be updated?"

The owner corrects the lower document or explains why it stands. If the higher document is the one that's out of date, the owner of that document changes it. Nobody overrides it locally.

### Claims made in a hurry

Launches and field events are when unapproved language tends to appear, usually from someone trying to help. If you see a claim in circulation that isn't on the approved list, tell Priit the same day, including where you saw it. There is no blame in reporting one. The aim is to get it corrected before it's copied into something else.

### Keeping the folder healthy

Anything superseded is meant to move to the archive, and in practice that lags. A folder cleanup was parked at the Q2 brand review and is planned for Q4, so treat the order of authority as the working guide and not the folder layout. When you notice a stale file, tell Noor or fix it. That is the fourth value in practice.

Changes to these guidelines go through Noor, and changes to this section also need Ilse's agreement. Each revision is listed in section 12.

## 12. Revision log

| Date | Change |
|---|---|
| February 10, 2026 | First issue, with the rebrand |
| March 2, 2026 | Evenburn name added to section 5 |
| April 2026 | Containment Report 2026 figures added to section 4. Addendum reference added to section 7 |
| June 2026 | Leashgate added to section 5 and to the promise table. Governance review table extended to cover certification mentions |
| September 2026 | Slow Burn Summit dates updated. Exceptions and agency notes added to section 11 |
