# WICKHOLD SECURITY BRAND GUIDELINES

**Version 3.0 (FINAL)**
Prepared by the Wickhold Security Marketing team
Approved by Ilse Varga-Holm, VP Marketing
September 2024

---

## Welcome!

What a year! A $46M Series B led by Marlbank Partners, a platform that now protects over 80+ teams, and a brand that finally looks as sharp as the product behind it. This document is your complete guide to how Wickhold Security looks, sounds and shows up in the world.

Version 3 is the biggest update to our identity since the company was founded. Everything you need is in here: the logo, the colors, the type, the imagery, the messaging, and practical guidance for the things you make every week. If you are writing a blog, building a slide, ordering a banner or briefing a freelancer, start here and you will get it right the first time.

Our promise fits on one line, and everything in this document exists to back it up:

> **Every workload. Always watched.**

Keep this guide close. Share it with your agencies. And when in doubt, come ask!

---

## 1. Our Brand at a Glance

| | |
|---|---|
| **Company name** | Wickhold Security |
| **Tagline** | Every workload. Always watched. |
| **What we do** | Continuous runtime and posture security for cloud and Kubernetes |
| **Founded** | March 2019, Denver, Colorado |
| **Founders** | Maren Tolliver (CEO) and Dov Achterberg (CTO) |
| **Products** | Wickhold Quenchline, Wickhold Tallowatch |
| **Primary color** | Cobalt `#1F4FD8` |
| **Typeface** | Inter |
| **Logo** | Shield with flame, plus the Wickhold Security wordmark |

### Our boilerplate

Use this paragraph, word for word, at the end of press releases, on event listings, and anywhere somebody asks for "the About section":

> Wickhold Security keeps every workload watched. Our platform gives over 80+ teams continuous visibility into cloud and Kubernetes risk. Founded in 2019, Wickhold Security is headquartered in Denver.

### Wickhold Security by the numbers

| | |
|---|---|
| Teams on the platform | 80+ |
| Founded | 2019 |
| Headquarters | Denver |
| Products | 2 |
| Watching | 24/7 |

### Our headline proof point

One number tells our story better than any other, and you will see it across our website, decks and campaigns:

> **68% of runtime incidents began with a misconfigured workload.**
> Source: Wickhold Field Report 2023

Why does this matter so much? Because it proves that visibility is the whole game. If you can see every workload, all the time, you can catch the mistake that turns into the 2am page. That is the case for Wickhold Security in a single sentence.

---

## 2. Our Story

Wickhold Security was founded in Denver in March 2019 by Maren Tolliver and Dov Achterberg. Both had spent years as on-call infrastructure leads, and both had the same complaint: by the time anybody knew something was wrong in a cluster, it was already somebody's very long night. Existing tools were built for servers that stayed put, and Kubernetes workloads do anything but.

So they built the tool they wished they'd had. Wickhold Quenchline reached general availability in September 2020, bringing runtime detection and containment to Kubernetes through a lightweight eBPF agent. Our Series A followed in March 2022 at $18M, and with it came Wickhold Tallowatch, extending the same always-on approach to cloud and cluster posture. In June 2024 we closed our $46M Series B, led by Marlbank Partners, to take the platform further and faster.

Today over 80+ teams rely on Wickhold Security to know what is running, what has changed, and what needs attention right now.

When you tell this story, keep these three beats in order:

1. **Founders who carried the pager.** We are operators first.
2. **A product that never blinks.** Continuous beats periodic, every time.
3. **Momentum.** More teams, more funding, more coverage.

---

## 3. Our Name

Our name is **Wickhold Security**. Two words, both capitalized, every time.

- ✔ Wickhold Security
- ✘ Wickhold
- ✘ WickHold Security
- ✘ WHS
- ✘ Wickhold Sec
- ✘ wickhold security (except in the URL and in email addresses)

Yes, "Wickhold" on its own is shorter, and yes, people say it out loud in meetings. In anything we publish, use the full name. "Security" tells the reader what category we are in before they read another word, and for a growing company that clarity is worth two extra syllables.

The legal entity is Wickhold, Inc. Use that only in legal notices, contracts and the copyright line.

### Product names

| Product | What it does |
|---|---|
| **Wickhold Quenchline** | Runtime detection and containment for Kubernetes, using an eBPF agent |
| **Wickhold Tallowatch** | Cloud and cluster posture management |

Together they make up **the Wickhold Security platform**. "Platform" is lowercase. Each product name is one word with one capital letter. Do not add "by Wickhold Security" after a product name, and do not abbreviate a name to initials in anything a customer might see, even if the engineering team does it in standups.

---

## 4. Our Messaging

### The core idea

Modern infrastructure never sits still, so neither do we. Wickhold Security gives teams one seamless view of everything running across cloud and Kubernetes, around the clock. Every message we write should ladder up to that idea.

### Our three pillars

**Pillar 1: Every Workload.**
Complete coverage. Every pod, every node, every cluster, every cloud account. There are no blind spots on the Wickhold Security platform.

Supporting language: *full coverage*, *no blind spots*, *one single pane of glass for runtime and posture*.

**Pillar 2: Always Watched.**
Security that never sleeps! Our eBPF agent and continuous scanning mean you find out in seconds, not in next quarter's audit.

Supporting language: *always on*, *continuous*, *real time*, *24/7 visibility*.

**Pillar 3: Built by Operators.**
Maren and Dov carried the pager. Our product respects the people who run production, with lightweight deployment, sensible defaults and robust integrations that fit how platform teams already work.

Supporting language: *by operators, for operators*, *lightweight*, *fast to deploy*.

### Elevator pitches

**Ten seconds:**
Wickhold Security is the always-on security platform for cloud and Kubernetes. Every workload. Always watched.

**Thirty seconds:**
Kubernetes moves fast, and most security tools can't keep up. Wickhold Security gives over 80+ teams a single, continuous view of runtime threats and cloud posture. Wickhold Quenchline watches what your workloads actually do, and Wickhold Tallowatch shows where your clusters and cloud accounts are exposed.

**Two minutes (for the booth):**
Start with the number: 68% of runtime incidents began with a misconfigured workload. That comes from our own Wickhold Field Report 2023. So the question for any security team is simple: can you see every workload, right now? Wickhold Quenchline runs a lightweight eBPF agent on every node, so you see what is happening at runtime and can act on it immediately. Wickhold Tallowatch covers the other half, continuously checking cloud and cluster posture so a misconfiguration gets caught early. Together, they give your team a holistic, best-in-class view of risk, without slowing anybody down. Over 80+ teams are already on board. Can I show you a quick demo?

### Tone by Format

The personality stays the same everywhere, but the volume changes.

| Format | Tone | Example opener |
|---|---|---|
| Website | Big, bold, benefit-led | "Every cluster. One seamless view." |
| Email campaigns | Friendly and energetic | "Big news from Wickhold Security!" |
| Social | Punchy, a little playful | "New Field Report just dropped!" |
| Technical blog | Helpful and detailed | "Here's how eBPF sees what your logs miss." |
| Sales deck | Confident, proof-heavy | "Over 80+ teams trust us to watch their workloads." |
| Press | Measured, factual | "Wickhold Security today announced..." |

### Who We Talk To

**Security leaders.** The people who sign off on the budget. They want to know that nothing is falling through the cracks and that they will have a good answer when the board asks. Talk about coverage, visibility and confidence, and show them the single view of risk across every cluster.

**Platform teams.** The people who run production. They will ask how heavy the agent is, how long the rollout takes and whether it will wake them up for nothing. Talk about lightweight deployment, sensible defaults and operators who've been in their shoes.

**DevSecOps engineers.** The hands-on users. They care about integrations, the API and how fast they can get an answer out of the product. Give them docs, demos and real examples.

### Sample Headlines

Stuck for a headline? Start from one of these and make it yours:

- See every workload. Sleep better tonight.
- Runtime security that never takes a night off.
- From first pod to full fleet: always watched.
- One platform. Every cluster. Zero blind spots.
- Your posture, in real time, with Wickhold Tallowatch.
- Lightweight eBPF. Heavyweight visibility.

### Sample Campaign: "Always Watched"

Our 2024 campaign is a great model for how the pieces fit together. A hero film opens on a dark data center that wakes up aisle by aisle as a Cobalt light moves through it, ending on the tagline. The landing page repeats the same headline, the booth repeats the same image, and every email in the series closes on the proof point. When one idea shows up the same way everywhere, people remember it. Pick one idea, then repeat it!

### Writing in the Wickhold Security style

Our personality is **bold, vigilant and helpful**.

- **Bold.** We lead the conversation. Use strong verbs and short sentences. Own the category!
- **Vigilant.** We are the team that's awake when you aren't. Remind readers that risk is moving all the time.
- **Helpful.** We are on the customer's side. Explain the why, and give the reader a next step.

Some examples from our recent work that hit the mark:

- "Your clusters never sleep. Neither do we."
- "See it all. In real time. On one seamless platform."
- "Next-gen runtime security for teams who refuse to fly blind!"
- "Every workload. Always watched."

Say "the Wickhold Security platform" in the first paragraph of anything longer than a paragraph, and mention the tagline in the closing line of campaigns wherever it fits.

---

## 5. Our Logo

### The primary logo

Our logo combines two elements: the **shield**, which stands for protection, and the **flame** rising from inside it, which stands for the constant, watchful light of runtime visibility. Beside the shield sits the **Wickhold Security wordmark**, set in Inter Bold with a custom tight fit.

The shield and the wordmark are a single unit. In nearly all cases, use them together.

### Logo versions

| Version | Shield | Flame | Wordmark | Use on |
|---|---|---|---|---|
| Full color | Cobalt | Sky | Navy | White and light backgrounds |
| Reversed | White | Sky | White | Cobalt and Navy backgrounds |
| One color Navy | Navy | Navy | Navy | Single-color print |
| One color White | White | White | White | Single-color print on dark stock |

Vertical lockups (shield centered over the wordmark) are available for square formats such as booth towers and swag.

### The shield on its own

The standalone shield is reserved for places where the full logo cannot fit: social avatars, favicons, app icons, lapel pins and the top corner of slides. In all other cases use the full logo.

### Clear space

Always keep a zone of clear space around the logo equal to the height of the flame. No text, images or edges may enter this zone. More space is always better!

### Minimum size

| Format | Full logo | Shield alone |
|---|---|---|
| Print | 1 inch wide | 0.25 inch wide |
| Digital | 120 px wide | 20 px wide |

### Logo misuse

Please protect our most valuable piece of brand equity. Do not:

- Separate the flame from the shield
- Recolor the logo in anything but the versions above
- Stretch, squeeze, skew or rotate it
- Add drop shadows, bevels or glows
- Place the full-color logo on Cobalt, or on any busy photograph
- Recreate the wordmark by typing it out
- Place the old 2022 logo on anything new
- Lock the logo up with a campaign name or tagline unless Marketing has supplied the artwork

---

## 6. Our Colors

Color is the fastest way to be recognized at a crowded show or in a busy feed. Cobalt is the heart of the Wickhold Security brand: confident, trustworthy and instantly at home in security. Used consistently, it has become our single most recognizable asset after the logo.

### Primary palette

| Name | Hex | RGB | CMYK | Role |
|---|---|---|---|---|
| **Cobalt** | `#1F4FD8` | 31, 79, 216 | 86, 63, 0, 15 | Primary brand color |
| **Navy** | `#0B1B3A` | 11, 27, 58 | 81, 53, 0, 77 | Ink, headlines, dark backgrounds |
| **White** | `#FFFFFF` | 255, 255, 255 | 0, 0, 0, 0 | Ground |

### Secondary palette

| Name | Hex | RGB | CMYK | Role |
|---|---|---|---|---|
| **Sky** | `#6CA8FF` | 108, 168, 255 | 58, 34, 0, 0 | Accents, highlights, charts |

### How much of each

- **White:** about 50% of most layouts. Clean, open pages feel modern and trustworthy.
- **Cobalt:** about 30%. Use it boldly! Full-bleed Cobalt slides, hero bands and booth walls are all encouraged.
- **Navy:** about 15%, mostly for text.
- **Sky:** about 5%, as an accent.

### Gradient

Our one approved gradient runs from Cobalt at the lower left to Sky at the upper right, at 45 degrees. Use it on hero bands, event backdrops and the opening slide of a deck. Do not reverse it, and do not add a third color.

### Text color

Body text is Navy on White, or White on Cobalt and Navy. Links are Cobalt. Sky is not a text color on White.

### Chart colors

Charts lead with Cobalt, followed by Navy, then Sky. Use grays only for axes and gridlines. Keep to four series at most. If you need more than that, the chart should be two charts.

---

## 7. Our Typography

We use one typeface: **Inter**. It is clean, modern, highly legible on screens and comes in the full range of weights we need. It works for slide titles and interface labels alike, and because it is open source, anyone on the team or at an agency can install it without a license request.

### Weights

| Use | Weight |
|---|---|
| Display and page titles | Inter ExtraBold (800) |
| Section headers | Inter Bold (700) |
| Subheads | Inter SemiBold (600) |
| Body copy | Inter Regular (400) |
| Captions and legal lines | Inter Regular (400) |
| Buttons | Inter SemiBold (600) |

Avoid weights lighter than Regular. They wash out on booth graphics and on projectors.

### Print and slide sizes

| Element | Slides | Print one-pager |
|---|---|---|
| Title | 44 pt | 32 pt |
| Section header | 28 pt | 18 pt |
| Body | 18 pt minimum | 10 pt |
| Caption | 12 pt | 7.5 pt |

### Web sizes

| Element | Desktop | Mobile |
|---|---|---|
| H1 | 56 px | 36 px |
| H2 | 36 px | 28 px |
| H3 | 24 px | 20 px |
| Body | 18 px | 16 px |

Line height is 1.5 for body copy and 1.15 for headlines. Set headlines with tight tracking of -1%.

### Fallback fonts

If Inter cannot be loaded, as in an email client, fall back to Helvetica, Arial, sans-serif, in that order. In code samples use the system monospace font. We do not have a brand mono.

---

## 8. Our Imagery

Imagery should say one thing: *we see everything, and it's under control*. Our look is bright, clean and technical, and blue carries it.

### Photography

- **Data centers and server rooms.** Long aisles with blue lighting and strong perspective work beautifully, and they make great hero backgrounds.
- **Modern workspaces.** Bright offices, big monitors and teams collaborating around a screen.
- **Confident people.** Practitioners at work, looking engaged and focused.

Apply a Cobalt overlay at 40% to photographs used behind text. This pulls images from different sources into a single family.

Stock photography is fine as long as it fits the look. Marketing keeps a licensed library in the shared drive, so check there before you buy anything new.

### Illustration and graphics

Our illustration style is **isometric and technical**. Think layered cubes for clusters, connected nodes for workloads, and shields as a recurring motif. All illustrations use the brand palette with the Cobalt-to-Sky gradient for depth.

The **Sky Thread** is our signature graphic device: a thin Sky line that traces across a layout from node to node, like a heartbeat monitor for your infrastructure. Use it as a section divider in decks, along the bottom of email banners, and across booth walls. One Sky Thread per layout.

### Social Graphics

Keep them simple. One headline in White Inter Bold on Cobalt or on the gradient, the reversed shield in the bottom right corner, and the Sky Thread underneath the headline. Product launches get a screenshot in the standard browser frame. Quote cards use a Navy background with Sky quotation marks. The templates in `/Brand/v3` are already sized for every network, so please start there and don't crop an old graphic.

### Iconography

Icons are line style, 2 px stroke on a 24 px grid, with rounded corners, in Cobalt or White. Please use the set in the shared drive, and ask before drawing a new one so the set stays consistent.

### Product screenshots

Show the product at its best! Use the demo environment, not a real tenant, and crop to the part of the screen that makes your point. Place screenshots in the standard browser frame on White or on the gradient. Highlight the key area with a Sky outline, 2 px.

---

## 9. Putting It All Together

### Slide decks

Use the Wickhold Security master template, which has the gradient opener, Cobalt section dividers and White content slides already built. Do not paste content into an older template. Slide titles should carry the point of the slide. The shield goes in the top right corner and the tagline goes on the closing slide.

### One-pagers and data sheets

Cobalt band at the top with the logo reversed, White body, Navy text. Include the proof point, a short product summary and the boilerplate at the foot of the page.

### Booth and events

Think big and blue! Booth backwalls use a full-bleed gradient with the reversed logo high enough to be seen over a crowd, the tagline at eye level, and the Sky Thread running along the counter. Staff wear Navy polos with the shield on the left chest. Keep the backwall copy to the tagline and one headline, since nobody reads a paragraph from across an aisle.

### Swag

Quality over quantity. Pick items people keep, such as good bottles, thick socks and well-cut T-shirts. Navy or Cobalt base with the reversed shield. Any vendor needs the vector logo files from Marketing, and we check a sample before we approve a run.

### Email signatures

Name, title, Wickhold Security, phone, then the tagline in Navy on its own line. Do not add a logo image, a banner or a quote. Signature images break in too many mail clients.

```
Jordan Sample
Senior Account Executive, Wickhold Security
+1 (303) 555-0100
Every workload. Always watched.
```

### Social avatars

All company accounts use the reversed shield on a Cobalt background. Founders and employees use their own photos on personal accounts.

### Website

The site uses Cobalt primary buttons with White labels, Navy text on White pages, and alternating gradient bands to pace longer pages. Every top-level page opens with a benefit-driven headline and a product visual.

### Video and Motion

Every video ends on the same five-second end card: the Cobalt-to-Sky gradient, the reversed logo, and the tagline underneath. The logo animates in with the flame rising from the base of the shield, using the supplied animation file. Do not build your own. Lower thirds use a Cobalt bar with White Inter SemiBold, and the Sky Thread can trace across the frame between sections. Music should be upbeat and modern, with a steady pulse.

Webinars use the same master template as decks, plus a holding slide with the session title on the gradient. Please test screen shares in the template before going live, since the Cobalt bands can swallow small text on a compressed stream.

### The Wickhold Field Report

The Field Report is our flagship piece of research and the source of our best numbers, so it gets the full treatment. Covers are full-bleed Cobalt with a large statistic set in Inter ExtraBold White, and inside pages use White with Sky chart accents. The lead finding from the 2023 edition, that 68% of runtime incidents began with a misconfigured workload, is the model to follow: one sharp number that a reporter can repeat. When you quote a Field Report figure, quote it exactly and name the edition.

### Website Components

The web team maintains a small component library, so please design with it and don't invent new pieces.

- **Hero:** gradient band, H1, one-line subhead, Cobalt button and product visual.
- **Logo bar:** customer and partner logos in single-color Navy, shown only with permission.
- **Stat band:** full-bleed Cobalt with one large number in White.
- **Feature grid:** three columns, each with a Cobalt line icon.
- **Footer:** Navy, with the reversed logo and the tagline.

### Slow Burn Summit

Our customer conference is a chance to have some fun with the brand! The event gets its own title lockup in Inter ExtraBold, always paired with the Wickhold Security logo. Stage screens use the gradient, badges use Navy, and the signage system follows the booth rules above. Please don't draw a separate logo for the event, for a track, or for a party. It has been tried, and we ended up with four of them on one banner.

### Data Sheets and Solution Briefs

Use this order, every time, so a reader who has seen one has seen them all:

1. Headline, with a one-sentence summary below it
2. The challenge, in two or three sentences
3. How the product solves it, with three benefits
4. A product screenshot or architecture graphic
5. Proof point
6. Boilerplate and a next step

Keep a data sheet to two sides. If the content runs longer, it wants to be a white paper.

### Customer Stories

A great customer story follows the arc of challenge, solution, results. Lead with the team's name and logo where we have permission, and pull one quote into a Cobalt callout box. Marketing tracks who has agreed to what, so please check with us before naming anybody.

### Press and Media

Only Maren, Dov and the VP Marketing speak to reporters on behalf of Wickhold Security. If someone contacts you, pass them to Ilse right away. Press releases use the standard dateline, one quote from a founder, and the boilerplate word for word at the end. Use the full-color logo on White in the press kit.

### File Names

Name working files clearly so that everyone can find them: project, piece, version. For example, `summit_booth_backwall_v2`. When a file is done, add `FINAL` to the name and move it to the shared drive so that nobody has to guess which one is approved.

---

## 10. Working With Partners

We are proud of the company we keep, and co-branding should show it.

- Place the Wickhold Security logo on the left, the partner logo on the right, with a thin Navy divider and equal visual height.
- Allow twice the normal clear space between the two logos.
- Never merge our logo into a combined mark.
- Send co-branded work to Marketing before it goes out. Many partners also have their own review process, so allow a few extra days.

Agencies and freelancers get this guide, the logo package and the master templates at kickoff. Please don't send them individual files from your desktop, because that is how old logos come back to life.

---

## 11. Asset Library and Requests

All approved logos, templates, icons and photography live in the Marketing shared drive under `/Brand/v3`. The logo package includes:

- Full logo, reversed logo and one-color logos as SVG, PNG and EPS
- Vertical lockups
- Standalone shield in Cobalt, White and Navy
- Favicons at 16, 32 and 64 px
- The Sky Thread as an SVG brush and a slide object
- Inter font files, for agencies that need them

To request something that isn't there, post in #marketing-design with what you need, where it will appear and when you need it. Please give us five working days for anything new.

---

### Common Mistakes

We see these all the time. Please help us stamp them out!

- Using the 2022 logo because it was in an old deck
- Writing "Wickhold" with no "Security" in a headline to save space
- Sky text on White, which nobody can read
- Pulling a low-resolution logo from the website and not from the drive
- Reversing the gradient
- Mixing Inter with whatever font the slide tool defaults to
- Rewording the tagline to fit a layout

---

## 12. Quick Checklist

Before anything goes out the door, run through this list!

- [ ] The name is Wickhold Security, in full
- [ ] The tagline is exact: *Every workload. Always watched.*
- [ ] The logo is the current v3 artwork with its clear space
- [ ] Colors come from the palette, led by Cobalt `#1F4FD8`
- [ ] All type is Inter
- [ ] Product names are spelled Wickhold Quenchline and Wickhold Tallowatch
- [ ] The boilerplate is word for word
- [ ] Any statistic has its source
- [ ] The piece sounds bold, vigilant and helpful

---

## Version History

| Version | Date | What changed |
|---|---|---|
| 1.0 | 2020 | First logo and color sheet, for the Quenchline launch |
| 2.0 | 2022 | Refreshed logo after the Series A, Tallowatch added |
| 3.0 | September 2024 | New shield-and-flame logo, Cobalt-led palette, Inter across everything, new messaging pillars |

Questions? Ideas? We'd love to hear from you: ilse@wickhold.example

© 2024 Wickhold, Inc. All rights reserved.
