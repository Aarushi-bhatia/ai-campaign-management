Logo and color addendum

Noor Eskelund, Brand. Rev. 2026-04-02, after the third round of print proofs.

The main guidelines tell you what the mark means and what the palette is for. This sheet has the numbers. It exists because the booth printer, two freelancers and the product team all asked the same questions in the three weeks after the February 10 launch. If you need a measurement, it should be here. If it isn't, write to noor@wickhold.example and it will be added here rather than answered in a thread.

## Logo files

The mark is a geometric W whose center stroke rises as a wick, tipped by one Ember dot. The lockup is the mark plus the wordmark "Wickhold". There are four approved variants, each supplied as SVG and PNG.

| Variant | W and wordmark | Dot | Background in the file |
|---|---|---|---|
| Ink on transparent | Soot `#15181C` | Ember `#C2501F` | None |
| Reversed on transparent | Tallow `#F4EFE6` | Ember `#C2501F` | None |
| On Tallow panel | Soot `#15181C` | Ember `#C2501F` | Tallow, with clear space built in |
| On Soot panel | Tallow `#F4EFE6` | Ember `#C2501F` | Soot, with clear space built in |

The dot is Ember in all four. There is no one-color version. On a single-color job such as laser engraving or a rubber stamp, the whole mark takes the one color and the dot is kept. We tested the mark without the dot on a batch of sample mugs and it read as a plain W.

The wordmark is set in Bricolage Grotesque Bold and then outlined. Never retype it. The files are drawn with optical corrections to the "k" and the "h" that the live font does not have.

Which variant to pick for a given layout is a usage question and is covered with the rest of the logo-in-context guidance. This sheet stops at the spec.

## Construction

For anyone redrawing the mark at a size the files don't cover, or checking a vendor's proof. All values are multiples of H, defined under clear space below.

| Part | Value |
|---|---|
| W overall width | 1.25H |
| Stroke weight | 0.16H |
| Wick rise above the top of the outer strokes | 0.4H |
| Dot diameter | 0.22H |
| Gap between mark and wordmark in the lockup | 0.5H |
| Wordmark cap height | 0.62H, centered on the W |

The center stroke is the same weight as the outer strokes all the way up. Early sketches tapered it, and it looked like a syringe.

## File names

The logo package uses one pattern: `wickhold-[mark|lockup]-[ink|reversed|tallow-panel|soot-panel].[svg|png]`. PNGs are exported at 2000 px on the long side. Send SVG to anyone who can open it. Send PNG only to people working in a slide tool or a document. If a supplier asks for EPS, export it from the SVG on the day and don't keep the copy.

## Clear space

Measure from the mark, not from the edge of the file. H is the height of the W, from baseline to the top of the two outer strokes. The wick and dot rise above that line and are not counted in H.

- **Mark alone:** clear space of 0.5H on all four sides.
- **Lockup:** clear space of 0.5H on all four sides, measured from the outer edges of the mark and the wordmark.
- **Top edge:** measure from the top of the dot, because the wick is the tallest point of the mark.

Nothing goes inside clear space: no text, no edge of an image, no second logo, no fold. Trim counts as an edge. On print pieces, measure clear space from the trim line, not from the bleed.

Panel variants already contain their clear space. Do not crop them, and do not place a panel variant inside another panel.

## Minimum sizes

| Use | Mark alone | Lockup |
|---|---|---|
| Screen | 24 px tall | 120 px wide |
| Print | 8 mm tall | 30 mm wide |
| Embroidery and engraving | 15 mm tall | 50 mm wide |

The mark's height here includes the wick and dot. Below 120 px wide the wordmark starts to fill in, so use the mark alone.

One exception: favicons and app icons at 16 px use the `small-cut` file, which thickens the strokes and enlarges the dot by a quarter. It is drawn for that size only. Do not scale it up, and do not use it anywhere else.

Embroidery got its own row after the Slow Burn Summit sample jackets. At 8 mm the dot came back as a brown knot.

## Typical placements

These are the sizes used in the master templates. Check them before changing a template.

| Piece | Version | Size | Position |
|---|---|---|---|
| 16:9 slide, 1920 x 1080 | Mark alone | 40 px tall | Bottom left, 48 px in |
| Title slide | Lockup | 280 px wide | Top left, 96 px in |
| US Letter one-pager | Lockup | 40 mm wide | Top left, inside the margin |
| Report cover | Lockup | 60 mm wide | Bottom left |
| Website header | Lockup | 132 px wide | Top left |
| Booth backwall, 3 m | Lockup | 1.2 m wide | Top third, so it clears a crowd |
| Lanyard | Mark alone | 18 mm tall | Centered, once per lanyard |

## Co-branding

When the mark sits next to a customer's or partner's logo, match optical height, keep 1H between the two, and separate them with a Whetstone hairline only if the partner's own rules require it. Wickhold goes on the left unless the partner is hosting. Whether you may show that logo at all is a legal question and is not decided here.

## Do not

- Recolor the dot, or the W, in anything outside the table above.
- Rotate, slant, outline, shadow or animate the mark. The product team's flickering-dot loading state was withdrawn in February.
- Place the mark on a busy photograph without a panel behind it.
- Stack the wordmark over the mark. There is no stacked lockup. Use the horizontal lockup or the mark alone.
- Rebuild the mark in a slide tool. Insert the SVG.

The 2024 shield-and-flame logo and the "Wickhold Security" wordmark are retired. Anyone holding those files should delete them, and any supplier still printing from them should get new files from Brand.

## Color values

All five values come from the master swatch file. Screen values are exact. CMYK values are the converted starting point, and print jobs get a proof before a run because Ember shifts toward brown on uncoated stock.

| Name | Role | Hex | RGB | HSL | CMYK |
|---|---|---|---|---|---|
| Ember | Primary | `#C2501F` | 194, 80, 31 | 18, 72%, 44% | 0, 59, 84, 24 |
| Soot | Ink | `#15181C` | 21, 24, 28 | 214, 14%, 10% | 25, 14, 0, 89 |
| Tallow | Ground | `#F4EFE6` | 244, 239, 230 | 39, 39%, 93% | 0, 2, 6, 4 |
| Whetstone | Secondary | `#5E6B73` | 94, 107, 115 | 203, 10%, 41% | 18, 7, 0, 55 |
| Verdigris | Secondary | `#2F8F83` | 47, 143, 131 | 172, 51%, 37% | 67, 0, 8, 44 |

For web and product code, use these names:

```css
:root {
  --wh-ember: #C2501F;
  --wh-soot: #15181C;
  --wh-tallow: #F4EFE6;
  --wh-whetstone: #5E6B73;
  --wh-verdigris: #2F8F83;
}
```

## Proportions

On a typical page or slide, aim for this mix:

| Color | Share of the layout |
|---|---|
| Tallow or Soot as ground | 60 to 70% |
| The other of the two, as type and blocks | 20 to 30% |
| Ember | 10% at most |
| Whetstone and Verdigris | What is left, as supporting detail |

Ember above 10% stops reading as a focal point. The first draft of the rebrand launch page had an Ember hero band, and everything on it looked like a warning.

Tints: Whetstone at 20% is allowed for table lines and hairlines. Tallow may darken by 4% for alternating table rows. Ember, Soot and Verdigris have no tints. No gradients between palette colors.

## Measured contrast

These are the calculated ratios for every pairing of the palette that comes up in layouts. "Body text" says whether the pairing clears the accessibility requirement at normal text size.

| Foreground on background | Ratio | Body text |
|---|---|---|
| Soot on Tallow | 15.55:1 | Yes |
| Whetstone on Tallow | 4.79:1 | Yes |
| Verdigris on Soot | 4.56:1 | Yes |
| Ember on Tallow | 4.11:1 | No, display sizes only |
| Ember on Soot | 3.78:1 | No, display sizes only |
| Verdigris on Tallow | 3.41:1 | No, display sizes only |
| Whetstone on Soot | 3.24:1 | No, display sizes only |

The two that catch people out are Ember links on Tallow and Tallow labels on an Ember button, both 4.11:1. For small links, use Soot with an underline. For a small button label, make the label bold and larger, or use a Soot button.

Ember next to Whetstone or Verdigris is 1.17:1 and 1.21:1. Those pairs differ in hue and hardly at all in lightness, so never use them for text or to carry meaning on their own.

## Printing and materials

- **Coated stock:** the CMYK values above, proofed once.
- **Uncoated stock:** raise Ember's yellow by about 5 points and check the proof. Tallow as a printed flood tends to look dirty, so print on a warm off-white paper and leave the ground unprinted.
- **Fabric and vinyl:** match to a physical swatch from Brand, not to a screen. The booth vinyl for Field Day came back closer to terracotta the first time, and the supplier now holds a signed swatch.
- **Soot floods:** ask for a rich black build on large areas. Plain K at that size looks grey and shows banding.
- **Metallics:** no foil or spot metallic on the dot. It stops being Ember.

## Before sending files to a supplier

1. Use files from the current logo package, not a copy from an old deck.
2. Confirm the size clears the minimum for that process.
3. Mark clear space on the proof if the supplier is new.
4. Ask for a physical proof on anything over 200 units.
5. Send the proof to Brand. Two working days is usually enough.

## 2024 to 2026 color map

For anyone converting an old file:

| Old | New |
|---|---|
| Cobalt | Ember, used far more sparingly than Cobalt was |
| Navy | Soot |
| White ground | Tallow |
| Sky | Whetstone or Verdigris, chosen case by case |
| Cobalt-to-Sky gradient | Nothing. Use a flat ground |
| Inter | Bricolage Grotesque for headlines, IBM Plex Sans for body, IBM Plex Mono for code |

Do not find-and-replace. Cobalt filled whole slides and page bands, and Ember swapped in at that scale fails the proportions above. Rebuild the layout on a Tallow or Soot ground.
