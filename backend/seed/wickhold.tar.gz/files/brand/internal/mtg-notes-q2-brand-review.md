# Q2 brand review: meeting notes

**Date:** Thursday June 11, 2026, 10:00 to 11:30, Denver office and video
**Present:** Noor Eskelund (chair), Ilse Varga-Holm, Priit Salonen, Kofi Anselm. Maren joined for the last 20 minutes.
**Notes:** Noor

Agenda was sent the day before. Actions at the end.

## Rebrand cleanup status

Four months in. Ilse's summary: the outward-facing work is mostly done and the long tail is annoying.

- Website: no Wickhold Security left in page templates. A few PDFs in the old docs tree still carry it. Kofi wants to delete them rather than fix them. Agreed, once he's checked inbound links.
- Tallowatch: renamed everywhere customers see it. The old `wickhold/tallowatch` chart keeps shipping until September 30. Support macros were updated in May.
- Cobalt slides: sales had two old deck versions still circulating. Ilse has asked sales ops to pull them from the shared library. Noor to check again in July.
- Brand folder: a mess, and everyone knows it. Old guidelines are still sitting next to new ones. Noor would like a cleanup sprint but there's no time before Summit. Parked until Q4.

## Hashtags on X

Kofi takes over the X account on Monday, so this needed settling now.

Marketing had been adding two or three hashtags to X posts since about 2024. Kofi pulled six months of posts. Those with hashtags did no better than those without, and the ones with the most hashtags got the most spam replies. Engineers he asked said hashtags make a post look like marketing.

Ilse asked if we should keep one for Slow Burn Summit. Kofi said people will make their own if they care. Noor agreed.

**Decision: no hashtags on X.** None, on any Wickhold account, including event and launch posts. Applies from Monday. Kofi to add the DevRel team to the review list so scheduled posts get cleaned up too.

Priit had no objection and asked for it to be minuted, as it's the kind of thing that gets forgotten. It's minuted.

## Report performance

The Wickhold Containment Report 2026 published April 14. Ilse reported that downloads were ahead of last year, helped by leaving it ungated. Sales says the report conversations are better than the old form-fill leads were, though nobody can prove it yet.

Kofi wants to do more with the raw data. Priit is fine with new cuts as long as he sees them before they go out, and anything with a base under 50 respondents stays internal. Noor to add four report posts to the Q3 blog calendar.

Containment Report 2027 survey: draft in October, field in January. Ilse to find budget.

## Leashgate early access

Open since May. Ilse: inbound interest is higher than product can onboard. Accounts are being approved by hand. Product asked marketing to hold off on paid.

Discussion on how much we say publicly. Kofi's tool-call policy walkthrough did well with engineers. Priit reminded everyone that the release notes are where the current product status is recorded and marketing should check there before writing.

No paid for Leashgate this quarter. Revisit in Q3.

## Customer proof

Lowmoor and Ostler are carrying nearly all of it, and we use them for everything. Ilse would like two more stories by the end of the year.

- Vaskell Health: draft case study exists, and sales keeps asking. Priit says their legal team has not cleared it and he doesn't know when they will. It stays where it is. Ilse will speak to sales again.
- Noor asked customer success for a list of accounts that have completed a full rollout. Three candidates so far, none approached yet.

## Summit planning

Registration page is live this week. Speaker list is almost set. Tomas Beaulieu-Kerr's slot comes out, since he's leaving at the end of the month. Dov will take the field session or find someone from his team. Kofi to run customer speaker rehearsals in August. Maren wants more working sessions and fewer talks, and she's the one paying for the room, so day two is all working sessions.

## Style questions from the team

Short list collected from the channel.

- "Early access" hyphenation: no hyphen as a noun or adjective. Noor to confirm against the style guide.
- `kubectl` always lowercase and in code format, even at the start of a sentence. Kofi prevailed over a copy editor.
- "On-call" hyphenated as an adjective, "on call" otherwise. Kofi says nobody cares. Noor cares.
- Can we say "runtime incident" and "runtime failure" interchangeably? For now, yes. The report uses "incident", so stick to it when quoting.

## Agency and contractors

Ilse confirmed the keyword agency contract ended in May. The two blog contractors stay through Q3. Noor asked that contractors get read access to the brand folder only once it has been tidied, otherwise they'll quote old files. Until then Noor sends them the specific documents they need. Kofi asked for one contractor to help with the throwaway test cluster docs. Not approved.

## Maren's items

Maren joined at 11:10. Two things.

She has read too many drafts that begin with how the industry is changing and wants them to start with what happened. Noor said the guidance already points that way, and the issue is drafts getting through without an editor. Ilse will make sure the contractors know.

She also asked whether the voice guide could have more examples of us admitting what the product can't do. Noor to add a few at next revision.

## Actions

| Who | What | When |
|---|---|---|
| Kofi | Check inbound links, then delete old PDFs | June 19 |
| Kofi | Add DevRel to X review list | Monday |
| Noor | Re-check sales library for Cobalt decks | July |
| Noor | Add report posts to Q3 calendar | June 26 |
| Noor | Confirm "early access" style | Next review |
| Ilse | Talk to sales about Vaskell Health | This week |
| Ilse | Budget for 2027 report survey | Q3 planning |
| Dov (via Noor) | Cover the field session at Summit | June 30 |

Next review: September, after Summit. Noor to send a date.
