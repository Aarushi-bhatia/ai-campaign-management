Slack export: #marketing, 2026-01-08 to 2026-10-16
Exported by Noor for the brand folder. Bot messages and file uploads removed.

[2026-01-08 09:12] Ilse: reminder that nothing about the new name or logo leaves this channel until Feb 10. Teasers only. "Something's changing" is as far as we go
[2026-01-08 09:15] Kofi: does that include the eng team? half of them have seen the wick mark on Noor's screen
[2026-01-08 09:16] Noor: they've all signed the same thing you did
[2026-01-08 09:20] Kofi: Dov already has it as his desktop background
[2026-01-14 13:02] Noor: Cobalt is dead to me but we still have 400 stickers. Anyone want them for the Field Day box?
[2026-01-14 13:05] Ilse: until Feb 10 sure. After that, recycling
[2026-01-22 16:40] Tomas: field team needs the new deck before the 10th or we'll be presenting Wickhold Security to a room of customers on the 11th
[2026-01-22 16:44] Ilse: you'll have it on the 6th, Tomas
[2026-02-09 18:31] Noor: final check. Press release is scheduled, site cutover is at 6am Mountain, redirects tested. Kofi, can you babysit the docs subdomain?
[2026-02-09 18:33] Kofi: yes. Setting an alarm like it's a kernel upgrade
[2026-02-10 06:22] Kofi: docs are up. New logo showing. One broken favicon, ignoring it until coffee
[2026-02-10 08:47] Maren: Thank you all. I read every line of the announcement twice and didn't want to change any of it, and that has never happened before.
[2026-02-10 08:50] Ilse: screenshotting that
[2026-02-17 11:03] Noor: still finding Wickhold Security in old PDF footers on the site. If you spot one, drop the URL in here, don't fix it by hand
[2026-02-17 11:30] Kofi: https://wickhold.example/docs/legacy/install-guide.pdf
[2026-02-17 11:31] Kofi: also this one is 40 pages and I'd rather we delete it
[2026-02-25 15:15] Ilse: reminder: Tallowatch becomes Evenburn on Monday March 2. Product marketing has the swap list
[2026-02-25 15:19] Priit: order forms update the same day. Sales ops is on it
[2026-02-25 15:21] Noor: I'll buy lunch for whoever finds the last Tallowatch on the marketing site
[2026-03-03 10:02] Kofi: the old wickhold/tallowatch chart keeps shipping until September 30, engineering knows. Please stop filing tickets about it
[2026-03-11 14:26] Ilse: pricing page moved to the new tiers. Scale tier is gone, sales has the migration note. Send any questions from customers to me
[2026-03-11 14:40] Noor: did anyone else's parking pass stop working
[2026-03-11 14:41] Kofi: the whole second level. Facilities says Friday
[2026-03-24 10:11] Priit: for the Containment Report: survey base is 412. Every chart needs that base stated somewhere on the page. Not negotiating this
[2026-03-24 10:13] Noor: fine by me. Design has it
[2026-04-14 07:58] Ilse: report is live. Thank you all, especially Kofi's team for the 2am chart fixes
[2026-04-14 12:30] Kofi: first engineer reply on X: "finally a vendor survey with a sample size." We'll take it
[2026-04-21 09:44] Noor: if you're writing about the report, the two numbers are approved exactly as Priit signed them. Copy them from the claims doc. Don't retype from memory
[2026-05-12 10:18] Ilse: Leashgate early access is open. Product is approving accounts one by one, so don't send the form link around
[2026-05-12 10:21] Kofi: can I blog the tool-call policy walkthrough
[2026-05-12 10:22] Ilse: yes, with "early access" in the title
[2026-05-19 16:22] Noor: Maren read the Field Day invite on her phone at the airport and asked me to pass this on. She hates exclamation marks in email subject lines. Hates. No exclamation marks in any of our email subject lines from now on. She said a calm company doesn't shout at people's inboxes
[2026-05-19 16:24] Ilse: who wrote "See you in Austin!"
[2026-05-19 16:24] Kofi: I plead the fifth
[2026-05-19 16:26] Noor: taking it out of the shared drafts now. Does an exclamation mark in the body count?
[2026-05-19 16:31] Maren: Subject lines are what I see. Use your judgment everywhere else.
[2026-05-28 09:05] Noor: for the case study queue, Vaskell Health is still with their legal team. Don't build anything around it yet
[2026-05-28 09:06] Ilse: sales keeps asking. I'll talk to them
[2026-06-03 17:12] Ilse: sharing before the all-hands: Tomas Beaulieu-Kerr is leaving at the end of the month. Noor, can you pull him from the Summit speaker draft? I'll sort out who covers field engineering
[2026-06-03 17:15] Noor: done. Do we need to go through the photo library too?
[2026-06-03 17:16] Ilse: yes but not today
[2026-06-09 11:20] Kofi: X is mine now as of Monday. Please send me launch posts by Thursday and don't schedule straight into the account
[2026-06-16 14:02] Noor: new shared font folder is up. Install Bricolage Grotesque from there, not from whatever you downloaded in January
[2026-06-16 14:05] Kofi: my browser insists it's fine
[2026-06-16 14:06] Noor: your browser is why I made the folder
[2026-07-08 10:33] Ilse: Summit registration is pacing ahead of last year. Field marketing, please stop adding your friends
[2026-07-22 15:50] Priit: two reminders from a contract review. Don't use a customer's logo in a deck because it was in someone else's deck. And if a quote has been edited since approval, it needs approving again
[2026-07-30 09:12] Dov: Need someone to proofread the roadmap talk. Not the claims, just whether a human can follow it.
[2026-07-30 09:14] Kofi: on it. How many slides
[2026-07-30 09:14] Dov: 71
[2026-07-30 09:15] Kofi: I take it back
[2026-08-12 13:44] Noor: LinkedIn playbook updated, same place as before. Please read it before asking about Maren's queue
[2026-08-27 11:08] Ilse: who has the spare portable cluster
[2026-08-27 11:19] Kofi: in my car, along with one adapter short of a full kit
[2026-09-09 18:02] Noor: Run-through went fine. Test clusters rebuilt clean. AV in the small room hums, venue is sending someone
[2026-09-15 08:30] Ilse: Summit day one. Doors at 8:30, Maren on at 9:15. Phones on, please, somebody will need something
[2026-09-15 14:12] Kofi: Dov's policy demo went wrong in exactly the way he planned and got the biggest laugh of the day
[2026-09-16 17:40] Maren: Thank you, all of you. The table sessions were the best thing we've done at this conference.
[2026-09-22 10:01] Ilse: recap post goes Wednesday. Use the marked event photos only in the recap, please, Noor has the list
[2026-10-05 16:15] Noor: Q4 planning doc is in the drive. Add your items by the 12th or they don't exist
[2026-10-07 09:48] Kofi: booth rota for November is up. If you were on call the night before, swap with someone
[2026-10-14 12:05] Ilse: does anyone actually use the second kitchen fridge
[2026-10-14 12:09] Noor: Kofi's fermentation project lives in there
[2026-10-14 12:10] Kofi: it's a sourdough starter and it has a runbook
[2026-10-16 10:22] Ilse: the 2027 Containment Report survey draft goes to Priit next week. Send any new questions before Friday
