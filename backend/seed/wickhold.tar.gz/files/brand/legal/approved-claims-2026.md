# Approved claims, 2026

Owner: Priit Salonen, General Counsel
Revision 7, 28 September 2026. Replaces revision 6.

This document lists what Wickhold may say about itself, what it may say only with a qualifier, and what it may not say. It governs marketing, sales, developer relations, press and customer success. Founder posts are included. A signature does not change the facts.

If a claim is not listed, it is not approved. That does not mean it is refused. It means nobody has checked it. Send the sentence, the proposed channel and the evidence to priit@wickhold.example. Copy under 500 words comes back within two working days. Reports, press releases and anything with a customer name take five. "Legal said it was fine on a call" is not a record, and I will not recognize it later.

Wording in quotation marks is exact. Do not improve it.

## 1. Claims approved as written

| Topic | Approved wording | Evidence held by |
|---|---|---|
| Customer count | "more than 140 customers" | Finance, reconciled quarterly |
| Market, time to contain | "41% of platform teams need more than six hours to contain a runtime incident" | Wickhold Containment Report 2026 |
| Market, median | "the median time to contain a runtime incident is 7.4 hours" | Wickhold Containment Report 2026 |
| Lowmoor Credit Union | Time to contain fell from 4 hours to 11 minutes, 220 nodes | Signed customer approval |
| Ostler Grocers | 63% fewer open critical misconfigurations in 90 days, 1,900 nodes | Signed customer approval |
| SOC 2 | Wickhold holds SOC 2 Type II, renewed January 2026 | Legal |
| Agent policy | "limits what a compromised agent can do" | Legal and product |
| Company | Founded in March 2019 in Denver, Colorado | Legal |
| Funding | Series B of $46M in June 2024, led by Marlbank Partners | Legal |

The Containment Report was published on April 14, 2026, and surveyed 412 platform and security leaders. Give the survey size when the copy has room for it. The legal entity is Wickhold, Inc. Contracts, order forms, privacy notices and page footers use that form. Marketing copy uses Wickhold.

### Customer count

The only approved claim is "more than 140 customers". The following are not approved: "140+ customers", "nearly 150 customers", "hundreds of customers", "thousands of engineers", or any count of nodes, clusters or workloads summed across the customer base. Finance reconciles the number each quarter against active contracts. Pilots, lapsed accounts, open-source users, and companies that attended Slow Burn Summit are not customers for this purpose.

When the reconciled number supports a higher claim, this document will change. Until it does, the number in a sales deck, a conference bio or a partner page is the number here. If you have seen a larger figure in circulation, it is wrong, and I would like to know where you saw it.

## 2. Claims that need a qualifier

### Lab figures

Two product figures come from Wickhold's own lab. Both must carry the phrase "in Wickhold lab benchmarks, 2026", in the same sentence as the figure.

| Figure | Required form |
|---|---|
| CPU overhead | "under 2% CPU overhead on a typical node in Wickhold lab benchmarks, 2026" |
| Containment speed | "contains a known-bad process in a median of 38 seconds in Wickhold lab benchmarks, 2026" |

A footnote does not meet this requirement. An asterisk does not meet it. A qualifier on the slide before does not meet it. In a chart, the phrase goes in the chart title or directly under it. In a talk, the speaker says it aloud.

The figures describe a lab, so they may not be presented as field results or customer averages. "Known-bad process" is part of the claim: it does not extend to unknown processes, novel techniques, or "threats" in general. Reports may repeat the figures only if the benchmark year stays attached. When the 2027 benchmarks run, the year changes and this table is reissued. Nobody edits the year by hand.

Approved:

> Wickhold Quenchline adds under 2% CPU overhead on a typical node in Wickhold lab benchmarks, 2026.

Not approved:

> Quenchline contains attacks in 38 seconds.

> Under 2% overhead. Guaranteed.

### Market statistics

Name the source and the year each time. A market statistic in a headline needs its source on the same screen or page section. See section 5 for how long a statistic stays usable.

### Customer results

Keep the node count with the result. The Lowmoor outcome belongs to a 220-node estate and the Ostler outcome to a 1,900-node estate, and neither may be stated as what a new customer should expect. Do not convert the Lowmoor result into a percentage or a multiple. Nobody approved that arithmetic. Do not combine the two results in one sentence, because that reads as a single program with both outcomes. Which customers may be cited, and how, is covered by the logo and quote policy.

### Product behavior

Wickhold Quenchline takes a containment action only in contain mode. In observe mode it records what it would have done. Copy describing automatic containment must therefore be true of contain mode and should say so where a reader could assume otherwise. Containment actions are isolating a pod's network, freezing a process and draining a node. Do not add to the list without product confirmation.

Wickhold Evenburn reports drift, exposure paths and a fix order. It does not change a customer's environment by itself, and copy should not imply that it does.

### Wickhold Leashgate (early access)

Leashgate is in early access. Claims describe what the early access product does today. They do not describe a roadmap, and they do not give a date.

Permitted vocabulary is tool-call policy, agent identity, and the blast radius of an agent. The approved outcome statement is "limits what a compromised agent can do".

## 3. Banned claims

| Do not say | Say instead, or do this | Reason |
|---|---|---|
| "prevents prompt injection" | "limits what a compromised agent can do" | Leashgate acts on tool calls. It does not read intent and it cannot promise that an agent will not be manipulated. The claim is false as a matter of product design |
| "FedRAMP Authorized", "FedRAMP certified" | See section 4 | Neither is true |
| "GDPR compliant" | Use the regional rules | Regional wording sits there, and the ban is not limited to that region |
| "breach-proof", "unhackable", "impossible to escape" | Describe the containment action | No security product can support an absolute |
| "zero false positives", "100% detection", "catches everything" | Give a sourced figure or say nothing | We hold no such evidence |
| "guarantee", "guaranteed", "warranty" outside a contract | Remove | These words have legal effect. Service credits live in the order form |
| "the leading", "the fastest", "No. 1", "the only" | Remove, or bring me the comparison data | Superlatives need current comparative substantiation, and we do not hold any |
| "certified by", "endorsed by", "partner of" for any standards body or open-source project | Remove | Using eBPF or Helm is not an endorsement from anyone |
| "saves $X", any return-on-investment figure | Remove | We have no approved financial outcome for any customer |

Two refinements, because they keep coming back:

"Helps prevent" is a banned claim dressed up. A qualifier in front of a promise does not make it a limited promise.

"Compliance-ready" and "audit-ready" were requested in June for a trust page and refused. Wickhold can describe what the product records. Whether a customer passes an audit depends on the customer and the auditor.

## 4. Certification status

SOC 2 Type II: held. Renewed January 2026. The report is shared under NDA through the account team.

FedRAMP Moderate: in process. The approved sentence is "Wickhold is pursuing FedRAMP Moderate authorization." Never state or imply FedRAMP authorization or certification. The status sheet has the detail and is the first thing to check.

## 5. Statistics: 12-month age limit

A market statistic may not be older than 12 months at publication. This is the limit on how old a statistic can be, and it is measured on the day the piece goes out, not the day it was drafted. A post queued in March for release in May is checked against May.

The limit applies to market and survey statistics only. It covers any figure that describes the industry, the market, or a population of teams. It does not apply to customer results such as the Lowmoor and Ostler outcomes, or to product metrics such as the lab figures, which have their own qualifier.

The age of a statistic runs from the publication date of its source. Fieldwork dates do not matter. A report re-quoted in a newer article keeps its original date, so a 2026 article quoting a 2024 survey is a 2024 statistic.

Applied to our own reports:

| Source | Published | Status |
|---|---|---|
| Wickhold Containment Report 2026 | April 14, 2026 | Usable for publication through April 14, 2027 |
| Wickhold Field Report 2024 | 2024 | Past the 12 months limit |
| Wickhold Field Report 2023 | 2023 | Past the 12 months limit |

The two Containment Report statistics in section 1 are the only market statistics of ours inside the limit today. The Field Report figures still appear in old decks and old posts. That is an archive problem and not a permission. Do not reuse them. Do not reword them to make them feel new, and do not refer to them as "historically" true.

Fresh third-party statistics are allowed without coming to me first, with the source link and the date of the source in the copy. The source must be a named publisher and the figure must appear on the page you link to. A figure found in a vendor's blog, quoting another vendor's blog, gets traced to the original or is dropped. The third party's name still has to clear the competitor rules.

When the 2027 Containment Report is published, section 1 will be updated and the 2026 figures remain usable until they reach the limit. Old assets stay in the archive as they are. They are not re-promoted once a market statistic in them has expired. Paid and email reuse counts as publication.

## 6. Breach and incident references

This section sets how Wickhold may talk about breaches and other public incidents, in any channel.

1. Never name a victim. That covers company names, product names, and descriptions that identify one ("a large regional retailer in the week it made the news").
2. No humor. Not in the copy, not in the image, not in a speaker's aside.
3. Nothing within 30 days of a public incident. Count from the first public disclosure. For the 30 days, Wickhold does not publish, post, send or sponsor anything that refers to the incident or that is plainly timed to it. An incident is not a marketing hook.

After 30 days, a breach may be discussed in general terms only, as a pattern and without identifying anyone. A technical analysis of a technique is fine if it does not rely on the incident for attention.

The rules cover paid media, social, email, blog posts, sales sequences, talks and replies to journalists. They apply to personal LinkedIn accounts when the post mentions Wickhold or its products. Press inquiries about a live incident go to Ilse Varga-Holm, and nobody comments before she has spoken to me.

If a campaign in market could be read as a reaction to a new public incident, whoever notices it pauses it and tells Ilse. Nobody will be criticized for pausing. Sales may answer a direct customer question about an incident with facts about the customer's own deployment. It may not use the question as an opening.

Incidents at Wickhold customers are never discussed without the customer's written approval, whatever their age. The approved Lowmoor material is the model. It has a figure and no drama.

Not approved:

> After last week's breach at a regional bank, can your team afford another six hours?

Approved, more than 30 days after any related event:

> When a pod misbehaves, Wickhold Quenchline in contain mode can isolate its network while the on-call engineer works out what happened.

## 7. Rulings from this year

Requests I have already answered. They are listed so that I do not answer them again.

| Request | Ruling |
|---|---|
| "Trusted by more than 140 customers" | Allowed. The count stays exact |
| "Trusted by credit unions" | Refused. One customer is not a plural |
| "Agentless" or "agent-free" for Quenchline | Refused. It uses an eBPF agent. Say so |
| "Lightweight" | Allowed only next to the CPU overhead figure and its qualifier |
| "Real-time" for Quenchline | Allowed for detection. For containment, use the lab figure or leave it out |
| "Stops the attack" | Refused. Name the containment action: isolate a pod's network, freeze a process, drain a node |
| "Automatic remediation" for Evenburn | Refused. Evenburn gives a fix order and people do the fixing |
| "AI-powered" for any product | Refused unless product confirms in writing what the model does. Writing about AI agents does not make the product AI-powered |
| "Secures your AI" or "safe AI" for Leashgate | Refused. Describe tool-call policy and agent identity |
| "SOC 2 certified" | Refused. Say "holds SOC 2 Type II" |
| "Used by your peers" in a sector email | Refused unless a named, approved customer in that sector is shown |
| "Battle-tested" | Refused. It implies a history of incidents at customers that we have not disclosed and may not disclose |

## 8. Spoken claims, demos and records

Spoken claims count. A webinar is a publication, a sales call can end up quoted in a procurement file, and a recorded conference talk stays available for years. Speakers get the same tables as writers. Questions from the floor that go beyond them are answered with "I will get back to you", and then with an email to me.

Demo environments show synthetic data. A demo may show a containment action in contain mode, and the timing shown on screen is not a claim about customer environments. Presenters should say so if anyone asks. Screenshots from a real customer tenant are not used in any circumstance.

The owner of each asset keeps the published version, or a link to it, and the source for each figure in it for three years. When a claim is withdrawn I will send a list of the assets I know about. I do not know about all of them, so owners should search their own material.

## 9. Review, exceptions, and how this document changes

Every piece of external copy containing a claim from section 1 or 2 is reviewed against this document by its author. Copy containing a new claim, a customer name, or a reference to a security incident also comes to me. Press releases and the annual report come to me regardless.

Exceptions are given in writing, for one asset, and expire with that asset. I have given two this year. Neither should be taken as a precedent.

If this document disagrees with a guideline, a playbook, a deck or a comment from a senior colleague, this document wins. If it disagrees with reality, tell me, and I will change it.

Reviewed each quarter with Ilse Varga-Holm and Noor Eskelund.

### Change log

- 2026-09-28: Refined the benchmark wording for charts and talks. Added the "audit-ready" refinement and section 8.
- 2026-06-11: Added third-party tracing requirement to section 5.
- 2026-05-12: Added Leashgate claims for early access.
- 2026-04-20: Added Containment Report 2026 statistics. Withdrew the Field Report figures.
- 2026-02-10: Reissued for the new company name. Customer count updated.
- 2026-01-22: SOC 2 renewal recorded.
