Certification status: sheet kept by Priit Salonen. Last checked 2 October 2026.

Sales, this is the sheet to use before you answer a security questionnaire. If a deck or an old email says something different, the deck or the email is out of date.

| Program | Status | What you may say |
|---|---|---|
| SOC 2 Type II | Held. Renewed January 2026 | "Wickhold holds SOC 2 Type II." |
| FedRAMP Moderate | In process. Not held | "Wickhold is pursuing FedRAMP Moderate authorization." |

**FedRAMP.** Never claim FedRAMP authorization or certification. The approved wording above is the only wording. It goes in copy exactly as written, including the word "pursuing".

These are banned in every channel, spoken or written: "FedRAMP Authorized", "FedRAMP certified", "FedRAMP Ready", "FedRAMP compliant", "FedRAMP equivalent", "built to FedRAMP standards". Agency buyers read those words literally, and a false statement to a federal buyer is a contract and legal problem, whatever the deal size.

The status changes when authorization is complete and published, and this sheet says so. An assessor's visit, a sponsor conversation, or a positive meeting does not change it. Do not give prospects a target date. We do not publish one. If a federal prospect presses, the answer is the sentence above and an offer to connect them with me.

Good, in an answer to a questionnaire:

> Wickhold holds SOC 2 Type II, renewed January 2026. Wickhold is pursuing FedRAMP Moderate authorization. We can share the SOC 2 report under NDA.

Bad:

> We're basically FedRAMP Authorized, the paperwork is just finishing up.

**SOC 2.** The report goes out under NDA through the account team, never by public link. Say "Type II" every time. Say "held" or "renewed", and do not say "SOC 2 certified", because SOC 2 ends in an attestation report and not a certificate.

**Questionnaires and RFPs.** Security questionnaires go through the account team, and any answer about certifications is copied from this sheet. If a form offers only "Yes" or "No" for FedRAMP, answer "No", and use the comments box for the approved sentence. Do not tick a box in the hope of explaining later.

**Website and decks.** Trust pages show what is held. When Noor's team updates a page or a master deck, they check it against this sheet first. The date at the top is the date I last confirmed both rows with the auditor and the compliance lead.

**Anything else.** If a prospect asks about a program that is not on this sheet, the answer is not yes. Send the question to priit@wickhold.example and wait. Customers running regulated workloads can have their own obligations, and helping them is not the same thing as Wickhold holding a certification.
