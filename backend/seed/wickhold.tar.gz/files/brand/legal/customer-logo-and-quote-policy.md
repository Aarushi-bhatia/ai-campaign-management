# Customer logo and quote policy

Maintained by Legal. Reviewed by Priit Salonen and Noor Eskelund, July 2026.

Cite only customers listed as approved below. That covers names, logos, quotes, results, case studies and any description that would let a reader work out who the customer is. A customer who likes us on a call has not approved anything.

## Approved

| Customer | Name and logo | Quote | Result |
|---|---|---|---|
| Lowmoor Credit Union | Approved | Hana Brandvold, CISO. Approved | Time to contain fell from 4 hours to 11 minutes, 220 nodes |
| Ostler Grocers | Approved | Rafe Mulcahy, VP Infrastructure. Approved | 63% fewer open critical misconfigurations in 90 days, 1,900 nodes |

Use the quote as it stands in the signed approval, with the person's name, title and company. Do not trim it so that the meaning shifts, stitch two quotes together, or update a title without asking. The written approval sits with Legal. If someone on the list changes jobs, stop using the quote until Legal has confirmed it.

Approvals cover website, email, social, sales decks, reports and event slides. They do not cover paid advertising or press releases. Each of those goes back to the customer through the account owner, one asset at a time.

Logos come from the brand library, in the supplied one-color versions. Don't recolor one, crop it, or take it from the customer's website. On a logo wall, keep the customers in alphabetical order so that nobody reads an endorsement ranking into it. Don't tag either company, or its people, on social unless the account owner has checked first. Sales emails may mention an approved customer by name, and may attach the approved case study, but may not offer a customer's contact details. Reference calls go through the account owner.

## Not cleared

**Vaskell Health is not cleared.** Do not use the name, logo, people, quotes or results in anything external, and do not use them in a customer-facing deck. "A large health system" does not help, because the draft material is specific enough to identify them. The draft case study in the folder stays a draft. No approval was given, and a finished-looking layout does not change that.

Everyone else is not cleared by default. Companies seen in a contract, in a support ticket, or in a Slow Burn Summit attendee list are not references.

## Anonymous examples

An unnamed customer story needs the same evidence as a named one and Legal's review of the wording. Keep the sector broad and leave out numbers that could be traced. Do not invent a composite customer.

## Adding a customer

1. The account owner confirms the customer is willing and names the person who can sign.
2. Noor's team drafts the wording and the logo use.
3. The customer signs a written approval that lists the asset types covered.
4. Legal adds a row to this table. Copy may go out after that, not before.

Allow three weeks. Regulated customers usually take longer.

## Withdrawal

A customer may withdraw at any time. Legal tells Noor, and owned assets are changed within five working days. Logo walls in decks are updated the same week. Events that have already printed are the only exception.
