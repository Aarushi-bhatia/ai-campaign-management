## Regional rules: EU and UK copy

Priit Salonen, with notes from the field marketing review, August 2026

Applies to anything aimed at readers in the EU or the UK: campaigns, event pages, email sends, localized landing pages, press outreach, partner co-marketing. If a global asset will run in those regions, it is regional copy too.

### GDPR wording

Never say "GDPR compliant". Not about Wickhold, its products, its customers' deployments or any feature. The ban began with EU and UK copy and it now applies everywhere, including US pages that a European buyer can obviously read.

The approved wording is:

> Wickhold supports customers' GDPR obligations.

Use it as written. GDPR obligations belong to the controller and the processor and depend on what they do with the data. No vendor product can make a customer compliant, and a regulator or a procurement lawyer will read the phrase as a promise.

Variants that have turned up in drafts, all refused:

- "GDPR-ready"
- "fully GDPR aligned"
- "compliant with EU privacy law"
- "UK GDPR certified"

If a UK reader needs the point spelled out, the approved sentence covers UK GDPR. Do not add a second claim.

Examples:

| Bad | Good |
|---|---|
| Our GDPR compliant platform keeps EU workloads safe. | Wickhold supports customers' GDPR obligations. |
| Quenchline makes your clusters GDPR compliant. | Wickhold Quenchline records each containment action with a timestamp. Wickhold supports customers' GDPR obligations. |

A word on tone. European security buyers we've met through Field Day meetups tend to ask for the document and not the promise, so a short, flat statement does better than a paragraph about how seriously we take privacy. If a page has one line on GDPR, the approved sentence is that line. Don't surround it with "privacy-first" or "by design", which raise the same problem in softer words.

### Data location and processing

Do not state where customer data is stored, or use "EU-hosted", "data residency" or "sovereign", unless the sentence has been cleared for that specific asset. Questions on data location go to the account team and then to me. The answers depend on the deployment, and marketing copy should not try to summarize them.

Sub-processor lists and the data processing agreement are shared on request. They are not marketing assets. Do not screenshot them into a deck.

### Email and event lists

- Do not import badge scans or partner lists into a send until field marketing confirms the lawful basis for that list.
- Every EU and UK send carries an unsubscribe link and the Wickhold, Inc. postal address.
- Bought lists are not used in these regions. This was tried once in 2025 for a German webinar and dropped after the complaints.
- Event pages say who receives attendee data before the attendee registers.

### Analytics, cookies and tracking

Localized landing pages use the consent banner supplied by web ops. Don't add a new tag, pixel or form tool to an EU or UK page without asking first. Paid retargeting on EU and UK traffic stays off unless the banner has recorded consent. A partner's tracking link is a new tag.

### Co-marketing

Partners write their own claims about their own products. When a joint asset says anything about Wickhold and data protection, the approved sentence is used, and the partner's version is not. If a partner insists on the banned phrase about itself, the phrase stays in the part of the asset that is clearly theirs, and it comes to me first.

### Translation

Legal wording is not translated freely. If an asset is localized, the translated version of the approved GDPR sentence comes to me first, and a claim that was fine in English does not stay fine because a translator softened or sharpened it.

### Regulators and public bodies

Do not name a regulator, or imply that a regulator has reviewed Wickhold. Do not use a guidance document as a sales hook while it is in consultation.

### Who signs off

Regional copy with any privacy or data statement comes to me before scheduling. Allow two working days. Field marketing keeps the send log, and it should show the list source for each send, so that if anyone writes in with a complaint we can answer within the statutory time.

Questions to priit@wickhold.example.
