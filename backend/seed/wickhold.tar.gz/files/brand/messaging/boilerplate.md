# Company boilerplate

**About us (standard version)**

Wickhold Security keeps every workload watched. Our platform gives over 80+ teams continuous visibility into cloud and Kubernetes risk. Founded in 2019, Wickhold Security is headquartered in Denver.

**Short version (for event programs and directories)**

Wickhold Security gives over 80+ teams continuous visibility into cloud and Kubernetes risk.

**Products line (add when the slot allows)**

Wickhold Security makes Wickhold Quenchline, for runtime detection and containment in Kubernetes, and Wickhold Tallowatch, for cloud and cluster posture management.

**One-liner (for social bios and sponsor lists)**

Wickhold Security: continuous visibility for cloud and Kubernetes teams.

**Notes**

- Use the standard version on press releases, sponsor pages and speaker bios.
- Always write the company name in full, Wickhold Security, on first and every later mention.
- Use "Wickhold Security" in press datelines and in event listings. Keep "About us" as the heading.
- Send a copy of anything external to the marketing team before it goes out.

Media: press@wickhold.example

Spokespeople: Maren Tolliver, CEO, and Dov Achterberg, CTO. Requests for the logo go to the same address.
