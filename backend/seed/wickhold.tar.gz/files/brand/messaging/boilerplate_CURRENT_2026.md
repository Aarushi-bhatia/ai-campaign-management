# Company boilerplate (current, 2026)

Use this paragraph verbatim:

> Wickhold is the runtime security company for teams that run Kubernetes. Its products contain failures early, so small fires stay small. Founded in 2019 and based in Denver, Wickhold serves more than 140 customers.

Usage notes from Noor Eskelund:

- Verbatim means verbatim. Don't edit, shorten, reorder or re-punctuate it. If the slot is too small, ask for more room or leave it out.
- Don't add product names or funding to the paragraph. Put those in a separate sentence.
- Use it for press releases, event programs, partner pages, speaker pages and report back pages.
- Use "About Wickhold" as the heading.
- It stays in the third person. "Its products" doesn't change to "our products", even on our own site.
- The customer count changes only when legal reissues this paragraph.
- Keep the period at the end and the words "small fires stay small" in lowercase. It isn't the tagline here, it's part of the sentence.
- Don't translate it without checking with Noor first.
- Contracts and footers use the legal name, Wickhold, Inc.

Copy it from this file. Questions to noor@wickhold.example.
