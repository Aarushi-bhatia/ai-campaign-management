# Wickhold Security Messaging Framework
## 2024 Refresh (post Series B)

Prepared by Product Marketing for the sales kickoff. Circulated July 2024. Please use this for all new decks, web pages and campaigns!

### Tagline

**Every workload. Always watched.**

### Positioning Statement

For cloud-native teams who can't afford a blind spot, Wickhold Security is the next-gen cloud and Kubernetes security platform that gives you continuous visibility across every cluster. Unlike point tools, Wickhold Security delivers a single pane of glass for runtime and posture, so nothing gets missed.

### Elevator Pitch (30 seconds)

"Attackers only need one mistake. Wickhold Security watches every workload, around the clock, from runtime to cloud configuration. With Wickhold Quenchline and Wickhold Tallowatch working together, your team gets robust, seamless coverage from a single platform. That's why more than 80+ teams rely on us today!"

### The Big Stat

Lead with this everywhere. It's our best number:

> **68% of runtime incidents began with a misconfigured workload**
> Wickhold Field Report 2023

Why it matters: it ties Quenchline and Tallowatch together. Tallowatch finds the misconfiguration and Quenchline catches what gets through. Every deck should have it by slide 3. Use it on the web homepage hero, in nurture email 1, and in the booth backdrop.

### Messaging Pillars

**1. See everything**
Continuous visibility into every workload, cluster and cloud account. If it runs, we watch it.
- Wickhold Tallowatch continuously scans cloud and cluster posture
- Wickhold Quenchline watches runtime behavior with a lightweight eBPF agent
- One holistic view of your risk

**2. Stop threats fast**
When something goes wrong, every second counts! Wickhold Quenchline detects attacks in real time and shuts them down before they spread.
- Best-in-class runtime detection for Kubernetes
- Containment actions at the push of a button
- Unlock instant response for your SOC

**3. Empower your teams**
Security and platform teams finally share one source of truth.
- Fewer tools, fewer tickets, fewer late nights
- Seamless integrations with the stack you already have
- Built by former on-call leads who've been there

### Product Messaging

**Wickhold Quenchline**
*Runtime detection and containment for Kubernetes.*
Quenchline is the always-on eye inside your clusters. A lightweight eBPF agent sees every process, every connection and every syscall, then surfaces what matters in real time. When your team spots something bad, they can contain it with one click. Key phrase: "always-on runtime visibility."

**Wickhold Tallowatch**
*Cloud and cluster posture management.*
Tallowatch watches your configuration so you don't have to. It continuously scans cloud accounts and clusters, flags risky settings, and scores your overall posture. Key phrase: "know your posture, every minute of every day."

**Better together**
Quenchline plus Tallowatch is the full story. Reps should always position both. Tallowatch shows you the misconfiguration, Quenchline shows you what happened next, and the Wickhold Security Platform ties it all together in a holistic risk view.

### Key Messages by Audience

**Security leaders**
- Are you sure you can see every workload right now?
- 68% of runtime incidents began with a misconfigured workload. Is yours next?
- Wickhold Security gives you the robust coverage your board expects.

**Platform / DevOps**
- Lightweight agent, installed in minutes
- Works with Helm and containerd out of the box
- No more alert fatigue!

**Executives / budget holders**
- Consolidate tools and reduce spend
- Trusted by 80+ teams
- Backed by Marlbank Partners

### Objection Handling

**"We already have a cloud security tool."**
Great! Ask if it gives them a single pane of glass across runtime and posture. It probably doesn't. Then remind them that 68% of runtime incidents began with a misconfigured workload, so siloed tools leave a gap.

**"Agents slow things down."**
Quenchline uses eBPF, so it's incredibly lightweight. Offer a proof of concept.

**"We're too small for this."**
Attackers don't care how big you are! Lots of our 80+ teams started with a single cluster.

**"Why not wait until next year?"**
Every day without visibility is a day you could be breached. Keep it friendly, but make the point.

### Booth Script (30-second version)

Rep: "Hi! Quick one: how many of your workloads can you see right now?"
Visitor: *(any answer)*
Rep: "Most teams aren't sure, and 68% of runtime incidents began with a misconfigured workload. Wickhold Security watches runtime and posture in one place. Want to see Tallowatch light up on a live cluster?"

Scan the badge, offer the Field Report, book the follow-up. Don't get pulled into a deep technical conversation at the booth. Grab a sales engineer for those.

### Value Props at a Glance

| Audience | What they get | Say this |
|---|---|---|
| CISO | Confidence | "Sleep better knowing every workload is watched." |
| Head of Platform | Fewer tools | "One robust platform instead of five dashboards." |
| SOC lead | Faster triage | "Best-in-class detections with full Kubernetes context." |
| CFO | Consolidation | "Unlock savings by retiring point tools." |

### Nurture Email 1 (approved copy)

Subject: Are You Watching Every Workload?

Hi {{first_name}},

68% of runtime incidents began with a misconfigured workload. That's why Wickhold Security gives teams like yours continuous visibility, from runtime to cloud configuration, in one seamless platform. Download the Wickhold Field Report and see where you stand!

### Campaign Themes for H2

- **"Always Watched" launch.** Homepage refresh, paid search and a new booth design for the big cloud-native conference in November.
- **Field Report promotion.** Keep driving downloads of the Wickhold Field Report. The 68% stat goes in the first line of every nurture email.
- **Field Day meetups.** Regional customer events, with a Tallowatch demo at every stop.
- **Series B moment.** Use the funding news as a credibility hook on LinkedIn and in outbound for the rest of the year.

### Sample Headlines

- Every Workload. Every Cluster. Always Watched.
- Is Your Kubernetes Environment Really Secure?
- Stop Attacks Before They Start!
- The Single Pane Of Glass For Cloud-Native Security
- See Everything With Wickhold Tallowatch

### Sample Email Subject Lines

- Do You Really Know What's Running In Your Cluster?
- Your Blind Spots Are Showing!
- New: See Your Whole Cloud With Tallowatch

### Sample Social Post

Your cluster never sleeps, and neither do we! 68% of runtime incidents began with a misconfigured workload. See how Wickhold Security keeps every workload watched. #CloudSecurity #Kubernetes

### Proof Points

- 80+ teams and growing fast
- Series B, $46M, led by Marlbank Partners (June 2024)
- Series A, $18M (March 2022)
- Wickhold Field Report 2023 (the 68% number above)

### Product Naming

Always "Wickhold Quenchline" and "Wickhold Tallowatch" on first use. "The Wickhold Security Platform" is fine when talking about both. Never abbreviate the company to "Wickhold" alone. It sounds unfinished, and the full name tells people what we do.

### Sample Blog Titles

- 5 Kubernetes Misconfigurations That Keep CISOs Up At Night
- Why Visibility Is The New Perimeter
- What The Wickhold Field Report Means For Your Team

### Do and Don't

Do:
- Use the tagline in every asset
- Say "platform," not "tools"
- Mention both products
- Use urgency. Security buyers respond to it!

Don't:
- Say "just a scanner" or "just an agent"
- Lead with price
- Leave out the Big Stat
- Use old screenshots from before the Tallowatch console refresh

### Call To Action

Default CTA across the website: **Learn more**. For bottom-of-funnel pages and emails: **Request a demo today!**

### Questions?

Ask anyone in Product Marketing. This framework will be reviewed after the fall events.
