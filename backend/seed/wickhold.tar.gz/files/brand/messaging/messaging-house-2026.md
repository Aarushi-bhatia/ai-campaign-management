# Wickhold messaging house

Ilse Varga-Holm, VP Marketing. Written for the rebrand, revised May 2026 for the Containment Report and Wickhold Leashgate early access, light edits after Slow Burn Summit in September.

This is the structure that sits under our copy. It says what we want a reader to believe, in what order, and what evidence supports it. The sentences marked as examples can be lifted. The rest is for writers, sales engineers and anyone briefing an agency. Fit any line to the channel; the argument stays the same.

## 1. The idea

A wick is where a fire is allowed to exist. The flame burns there, at a size someone chose, and it stops being an emergency. That's the company. Runtime failures in Kubernetes are going to happen. A pod gets compromised, a process does something it shouldn't, a policy drifts. What decides the outcome is how far the failure gets before someone or something contains it.

Mission: keep small failures from becoming big ones.

The old house was built around watching things. It made sense when customers mostly bought a dashboard, and it stopped making sense once the question from every serious buyer became "and then what happens?" The 2026 house answers that question.

## 2. Core message

**Wickhold contains runtime failures in Kubernetes early, tells you plainly what happened, and leaves your on-call team with a smaller problem.**

Short version for tight spaces: small fires stay small.

### What a reader should conclude

| After | They should think |
|---|---|
| One line | This company is about containment, and it works on Kubernetes |
| One page | Containment can be scoped, tested in observe mode, and audited after the fact |
| One conversation | These people told me what the product doesn't do, so I believe the rest |

### Who it's for

Teams that run Kubernetes in production and carry a pager for it. Typically a platform team and a security team who have to agree. Lead sectors are financial services and retail, because that's where our proof is. We'll take other sectors, and we don't write copy as if we're specialists in them.

### Market frame

Use these two statistics to set the scene. They come from the Wickhold Containment Report 2026, published April 14, 2026, a survey of 412 platform and security leaders.

- 41% of platform teams need more than six hours to contain a runtime incident.
- The median time to contain a runtime incident is 7.4 hours.

The argument that follows: time to contain is the gap between a small failure and a big one, and it's a gap that teams can measure and shrink. We describe the gap and stop there. We don't dramatize it.

## 3. Pillars

The early draft had three pillars, all about Quenchline. We added the fourth once the board asked what the company stands for beyond one product, and we rebuilt pillars two and three around jobs when product names turned out to make terrible pillar titles.

### Pillar 1: Contain first

Wickhold Quenchline runs an eBPF agent on the node, detects runtime behavior that breaks policy, and takes a containment action: isolate a pod's network, freeze a process, or drain a node. Teams choose how much of that happens automatically through the default containment policy and through contain mode vs observe mode, set per scope.

Message: when something goes wrong at runtime, the first job is to limit it. Investigation goes better when the failure has stopped spreading.

Proof:
- Contains a known-bad process in a median of 38 seconds in Wickhold lab benchmarks, 2026.
- Under 2% CPU overhead on a typical node in Wickhold lab benchmarks, 2026.
- Lowmoor Credit Union: time to contain fell from 4 hours to 11 minutes, across 220 nodes.

Example line: "Quenchline freezes the process and isolates the pod. Your on-call engineer starts with a contained problem."

### Pillar 2: Fix the right thing next

Wickhold Evenburn manages cloud and cluster posture. It shows drift from what you intended, maps the exposure path to what matters, and gives a fix order, so a long list of findings becomes a short list of decisions.

Message: most teams know they have more findings than hours. The useful question is which one to fix first.

Proof:
- Ostler Grocers: 63% fewer open critical misconfigurations in 90 days, across 1,900 nodes.

Example line: "Evenburn gives you a fix order. Start at the top and stop when your sprint runs out."

### Pillar 3: Hold agents to a policy

AI agents now call tools inside customer infrastructure, and they do it with real credentials. Wickhold Leashgate, in early access, applies runtime policy to those tool calls. It gives each agent an identity, sets a tool-call policy, and reduces the blast radius of an agent. The approved outcome language is that Leashgate limits what a compromised agent can do.

Message: treat an agent as a workload with credentials. Give it a boundary.

Proof: there's no customer proof yet, so we describe what the product does. Don't stretch for a number.

Example line: "Wickhold Leashgate, in early access, applies a tool-call policy to each agent, which limits what a compromised agent can do."

### Pillar 4: Say what happened

This pillar is about how we behave, and buyers read it as a product attribute anyway. A containment action comes with a record of what fired and what was done. Our reports publish methods. Our pages say what the product doesn't do. Two of our four values live here: say what happened, admit limits.

Message: you can check what we tell you. In a category full of claims, that's the difference.

Proof:
- SOC 2 Type II, renewed January 2026.
- The Containment Report's published survey method.
- Maren and Dov's history: both are former on-call infrastructure leads, and the company's habits come from on-call.

Example line: "Every containment action leaves a record your team can read at 9am."

## 4. Messages by persona

Each block has the situation, the lead, supporting messages, proof to use, and a sample. The persona files have the fuller profiles. This is what we want to say to each of them.

### CISO

**Situation.** Accountable to the board for risk they can't personally inspect. Has been told by every vendor that the worst is coming. Short on time and allergic to noise. Often the economic buyer, usually with the platform lead as a veto.

**Lead.** A decision: how long may a runtime incident run in your Kubernetes estate before it's contained, and who has authorized the action that contains it?

**Supporting messages**
- Time to contain is a board-level number you can report. The median is 7.4 hours, and you should know where you sit against it.
- Containment is controlled. Your team sets the default containment policy and can run in observe mode until the evidence supports contain mode.
- Each action leaves a record for audit and for the post-incident review.
- Agents are a new class of identity in your estate. Leashgate (early access) is how Wickhold approaches that risk. Ask about it, and treat it as early access in your planning.

**Proof.** Lowmoor Credit Union, with Hana Brandvold as the peer reference. The 2026 report. SOC 2 Type II.

**Sample**

> Decide how long a runtime incident may run before it is contained. Across the industry, the median time to contain a runtime incident is 7.4 hours [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]. Lowmoor Credit Union took its time to contain from 4 hours to 11 minutes across 220 nodes using Wickhold Quenchline.

**Likely questions**

| Question | Answer |
|---|---|
| What about FedRAMP? | Wickhold is pursuing FedRAMP Moderate authorization. |
| What happens to GDPR obligations? | Wickhold supports customers' GDPR obligations. |
| Will this take production down? | Scope contain mode to what you've tested. Draining a node is a policy choice you make, and observe mode shows you what would have happened first. |
| Can you stop prompt injection? | Leashgate limits what a compromised agent can do. It works on tool calls and doesn't judge prompts. |

### Platform lead

**Situation.** Owns the clusters and the on-call rotation. Has removed at least one security agent from production after it misbehaved. Wants to know what it does to the node, how it fails, and how to turn it off. Will read your docs before your website.

**Lead.** What the agent is, how to install it, what it costs the node, and what happens when it breaks.

**Supporting messages**
- It's an eBPF agent, installed with Helm. Start in observe mode and read what it would have done.
- Under 2% CPU overhead on a typical node in Wickhold lab benchmarks, 2026. Run your own numbers and tell us if yours differ.
- Move one namespace to contain mode when you trust the policy. Roll back the same way.
- Containment actions are named and few: network isolate, process freeze, node drain. There's no mystery action.
- Evenburn shows you drift and a fix order, which is shorter than the list your scanner gave you.

**Proof.** Ostler Grocers at 1,900 nodes, with Rafe Mulcahy. The lab figures, qualified. The release notes, which we keep honest.

**Sample**

> Install Wickhold Quenchline with Helm and leave it in observe mode. It records what the default containment policy would have done on your nodes. When you've read enough, set one namespace to contain mode. Under 2% CPU overhead on a typical node in Wickhold lab benchmarks, 2026.

A line that went over well at Slow Burn Summit:

> Your pager will still go off. It will have less to say.

**Likely questions**

| Question | Answer |
|---|---|
| Kernel versions? | Point to the docs. Don't answer from memory. |
| What if the agent crashes? | Quote the failure behavior from the Quenchline docs word for word. |
| Can I run it in observe mode forever? | Yes. You'll get detection and records, and no containment. |
| Does it replace my image scanner? | No. Quenchline works at runtime. |

### DevSecOps

**Situation.** Sits between developers and security. Owns pipelines, policy as code and the queue of findings. Measured on how many findings get closed without slowing delivery. Often the person who brings us in, and rarely the budget holder.

**Lead.** Findings ranked by exposure path and a policy you can review like code.

**Supporting messages**
- Evenburn's fix order means developers get a short, justified list instead of a spreadsheet.
- Drift shows up as a difference from what you declared, so it can go back into the normal review.
- Quenchline's policies live with the rest of your configuration and get reviewed the same way.
- If teams are wiring agents into pipelines or internal tools, Leashgate (early access) gives each one an agent identity and a tool-call policy you can read.

**Proof.** Ostler Grocers: 63% fewer open critical misconfigurations in 90 days, across 1,900 nodes. It's the number this reader cares most about, because closing criticals is the job.

**Sample**

> Wickhold Evenburn turns your posture findings into a fix order, ranked by exposure path. Ostler Grocers saw 63% fewer open critical misconfigurations in 90 days, across 1,900 nodes.

**Likely questions**

| Question | Answer |
|---|---|
| Does Evenburn fix things for me? | No. It tells you what to fix and in what order. |
| Will it fight our existing policy tool? | Ask about their setup first, then bring in a sales engineer. |
| Is Leashgate ready for production agents? | It's in early access. Talk to us about what that covers. |

## 5. Product one-liners

| Product | One line | Concepts to reach for |
|---|---|---|
| Wickhold Quenchline | Runtime detection and containment for Kubernetes | Containment action, default containment policy, contain mode, observe mode |
| Wickhold Evenburn | Cloud and cluster posture management, with a fix order | Drift, exposure path, fix order |
| Wickhold Leashgate (early access) | Runtime policy for AI agents and their tool calls | Tool-call policy, agent identity, blast radius of an agent |

Together: Quenchline handles what's happening now, Evenburn handles what could happen next, and Leashgate (early access) handles what your agents are allowed to do.

## 6. Common objections

**"We already have detection."** Good. Ask what happens in the minutes after an alert. Quenchline's job is the containment action, and that's the conversation to have. If they're happy with their time to contain, they may not need us yet, and it's fine to say so.

**"An automated action in production scares me."** It should. That's why observe mode exists, and why contain mode is set by scope. Lowmoor started that way too, and sales can walk through how.

**"Our cloud provider has this built in."** The native tooling covers posture in that cloud. Ask how they contain a process on a node across clusters. We don't claim the built-in tools are bad.

**"You're a young company."** Founded in 2019, Quenchline GA since September 2020, more than 140 customers. Say that and move on.

**"Agent security is hype."** Possibly in places. Leashgate is in early access because we're still learning from the teams running agents. The problem it addresses is a workload with credentials acting on instructions, which isn't hype.

## 7. How the house plays through a buying cycle

A deal usually starts with one person and ends with three. The order below is what sales and marketing have agreed to run. It isn't a script.

**First touch.** Usually a report, a talk, or a colleague. The job at this stage is to make time to contain feel like the right thing to measure. Use the market frame and the idea. Keep products to one line. Most report traffic comes from security leaders, and most of the people who forward it are platform engineers.

**Evaluation.** The platform lead gets involved, and the tone moves to install steps. Observe mode is the main message here because it lets a cautious team say yes to something small. A trial that ends with a list of what Quenchline would have done is a better sales asset than anything marketing can write. Sales engineers should ask for one specific namespace, not a whole cluster.

**Security review.** The CISO or a delegate checks SOC 2, the record of containment actions, and how contain mode is authorized. Pillar 4 does the work here. Send the documents they asked for and don't add a pitch.

**Expansion.** Evenburn usually comes second, after the first containment review raises the question of why the failure was possible at all. That's the natural bridge from pillar 1 to pillar 2: contained today, and a fix order for tomorrow. Leashgate comes up when a customer mentions agents. Don't raise it in a first meeting unless they do, because an early access product can pull a good Quenchline deal off course.

## 8. Adapting by sector

Financial services copy can talk about regulators and examiners in general terms, and it should stay close to the CISO block. Lowmoor is the reference. Mid-size banks and credit unions run small security teams, so "your on-call engineer starts with a contained problem" tends to land harder than anything about scale.

Retail and grocery copy leans on fleet size and seasonal peaks. Ostler is the reference. These teams worry about change freezes, so observe mode and the fix order both matter more than containment speed.

Health and public sector aren't lead sectors for this house. If you're writing for either, come and talk to us first. Sector claims need proof we're allowed to use, and for those two we don't have it.

## 9. Category language

We call Wickhold a runtime security company. Teams who search for us use other words: Kubernetes runtime security, container security, cloud posture management, and increasingly AI agent security. Those are fine as descriptive terms and for search. Our preferred category line is "runtime security for teams that run Kubernetes".

The three shapes of alternative a buyer will have seen are the broad platform with a heavy agent, the posture-only tool, and the detection-only tool with a large rule library. We talk about those shapes when it helps the reader understand us. What we offer against each:

- Against a broad platform: a footprint you can measure, and a clear account of what it does to the node.
- Against posture-only: something that acts at runtime, once the fix order hasn't reached the problem yet.
- Against detection-only: the step after the alert.

## 10. Examples of the house in copy

| Weak | Why | Better |
|---|---|---|
| Hackers are already inside your cluster. | Sells fear | Runtime failures happen. Time to contain is the number you can change. |
| The complete platform for cloud-native security | Claims everything, says nothing | Wickhold contains runtime failures in Kubernetes |
| Quenchline protects your workloads against every threat | Absolute promise | Quenchline contains a known-bad process in a median of 38 seconds in Wickhold lab benchmarks, 2026 |
| Reduce risk and accelerate innovation | Outcomes fog, especially for engineers | Install in observe mode. Read the report on Friday. |
| We believe agents are the future of work | Opinion in brand voice, and no product | Wickhold Leashgate, in early access, applies a tool-call policy to each agent |

## 11. Lines we tried and dropped

- "Fireproof your cluster." A promise we can't keep, and it fights the idea. Fire is expected here.
- "Sleep through the night." It tested well with marketers and badly with on-call engineers, who pointed out that the pager still rings.
- "Containment is the new detection." Clever and meaningless.
- "The 3am product." Good internally as a description of the voice. In market it read as a threat.
- "Wick it." Please no.

## 12. What we heard at Slow Burn Summit

We ran the house past a dozen customers in the hallway track in September, with Kofi Anselm taking notes. Nothing in the pillars changed, and three things changed in how we use them.

Platform leads kept asking for the failure behavior before anything else, so that question now sits in the platform block, and sales engineers open with it. CISOs at the session wanted the 7.4-hour figure as something they could put next to their own number, so the CISO copy now asks them to compare. Previously it only stated the median. Several customers asked about agents, and most of them weren't running any in production yet. We kept pillar 3 in the house, and it stays third.

One thing we didn't change: a few people suggested making "containment" softer for buyers who worry about automated action. That worry is real and observe mode answers it, so the word stays. Sales engineers reported the same pattern in Q3 calls, and the customers who raised it were usually the ones furthest along in their rollout.

## 13. Briefing an agency or freelancer

Give them this page, the proof sheet and the voice guide. Tell them which persona, which pillar and which single proof point the piece uses. A piece that tries to carry all four pillars ends up saying none of them. Ask for two versions of the lead, and read them aloud before picking one. Everything goes through the claims review before it leaves the building.

## 14. Keeping this current

Noor Eskelund keeps this file in step with the guidelines and I sign off on changes. Numbers come from the proof sheet and from Priit's claims review, and if one of those disagrees with this page, trust them and tell us. Leashgate's section gets rewritten when product and legal say its status has changed. Until then, copy here stays in early access terms.
