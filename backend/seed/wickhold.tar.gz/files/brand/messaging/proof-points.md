Proof points, kept by brand. Noor Eskelund updates this after each claims review. Last pass: 6 October 2026.

Sheet for writers. Each row has the date of the evidence, the sentence to use, and where it fits. If a number isn't on this sheet, don't use it in a draft. Ask Noor first and she'll route it to legal if it's new. The exception is a third-party statistic under section 5 of the approved claims.

## Market

| Date | Proof point | Source | Good for |
|---|---|---|---|
| 2026-04-14 | 41% of platform teams need more than six hours to contain a runtime incident | Wickhold Containment Report 2026, survey of 412 platform and security leaders | Blog intros, CISO decks, report promotion |
| 2026-04-14 | The median time to contain a runtime incident is 7.4 hours | Same report | Blog intros, talks, board-level summaries |

Cite like this: "41% of platform teams need more than six hours to contain a runtime incident [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]."

Earlier Field Report numbers are gone from this sheet on purpose. Please stop pasting them in from old decks.

## Product, lab

| Date | Proof point | Good for |
|---|---|---|
| 2026 | Under 2% CPU overhead on a typical node in Wickhold lab benchmarks, 2026 | Platform engineers, install docs, comparison calls |
| 2026 | Wickhold Quenchline contains a known-bad process in a median of 38 seconds in Wickhold lab benchmarks, 2026 | Landing pages, demos |

Writers trim the second half of these sentences more than anything else on this sheet. Copy the whole row.

## Customers

| Reviewed | Customer | Proof point | Scale | Good for |
|---|---|---|---|---|
| 2026-07-14 | Lowmoor Credit Union | Time to contain fell from 4 hours to 11 minutes | 220 nodes | CISO copy, financial services, Quenchline pages |
| 2026-07-14 | Ostler Grocers | 63% fewer open critical misconfigurations in 90 days | 1,900 nodes | Platform leads, Evenburn pages, retail |

Named people on the record: Hana Brandvold, CISO, Lowmoor Credit Union. Rafe Mulcahy, VP Infrastructure, Ostler Grocers. Take their quotes from the case studies. Don't retype from memory.

Lowmoor is the small-estate story and Ostler is the large-estate story. If you're writing for a 2,000-node retailer, Ostler is the fit, even when Lowmoor's number looks better on the page. Sales engineers have told us prospects notice.

## Company

| Date | Proof point | Notes |
|---|---|---|
| 2026-10 | More than 140 customers | Copy as is |
| 2026-01 | SOC 2 Type II, renewed January 2026 | Reports go through the account team |
| 2024-06 | Series B, $46M, led by Marlbank Partners | Press and recruiting pages. Not a product proof point |
| 2022-03 | Series A, $18M | Press background only |
| 2020-09 | Wickhold Quenchline GA since September 2020 | Useful with engineers who ask how long it has run in production |
| 2019-03 | Founded in Denver by Maren Tolliver and Dov Achterberg, both former on-call infrastructure leads | About pages, founder bios |

## Which proof for which job

- Headline on a Quenchline page: the 38-second lab figure, with its qualifier, or the Lowmoor result. Pick one.
- Platform lead email: overhead figure as the first proof, after the command. They'll ask about it anyway.
- Board-level or CISO summary: the 7.4-hour median, then Lowmoor's 11 minutes as the contrast. Keep the two sentences separate and name both sources.
- Evenburn page: Ostler. There's no lab figure for Evenburn, so don't try to build one out of the Ostler result.
- Wickhold Leashgate (early access): no customer proof yet and no lab figure. Describe what tool-call policy does and leave it there. A thin page beats a borrowed number.

Tried and dropped: a "customers in numbers" strip that added nodes across both named accounts. It looked good and said nothing, since 220 and 1,900 are different estates doing different things.

## By persona, quickly

| Reader | Best proof | Back it with |
|---|---|---|
| CISO | The 7.4-hour median, as the risk | Lowmoor, SOC 2 |
| Platform lead | Overhead figure | 38-second figure, Ostler if posture comes up |
| DevSecOps | Ostler | Overhead figure |

## How a row gets on this sheet

Someone brings a number with its source to Noor. Noor checks whether it's already approved. If it's new, it goes to Priit with the evidence. Customer numbers also need the customer's sign-off through the account owner, which usually takes a few weeks. Once approved, the row goes on with a date. Rows don't get edited in place. When a number changes, the old row comes off and a new one goes on, so nobody ends up quoting a mix of the two.

We don't keep "nice to have" rows. Summit attendance, follower counts and press mentions came off in the spring because no prospect has ever cared, and they were getting pulled into decks as filler.

A few things that aren't on the sheet because we don't have them, and people ask every quarter: a detection-rate figure, a false-positive figure, a dollar savings figure, and any analyst ranking. If one of these turns up in a draft, it came from somewhere else and needs to come out.

Date formats above are for us. In copy, write the source and year the way the style guide says.

## Limitations line for landing pages and long blogs

Every landing page and every long blog names one thing the product does not do. One specific limitation, in plain words, on the page itself. This comes from the "admit limits" value, and it has also done real work: on the spring Quenchline landing page test the limitations line was the most-quoted sentence in sales calls.

How to write it:

- State what the product does not do, as a flat sentence. Don't bury it in a footnote or an FAQ accordion.
- It has to be a real limitation of the product. "Quenchline does not do your laundry" is a joke. It's fine in a talk and it doesn't count here.
- Put it close to the claim it qualifies. On a landing page, that usually means right below the product section. On a long blog, the end of the section where the product appears.
- No apology and no pivot. Don't follow it with "but". The next sentence can say what handles that job, if something does.

Lines you can use or adapt:

| Product | What it does not do |
|---|---|
| Wickhold Quenchline | Quenchline does not patch the image or fix the misconfiguration that let the problem in. It contains the problem so your team can do that work in daylight. |
| Wickhold Quenchline | Quenchline does not cover workloads outside Kubernetes. |
| Wickhold Evenburn | Evenburn does not contain a running process. It tells you where the exposure path is and what to fix first. |
| Wickhold Leashgate (early access) | Leashgate does not judge what a prompt says. It applies tool-call policy to what an agent tries to do. |

Weak, and sent back in review:

- "No product can do everything." Not a limitation. It says nothing about the product.
- "Quenchline isn't a replacement for good security hygiene." Too vague to be useful.

A landing page for two products names one limitation for the product the page mainly sells. Report promotion pages and press pages don't need one, and neither does a short blog. If you're unsure whether a blog is long, include the line.
