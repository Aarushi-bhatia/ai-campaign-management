# Persona: the CISO

Owner: Ilse Varga-Holm. Rewritten in May 2026 after the Containment Report launch, and checked against the notes from the executive roundtable at Slow Burn Summit in September.

## Who this is

The CISO at a company with 200 to 5,000 nodes in production Kubernetes. She reports to the CEO or the CIO, presents to the audit committee or the full board once a quarter, and inherited most of the cluster estate from a platform team that built it before anyone asked her opinion. She has a team of analysts who are strong on identity and endpoint and thin on containers. The person who actually understands the clusters reports to somebody else.

She rarely buys on a first conversation and she rarely evaluates the product herself. She sponsors, she signs, and she kills deals that will embarrass her. Her platform lead does the proof of concept. Her job in the deal is to decide whether the risk reduction is worth a change to production, and to be able to defend that decision in one sentence to people who do not know what a pod is.

Typical titles: CISO, VP Security, Head of Information Security. At smaller customers the title may be Director of Security with the same duties and a smaller budget.

## What she is trying to get done

- Give the board a credible answer to "how long would it take us to contain something in production?" Most can't give one today, and they know it.
- Close the gap between detection and action. Her SOC can see an alert from a cluster, but it can't do anything about it without paging an engineer in another org.
- Get through audits without pulling platform engineers off roadmap work for weeks.
- Decide what to do about AI agents. Engineering wants to run them with real credentials. She needs a position before the next board meeting.

## What keeps the deal from moving

She has been burned by agents that took down a production node, so "runs in the kernel" is a concern before it is a selling point. She will ask who controls containment actions, who gets paged when one fires, and how to turn it off. She also has too many tools. Adding one means explaining why, and she would prefer to retire something.

Her platform lead has a veto in practice. A CISO who forces an agent onto a cluster over the platform team's objection tends to regret it, and she knows that. Treat the two conversations as linked: anything we tell her about contain mode has to match what the platform lead hears.

## How to write for her

Lead with the decision she needs to make, then the risk, then the time. In that order, in every format. If an email, briefing or deck opening can't state the decision in its first two sentences, it isn't ready.

"The decision" means something she could actually put on a calendar: whether to move a set of clusters from observe mode to contain mode, whether to set a target time to contain, whether AI agents get production credentials before there is a policy on them. Product features come after that, if at all. She doesn't need to hear about eBPF unless she asks. When she does ask, answer in one sentence and offer the platform lead's version.

Risk means what the business loses and how likely that is, in language her audit committee uses. Time means two things: how long containment takes today, and how long the change takes to roll out. Give both.

The figure that works best with this audience is from the Containment Report, because it gives her a benchmark for the board: the median time to contain a runtime incident is 7.4 hours [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]. Follow it with a question for her own team, never with a scare.

Customer proof: the most useful story for this reader is Lowmoor Credit Union, because the speaker holds the same job in a regulated business. Hana Brandvold, CISO, Lowmoor Credit Union, runs the team that cut time to contain from 4 hours to 11 minutes across 220 nodes. Say that and let it stand.

Compliance comes up early. SOC 2 Type II is held and was renewed in January 2026. If she asks about federal work, the sentence is "Wickhold is pursuing FedRAMP Moderate authorization." Nothing warmer than that.

### Examples

Good email opening:

> Your team has one decision to make this quarter: whether to move your payment clusters from observe mode to contain mode. That decision sets how long a runtime incident stays open. The rollout starts with two to four weeks in observe mode, and your platform lead keeps control of the containment policy.

Why it works: the decision is first, the risk is in the second sentence, and the time is in the third. She can forward it as written.

Good briefing headline:

> Set a target time to contain before the next audit committee

Bad, do not send:

> Attackers are moving faster than ever. Is your cluster next? Our powerful, award-winning platform gives you total peace of mind.

Three problems before we even reach the product. It opens with a threat, it opens with a question, and it offers feelings where she wanted a decision. There is also no figure anywhere in it.

Bad, do not send:

> Quenchline's eBPF sensor hooks syscalls at the kernel level with very little overhead, and its YAML policies support label selectors.

True, and useful to someone else. Send it to her platform lead.

## Humor and tone with CISOs

No humor in anything aimed at CISOs. That covers email, briefings, executive slides, the CISO track at Slow Burn Summit, and the sales follow-up afterwards. It also covers the light touch: no wry subject line, no joke to open a talk, no on-call anecdote played for a laugh. When a piece has a mixed audience and a CISO audience is anywhere on the distribution list, humor is not allowed for that piece.

This surprises people, because a CISO in a room can be very funny and the dry line that works with a platform audience often gets a smile from a CISO too. The reasons we hold the line are practical. The CISO forwards what we send to a CFO or an audit chair, who reads it cold. And a CISO audience is often reading after something has gone wrong for them or a peer, so a joke that lands on Tuesday can read badly the following week.

The tone we want with CISOs is plain, level and brief. Respect her time, say what is known, say what isn't. Warmth is fine: thanking her for the time, or acknowledging that a rollout is a real ask of her team. Keep it to a sentence.

Dov asked in June whether technical talks with a CISO in attendance count. They don't, if the talk is aimed at engineers and promoted to engineers. If the invitation went to CISOs, it counts.

## Where she spends time

Peer groups and private CISO dinners count for more than anything we publish. She reads the board pack, one or two newsletters, and whatever her team forwards. She does not read our blog on her own, though she will read a post that a trusted peer or her platform lead sends. LinkedIn works for founder posts from Maren, and very little else with this reader. Field Day is usually too engineering-heavy for her, so at those events invite her deputy.

## Questions she asks, and who answers

| Question | Who answers |
|---|---|
| What happens if containment fires on the wrong thing? | Solutions engineer, with the platform lead in the room |
| Who owns the default containment policy, you or us? | Solutions engineer. The customer owns it, and it ships in observe mode |
| Are you SOC 2? | Anyone. Send the report under NDA |
| What are you doing about AI agents? | Product, and label Wickhold Leashgate as early access every time |
| Can I see a customer in my industry? | Marketing, and only from the current approved list |

Last edited October 2026 to add the agent question above, which came up at nearly every Summit dinner.
