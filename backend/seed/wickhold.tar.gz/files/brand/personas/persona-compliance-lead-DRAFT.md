# Persona: compliance lead (DRAFT, do not circulate)

Started by Noor, June 2026. Needs at least [X] customer interviews before this is usable. TODO: get names from sales.

## Who this is

Title varies: Compliance Manager, GRC Lead, Head of Risk and Compliance. [TK: reports to CISO or General Counsel? seems to differ by account. Ask Priit.] Shows up late in the deal and can slow it down. Mostly at regulated accounts.

TODO: team size, typical background (audit firm? internal audit?). Does anyone in sales actually talk to them directly?

## What they want

- Evidence they can hand to an auditor without asking an engineer for it
- [TK: something about control mapping. Which frameworks actually come up? SOC 2 and PCI DSS for sure, HIPAA at some accounts. Confirm before listing]
- TODO: anything on retention? Ask product how long Evenburn keeps history

## Where they show up

Security questionnaires, vendor risk reviews, the last two weeks before signature. Ilse thinks they also sit in on renewals. [TK: confirm]

## How to write for them

Early thought, not agreed: fewer metaphors than the rest of our copy. Would "small fires" even land here? Needs checking with [NAME] at a customer.

Humor: TODO. Probably follow the CISO page, but I haven't talked to enough of them.

Certifications: use whatever the current wording is in legal's documents. TODO: paste it in once Priit confirms.

## Example copy

[TK]

## Objections we hear

1. "Who approved this containment action?" They want the audit trail for

