---
persona: DevSecOps engineer
owner: Kofi Anselm
reviewed: 2026-08
status: current
---

## Snapshot

| | |
|---|---|
| Usual titles | DevSecOps Engineer, Security Engineer (Cloud), Product Security Engineer, AppSec Engineer with a cluster problem |
| Reports to | Head of security engineering, sometimes a platform manager on a dotted line |
| Team size | 1 to 6, spread across several product teams |
| Role in a deal | Runs the security side of the evaluation, writes the policy, owns the rollout plan and most of the day-to-day after signature |
| Top product interest | Wickhold Evenburn first in most accounts, Wickhold Quenchline when they own runtime too |

This person sits between the people who ship and the people who sign off. Developers see them as the owner of a noisy gate in CI. The CISO sees them as the one who'll tell her whether a product is real. The platform lead sees them as someone who files tickets against infrastructure they don't run. They know all of this, and most of their week goes to reducing that friction.

They differ from the platform lead in one way that matters for us: their unit of work is the finding, while the platform lead's is the node. When we write to them, the interesting question is how a finding gets from detected to fixed to verified without a meeting.

## A week in the job

Monday is triage: scanner output from the weekend, a list of new CVEs and which ones touch something deployed. Midweek is exceptions. A team needs a privileged container for a release, and someone has to decide whether that's acceptable and for how long. Thursday is writing policy that someone will complain about. Friday, if it's a good week, is working on the pipeline.

They live in pull requests, CI logs, and the ticket queue. Dashboards get opened when someone asks a question.

## Pain, in their words

From interviews Kofi's team ran during spring 2026, lightly cleaned up:

- "I have four thousand findings and two hours."
- "The scanner tells me the image is bad. It doesn't tell me the thing is even reachable."
- "We wrote the exception in March. Nobody knows if it still applies."
- "When something fires at runtime I find out from the platform team, and then I have to go work out which repo it came from."
- "Every audit, I'm the one taking screenshots."

The first two are why fix order and exposure path are the best-performing Evenburn concepts with this reader. They already have more findings than they can use, and what they want is a defensible reason to work on one before another.

## What they care about in the product

**Evenburn.** Drift between what was merged and what's running. Exposure path, meaning whether a misconfiguration can actually be reached from somewhere that matters. Fix order, meaning which of these to do first and why. Show how a finding becomes a proposed patch or a ticket with an owner on it, and how it clears once the fix lands.

**Quenchline.** Writing and testing policy. They want policy in version control, reviewed like code, with observe mode decision records to read before it goes anywhere near contain mode. They want a runtime event to carry enough context to trace it back to a workload, a deployment, and ideally a commit.

**Wickhold Leashgate (early access).** A growing interest. Product teams are shipping AI agents with broad tool access, and this person has been told to have an opinion. The tool-call policy idea makes sense to them straight away, since it resembles the admission policy they already write. Be plain that this is early access, and be plain about scope: Leashgate limits what a compromised agent can do. Promise nothing beyond that.

## Writing for this reader

They respect precision and they spot marketing quickly, but they have more patience for explanation than the platform lead does, because they often have to re-explain our product to developers and auditors. Worked examples do well, especially a single finding followed from start to finish. They'll forward a clear explanation of an exposure path to a developer if it saves them writing one.

Show the policy file, then the finding, then the fix. Use the real names of concepts in Kubernetes and CI. Keep CVE references current, and check any CVE we mention with Dov's team before it runs. They care about CIS Benchmarks mappings, so state them accurately and say which checks aren't covered.

Humor: fine in community posts and talks, in small doses, and aimed at our shared tooling. Keep it out of anything they might paste into an audit package or a report to their CISO.

### Examples

Good:

> Wickhold Evenburn found 212 open misconfigurations in this cluster. Fix order puts three first, because each one sits on an exposure path from an internet-facing ingress to a workload with write access to your customer database. The other 209 are real and can wait for the normal sprint.

Why it works: a concrete count, a reason for the ordering, and permission to ignore most of the list. The figure here is an illustration, so in published copy replace it with a real example from a demo cluster and say that's what it is.

Good:

> Drift, in one line: the deployment in Git says `allowPrivilegeEscalation: false`, and the pod running in production says `true`. Wickhold Evenburn opens the finding with the declared value, the live value and who changed it, where the audit log can show that.

Bad:

> Shift left and secure your entire software supply chain with a holistic, developer-first platform.

A category we don't claim, a banned word, and nothing a developer could use.

Bad:

> Evenburn eliminates misconfigurations before they reach production.

It doesn't, and this reader knows it can't. Evenburn finds and orders them, and the fix is still a person's work.

## Where they are

Security engineering newsletters, smaller open-source communities around policy engines and scanners, the security track at the big cloud-native conference in November, and internal Slack channels we'll never see. Field Day draws a fair number of them, and they tend to stay for the hands-on block. Their manager's approval matters less than you'd think for a free tool or a trial and a lot more for anything that needs an agent on a node, at which point the platform lead gets involved.

## What moves them, what doesn't

Moves them:
- A way to reduce their list without arguing about severity scores.
- Findings with an owner attached.
- An audit export they don't have to build by hand.
- Evidence that runtime events and posture findings land in one place, tied to one workload.

Doesn't:
- Severity counts as a headline. Everyone's numbers look bad, and big numbers read as noise.
- Another dashboard. They already have the ones they've stopped opening.
- Case studies in general, unless one explains what the team changed in its process. A number alone gets a shrug.

## Open questions

Whether this persona splits in two as AI agent work grows: someone who owns pipeline security and someone who owns agent policy. Three of the accounts in the Leashgate early access group have named a separate owner already. Too early to call. Revisit at the end of the year.
