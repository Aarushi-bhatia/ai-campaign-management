persona-platform-lead
kofi, updated after slow burn 2026. ping me before you rewrite this one. Noor has a copy for the guidelines review.

# The platform lead

Staff or principal engineer, or the manager of a platform team of 4 to 15 people. Title might be Platform Lead, Head of Infrastructure, SRE Manager, or Principal Engineer. They run the Kubernetes clusters everyone else deploys to, and they carry the pager or manage the people who do. Both of our founders held this job, which helps, and it's also why we get lazy here. Don't assume you know this reader because you've met Dov.

They got burned by something. Usually it was a security agent that OOM-killed a node, or a DaemonSet from a vendor that rolled out with no resource limits on a Friday. So they start the conversation with a no. They're the ones who'll run `kubectl top` on our pods during the POC.

## What they want

- Nothing on a node that they can't explain, limit and remove with one Helm command.
- Fewer pages at 3am, and when the page comes, a clear statement of what fired and why.
- Their security team off their back. They don't mind security. They mind tickets with no reproduction steps.
- Control over anything that can drain one of their nodes. This is the sticking point on contain mode.

## How to talk to them

Lead with commands, flags and failure modes. The first thing they read should be something they could paste into a terminal, or a description of how the thing breaks. Concepts come after, if anyone's still reading.

Dry humor is allowed, and they'd rather have it. A straight-faced line about a Friday deploy does more for us than an adjective. It has to come from having been on-call. Puns about fires got old in about March.

No outcomes language. Nothing about "transforming" operations, "peace of mind", "improved security posture" or "business value". If a sentence would also work in a deck for their CFO, cut it. Tell them what the agent does to the node and what it costs in CPU and memory.

The order that works in docs, posts and talks:

1. The command or config.
2. What happens when it runs.
3. How it fails, and what you'll see when it does.
4. How to back it out.

## The four things they check first

**Install and removal.** They'll read the Helm chart before they read our site. Show the values file. Say what privileges the agent needs and why. Show the uninstall in the same post as the install, because they'll look for it.

**Overhead.** Quote the number with its source every time: under 2% CPU overhead on a typical node in Wickhold lab benchmarks, 2026. Then tell them to measure it on their own nodes, since a lab isn't their cluster. They'll respect that more than a bigger claim, and they're going to measure anyway.

**Blast radius of a bad policy.** What happens if a containment action fires on the wrong pod. This is the question that decides whether they ever leave observe mode. Walk through it: which containment actions exist (isolate a pod's network, freeze a process, drain a node), what the default containment policy will and won't do (it isolates or freezes, and it never drains a node), and how to set contain mode per policy so one namespace goes first.

**Agent failure.** What happens to workloads if the agent gets OOM-killed, or if the node's kernel has no BTF. Give the real answer with the real error string. If an edge case isn't handled yet, say that too.

## Examples

Good opening for a blog post or docs page:

```bash
helm repo add wickhold https://charts.wickhold.example
helm install quenchline wickhold/quenchline \
  --namespace wickhold-system --create-namespace \
  --set agent.mode=observe
```

> That runs Wickhold Quenchline in observe mode. Nothing gets contained, and you get a pile of decision records saying what it would have done, to read before you trust it with anything. Node drain needs `rbac.nodeDrain=true`, which you haven't set. On a kernel without BTF the agent exits with `btf_not_found` and the pod goes into CrashLoopBackOff. There's no degraded mode. Your workloads keep running, and you have no detection on that node until you fix it.

Good, with a little dry humor:

> Contain mode will freeze a process that matches your policy. It doesn't know that process is your CTO's favorite cron job. Scope the policy to a namespace first.

Good, on where we stop:

> Wickhold Quenchline won't patch your image and it won't tell you which base image to use. It watches what runs. Fix the image with whatever you use today.

Bad:

> Empower your platform team with a next-gen runtime security solution that delivers peace of mind and measurable business outcomes.

Banned words aside, there's no command in it, no failure mode, and nothing they could test.

Bad, and this one is sneakier:

> With Quenchline, platform teams spend less time on incidents and more time on what matters.

Might even be true. They'll close the tab anyway. Outcomes language, and it says nothing about what the software does.

## Where they are

The Kubernetes Slack and its local meetup equivalents, the big cloud-native conference in November (the hallway, not the booth), Field Day if a colleague drags them along, and our docs, which they usually reach through search with an error message in the box. Reading our marketing site is rare and usually a sign that someone asked them to evaluate us.

Kofi's team handles the community side. If you want this person's attention, a useful Helm values example will do more than a campaign. A gated PDF will lose them for good, so anything aimed here is ungated by default.

## Things we tried and dropped

- A "Platform Engineer Survival Kit" download in 2025. Forty-odd signups, most of them students. Dropped.
- Comparison tables on overhead with other agents. Too hard to keep honest across kernel versions, and readers assumed we'd picked the numbers.
- Webinars. They'd rather read. We kept the recordings up but stopped scheduling them for this audience.
- Sending them the Containment Report on launch day. It went better when we pulled the method section and the questions we asked into a short post, because they wanted to know who we surveyed before they'd believe the rest.

## What a good conversation looks like

They ask what the agent does when the API server is unreachable, you tell them, they say "huh, ok," and they try it on a staging cluster. That's a win. Don't ask for a meeting with their CISO in the same breath. They'll get there if the POC goes well, and they'll tell you who to talk to.
