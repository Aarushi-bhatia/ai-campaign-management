FOR IMMEDIATE RELEASE

# Wickhold Security Raises $46M Series B to Keep Every Workload Watched

*Funding led by Marlbank Partners will accelerate the next-gen Wickhold Security platform for Kubernetes and cloud*

DENVER, June 2024 — Wickhold Security, the cloud and Kubernetes security company, today announced it has raised $46 million in Series B funding led by Marlbank Partners. The round follows an $18 million Series A in March 2022 and will fund product development, field engineering and go-to-market expansion.

Cloud-native environments are growing faster than security teams can keep up. According to the Wickhold Field Report 2023, 68% of runtime incidents began with a misconfigured workload. Wickhold Security brings runtime and posture together, giving teams robust, continuous coverage from a single platform.

"When Dov and I started this company, we'd both spent years on call, and we knew how exhausting it was to wonder what you were missing," said Maren Tolliver, CEO and co-founder of Wickhold Security. "This investment lets us go even further toward a world where every workload is watched, every minute of every day. We couldn't be more excited!"

The Wickhold Security platform includes:

- **Wickhold Quenchline**, runtime detection and containment for Kubernetes, powered by a lightweight eBPF agent and available since 2020
- **Wickhold Tallowatch**, continuous cloud and cluster posture management

"Our field team sees it every week: customers want one place to understand their risk, and they want a partner who shows up," said Tomas Beaulieu-Kerr, VP Field Engineering at Wickhold Security. "With this funding we'll be adding engineers in the field so that every customer gets seamless onboarding and hands-on support."

Marlbank Partners will join the Wickhold Security board as part of the investment. The company said the funding will also support its annual Wickhold Field Report and an expanded schedule of Field Day customer meetups.

With over 80+ teams now relying on the platform, Wickhold Security plans to grow its Denver headquarters and hire across engineering, field and marketing this year. Open roles are posted on the company website, and more news is coming soon!

**Every workload. Always watched.**

### About Wickhold Security

Wickhold Security keeps every workload watched. Our platform gives over 80+ teams continuous visibility into cloud and Kubernetes risk. Founded in 2019, Wickhold Security is headquartered in Denver.

Media contact: press@wickhold.example
