# Wickhold opens early access to Wickhold Leashgate, runtime policy for AI agents

DENVER, May 2026 — Wickhold today opened early access to Wickhold Leashgate, a new product that applies runtime policy to AI agents and their tool calls. Early access is included in the Enterprise tier, and teams can apply through their account contact. Wickhold has not set a date for general availability.

Teams that run Kubernetes are starting to give AI agents real work: reading logs, opening pull requests, changing configuration, calling internal services. Those agents act with real credentials, and the tools they call are often the same ones an engineer would use. If an agent is manipulated or simply wrong, the damage depends on what it was allowed to reach.

Leashgate treats an agent as a workload with an identity and a boundary. In early access it provides:

- **Agent identity.** Each agent is identified at runtime, separately from the service or person who launched it.
- **Tool-call policy.** Teams define which tools an agent may call and with what limits. Leashgate applies that policy at the moment of the call and records the decision.
- **Blast radius of an agent.** Teams can see what an agent could reach under its current policy, and narrow it before the agent runs.

Leashgate limits what a compromised agent can do. It does not judge what a prompt says, and it does not make an agent's decisions correct. Those limits are deliberate: the product acts on tool calls, where an agent's actions become real.

"I keep hearing the same thing from platform teams: the agents arrived before the policy did," said Maren Tolliver, CEO and co-founder of Wickhold. "We started this company to keep small failures from becoming big ones. An agent with too many permissions is a small failure waiting for a reason. I'd like teams to have a boundary in place before they need one."

"The design is deliberately plain: deny by default, check every tool call, write down the decision," said Dov Achterberg, CTO and co-founder. "I'd rather give early access teams something narrow that behaves predictably and hear from them about what's missing. There's plenty missing. It runs on Kubernetes only for now, for one thing. That's why it's early access."

Leashgate joins Wickhold's two other products: Wickhold Quenchline for runtime detection and containment in Kubernetes, and Wickhold Evenburn for cloud and cluster posture management. Early access is intended for teams running agents against real infrastructure who are willing to give direct feedback to the product team. Features and behavior will change during early access, and policy written today may need revisiting. Support during early access runs through a shared channel with the product team.

Wickhold will review each application with the applicant's platform and security teams, since a tool-call policy usually needs both to agree on it. Customers who are not on the Enterprise tier can register interest through their account contact.

Dov and Kofi Anselm, Head of Developer Relations, will publish technical notes from early access on the Wickhold blog.

### About Wickhold

Wickhold is the runtime security company for teams that run Kubernetes. Its products contain failures early, so small fires stay small. Founded in 2019 and based in Denver, Wickhold serves more than 140 customers.

Media contact: press@wickhold.example
