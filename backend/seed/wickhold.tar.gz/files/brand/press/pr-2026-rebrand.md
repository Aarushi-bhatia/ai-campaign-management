**For release February 10, 2026**

# Wickhold Security is now Wickhold

New name, new identity and a new tagline reflect a company built around containment

DENVER, February 10, 2026 — Wickhold Security today announced that it is now Wickhold. The company's legal name, Wickhold, Inc., its leadership and its customer agreements are unchanged. The brand, including the name, logo, colors and tagline, changes today.

The company's new tagline is "Small fires stay small." It replaces "Every workload. Always watched."

"For years we described what we watched. Our customers kept asking a better question, which is what happens next," said Maren Tolliver, CEO and co-founder of Wickhold. "I spent enough nights on call to know that failures are going to happen. What I want from a security product is that a small failure stays small. So that's what the name and the work should say."

### Why the change

A wick is where a fire is allowed to exist. The company's new identity starts from that idea. Wickhold's flagship product, Wickhold Quenchline, has offered runtime detection and containment for Kubernetes since September 2020, and containment is now what customers most often buy it for. The old name and tagline described visibility. The new ones describe the outcome the company works toward, which is keeping small failures from becoming big ones.

Dropping "Security" from the name was a practical choice as well. People already said "Wickhold".

### What is changing

- **Name.** Wickhold Security becomes Wickhold. The company's website and materials change over the coming weeks, and older documents may keep the previous name for a while.
- **Logo.** The shield and flame are retired. The new mark is a geometric W whose center stroke rises as a wick, tipped with one Ember dot.
- **Color.** Ember replaces Cobalt as the primary color, with Soot and Tallow as ink and ground.
- **Product name.** Wickhold Tallowatch, the company's cloud and cluster posture management product, will be renamed Wickhold Evenburn on March 2, 2026. The product and customers' contracts do not change. Customers will see the new name in the console and documentation on that date.
- **Unchanged.** Wickhold Quenchline keeps its name.

"Tallowatch was named in the same period as the old tagline, and it says 'watch' in a place where customers want a fix order," said Ilse Varga-Holm, VP Marketing. "Evenburn is the better name for what the product does. We'd rather make the change once, with notice, than leave customers with a product that sounds like it belongs to a different company."

The rebrand was led by the marketing team over the past year with input from customers and from engineers who carry a pager. Customers who attend Field Day meetups this spring will see the new identity first.

Customers do not need to take any action. Existing Helm charts, API keys and integrations keep working. Account teams will contact customers directly with details of the March change.

### About Wickhold

Wickhold is the runtime security company for teams that run Kubernetes. Its products contain failures early, so small fires stay small. Founded in 2019 and based in Denver, Wickhold serves more than 140 customers.

Media contact: press@wickhold.example
