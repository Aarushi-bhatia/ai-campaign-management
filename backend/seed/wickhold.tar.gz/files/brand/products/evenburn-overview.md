Wickhold Evenburn overview
Revised March 2026 for the rename. Product Marketing. Field team: use this version from now on.

---

**What it is.** Wickhold Evenburn (called Wickhold Tallowatch until March 2, 2026) is cloud and cluster posture management. It reads your cloud accounts and Kubernetes clusters, works out how the configuration differs from what you meant to run, and tells you what to fix first.

The rename changed the name. The product, its data and its contracts carried over. Existing customers needed no migration beyond a Helm chart rename, and the release notes have those steps.

Status: GA. Sold in the Team and Enterprise tiers.

## The three ideas to get right

Nearly every Evenburn conversation comes down to three concepts. Use these exact terms in copy, docs and demos, since they are also the names in the console.

### Drift

Drift is any difference between what a team declared and what is running. Declared state comes from Helm releases, manifests in a connected Git repo, and infrastructure baselines you approve in the console. Running state comes from the Kubernetes API and cloud provider APIs.

A typical example: the chart for `checkout-api` sets `readOnlyRootFilesystem: true`, somebody ran `kubectl patch` during an incident in June to get a debug tool working, and the patch never came out. Evenburn reports the object, the field, the declared value, the live value and who changed it, where the audit log can show that.

```text
DRIFT  apps/v1 Deployment shop/checkout-api
  field     spec.template.spec.containers[0].securityContext.readOnlyRootFilesystem
  declared  true    (helm release shop/checkout, rev 41)
  live      false
  first seen 2026-02-11T03:42:18Z
  changed by svc-oncall-breakglass (audit log)
```

Not all drift is a problem. Autoscalers change replica counts, and mutating webhooks add sidecars. Evenburn ignores the common cases by default, and teams can add ignore rules scoped by namespace, kind and field path. Every ignore rule keeps its author and a reason, so a reviewer can tell a deliberate choice from a forgotten one.

### Exposure path

An exposure path is a chain of real, currently valid connections from somewhere an outsider can reach to something that matters. Evenburn builds a graph from load balancers, ingresses, services, pods, service accounts, cloud roles, storage and secrets, then searches for routes through it.

```text
EXPOSURE PATH  ep-20817  severity: critical
  internet
   -> LoadBalancer  ingress-nginx/public
   -> Ingress       shop/storefront
   -> Pod           shop/storefront-6d9f (CVE fixed upstream, image not rebuilt)
   -> ServiceAccount shop/storefront
   -> Cloud role    prod-orders-rw (bound through workload identity)
   -> Object store  prod-orders-export (contains customer records, by tag)
```

Each step is a fact Evenburn can show you. A path does not mean someone has walked it. It means nothing in the configuration would stand in their way. In copy, keep that distinction clear. "Three exposure paths reach your orders bucket" is accurate. "Your orders bucket is exposed to attackers" adds drama and loses precision.

### Fix order

Fix order is the ranked list of changes that close the most exposure paths for the least work. Most posture tools hand a team hundreds of findings sorted by severity, and the team fixes whatever is easiest. Evenburn looks at the graph and asks which single change cuts the most paths to the most sensitive resources.

Removing one overly broad role binding may close 14 paths, while patching any one of the images on those paths closes one. The binding goes to the top of the list even though its individual CVSS-style score would look unremarkable.

Fix order is computed per scope, so a platform team sees the cluster-wide list and an application team sees the list for its namespaces. Each item shows the proposed change as a patch where we can generate one:

```yaml
# fix-order item 1 of 37, closes 14 exposure paths
# remove cluster-admin from the CI deployer
- op: remove
  path: /subjects/2
  # ClusterRoleBinding/ci-deployer-admin
```

Teams can export the list to their ticketing system through a webhook or read it from the API. They can also snooze an item with an expiry date.

## How it is deployed

There are two collectors and no node agent is required.

**Cloud collector.** Runs on Wickhold's side. You grant a read-only role in each cloud account, using a template we provide for each of the three major public clouds. It reads IAM, network, storage and managed Kubernetes configuration. It reads resource configuration only and does not read the contents of storage objects.

**Cluster collector.** A single Deployment installed with Helm that reads the Kubernetes API with a read-only ClusterRole.

```bash
helm install evenburn wickhold/evenburn \
  --namespace wickhold-system --create-namespace \
  --set cluster.name=prod-denver-1 \
  --set-file auth.token=./enrollment.token
```

Secret values are never read. The ClusterRole grants `get` and `list` on secret metadata through a dedicated aggregated view, and the collector records names, types and which pods mount them.

Collection is on a schedule with event top-ups. Full cloud inventory runs every six hours by default. Kubernetes watches feed changes in near real time, so cluster drift normally shows within a couple of minutes. Cloud drift can take as long as the next inventory unless the customer has connected audit log streaming.

Permissions come up in every security review, so here is the short version to give a reviewer:

| Component | Access | Writes anything? |
|---|---|---|
| Cloud collector | Read-only role on configuration APIs, scoped by account or organization | No |
| Cluster collector | `get`, `list`, `watch` on workloads, RBAC, networking objects and CRDs | Only its own lease and status |
| Git connection | Read-only access to the repos a customer selects | No |
| Audit log stream (optional) | Subscribe-only access to the customer's log export | No |

## A typical first month

**Days 1 to 3.** Connect one cloud account and one production cluster. Exposure paths and benchmark results appear after the first inventory. Most teams find a few surprises here, usually an old role binding from a migration.

**Week 2.** Connect the Git repo or Helm history so that drift has a declared source. Expect a burst of drift at first, because every undocumented hotfix since the cluster was built appears at once. Sort through this with the team that owns the cluster, add ignore rules with reasons, and tag sensitive storage.

**Weeks 3 to 4.** Work the top of the fix order. Pick the first ten items, assign them, and watch the path count fall. Solutions engineers should book a review at this point to show the before and after. This number is what keeps a team using the product after the pilot excitement wears off.

The common reason an Evenburn rollout stalls is ownership. A platform team can see a role binding that needs to go, but an application team owns the deploy that depends on it. Per-namespace fix order lists exist for this reason, and it helps to get those teams into the console early.

## Benchmarks and audit work

Evenburn evaluates clusters and cloud accounts against CIS Benchmarks and produces evidence reports that map findings to SOC 2, PCI DSS and HIPAA controls. These reports support the audit process. They do not on their own make a customer compliant with anything, and copy should not suggest they do. Wickhold supports customers' GDPR obligations, and that is the extent of what we say on the subject.

Custom checks are written as small YAML rules with a match on resource kind and a condition on fields. There is a library of about 400 built-in checks, and the console shows which ones are noisy for a given customer so that they can be tuned.

## Customer proof

Ostler Grocers runs Evenburn across 1,900 nodes and reported 63% fewer open critical misconfigurations in 90 days. They got there by working the fix order from the top rather than triaging by severity. Keep the 90-day window and the node count with the figure.

## With Quenchline

Wickhold Quenchline contains incidents at runtime. Evenburn reduces how far an incident could go. In the Team tier the two share a console. A Quenchline detection on a pod shows the exposure paths that run through that pod, which helps an on-call engineer decide how hard to contain. In the other direction, Evenburn can use Quenchline's process data to mark a package as loaded or never loaded at runtime, which pushes unused vulnerable packages down the fix order.

That second feature needs the Quenchline agent. Without it Evenburn treats every package in the image as potentially in use.

## What Evenburn does not do

- It does not contain anything. It reports and proposes. If a workload misbehaves right now, that is a job for Quenchline.
- It does not change your environment on its own. Patches are proposals, and a human or the customer's own pipeline applies them.
- It does not block deployments. There is no admission controller in the product, though customers can call the API from CI and fail their own build.
- It does not see inside storage objects, so data sensitivity comes from tags and naming conventions the customer sets up. If tagging is poor, exposure paths to sensitive data will be under-reported.
- It does not cover on-premises hypervisors or bare-metal network gear. On-premises Kubernetes clusters are supported through the cluster collector.
- It cannot tell whether a path has been used. For that you need runtime data and logs.

## Things that were tried and dropped

The first version of fix order, back under the old name, used a single numeric risk score. Customers argued with the score instead of fixing things, and support tickets asking why a resource scored 71 rather than 74 took up real time. The score was removed and replaced by a plain count of paths closed. Scored risk comes up in RFPs now and then. The answer is that we show the paths and leave the arithmetic out.

An auto-fix option also existed briefly as a private preview. Two design partners turned it on and both turned it off within weeks, because a correct patch applied at the wrong moment still caused a rollout. We do not plan to bring it back, and it should not appear on any roadmap slide.

## Writing about it

Bad example, and the fix:

| Bad example | Better |
|---|---|
| "Eliminate cloud risk with total visibility." | "See which change closes the most exposure paths, then make that change first." |
| "Hackers can walk right through your misconfigurations." | "Evenburn found 37 exposure paths in this cluster. One role binding accounts for 14 of them." |
| "AI-powered posture intelligence." | Say what it does. The graph search is deterministic and there is no model in it. |

For engineers, show output. A drift record or an exposure path does more than a paragraph, and the sample output in this document can be reused provided the names stay fictional.

For a CISO, the framing is what to fund first: which fixes reduce the most exposure this quarter, and what evidence goes to the auditor.

Short description, for listings and event programs:

> Wickhold Evenburn is cloud and cluster posture management that tells you what to fix first.

Slightly longer:

> Wickhold Evenburn tracks drift across cloud accounts and Kubernetes clusters, maps exposure paths from the internet to sensitive resources, and ranks fixes by how many paths each one closes.

## Questions that keep coming up

**Is there an agent?** Not on the nodes. There is one Deployment per cluster, plus read-only cloud roles.

**How long until first results?** The first full inventory normally completes the same day, depending on account size. Drift detection needs a declared source connected, so teams that have not linked a repo or Helm history see exposure paths and benchmark results first.

**Does it replace a cloud provider's built-in posture tool?** It reads the same configuration and adds the cluster side and the path analysis. Some customers keep both. We do not ask anyone to turn theirs off.

**Multi-cloud?** Yes, one graph across accounts and the three major public clouds. A path can cross from a cluster in one cloud to storage in another if the credentials allow it.

**Where does the data live?** In Wickhold's hosted service. We store configuration metadata and no customer application data. Wickhold holds SOC 2 Type II, renewed in January 2026.
