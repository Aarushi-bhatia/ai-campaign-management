# Wickhold Leashgate

*Product marketing overview for the May 2026 early access. First draft for field and web teams, May 4, updated September 2026.*

## Status

Wickhold Leashgate is in early access, as of May 2026. It is offered to Enterprise tier customers who sign an early access addendum. There is no announced date for general availability.

## The short version

Agents are moving from demos into production clusters, and the tools they call are real: a ticketing API, a database, a deploy pipeline, a shell. An agent that reads a poisoned document or a hostile web page can be talked into calling those tools with the permissions its owner gave it. Leashgate prevents prompt injection from becoming an incident. It sits between the agent and its tools, gives each agent a verifiable identity, and checks every tool call against policy before the call goes through.

Runtime policy for AI agents and their tool calls: that is the whole product. It comes from the same place Wickhold Quenchline did. Assume something will go wrong inside the workload, decide ahead of time how far it can go, and make that limit hold on the platform where the workload runs.

## Why this belongs to a Kubernetes security company

Most of the agents our design partners run are ordinary Deployments with a service account, a few secrets and network access to internal APIs. Their platform teams already know how to reason about a compromised pod. Tool calls are the part they cannot see. From the network, a hostile tool call and a legitimate one look the same: an authorized POST to an internal service.

Early design partner conversations kept returning to one question: what is the worst this agent could do on a bad day? We call the answer the blast radius of an agent. Leashgate exists to measure that and to make it smaller.

## Core concepts

### Agent identity

Every agent gets an identity tied to the workload rather than a shared API key. Leashgate takes a projected, audience-bound service account token from the pod and exchanges it for a short-lived agent credential, by default valid for 15 minutes. Policies and logs refer to that identity, so "which agent did this" has a precise answer even when ten agents share a framework and a namespace.

Agents acting for a human user can pass that user's identity along. Policy can then require both, so an agent cannot use a tool its current user could not use directly. This is the case design partners ask about most.

### Tool-call policy

A tool-call policy is a declarative rule set, stored as a Kubernetes custom resource. It says which agent may call which tool, with what arguments, how often, and whether a person must approve first.

```yaml
apiVersion: leashgate.wickhold.example/v1alpha1
kind: ToolCallPolicy
metadata:
  name: support-triage-agent
  namespace: support
spec:
  agentSelector:
    matchLabels:
      agent: support-triage
  defaultAction: deny
  rules:
    - tool: tickets.search
      action: allow
    - tool: tickets.update
      action: allow
      arguments:
        status:
          oneOf: [open, pending, resolved]
      rate: 60/minute
    - tool: crm.export
      action: requireApproval
      approvers: [group:support-leads]
      timeout: 10m
    - tool: shell.*
      action: deny
```

`defaultAction: deny` is the default and we recommend leaving it there. Note the `v1alpha1` in the API version: field names may change during early access, and design partners should expect at least one schema migration.

### Blast radius of an agent

Leashgate reads an agent's policy, its service account's RBAC and its Secret mounts, then reports what the agent could reach: every tool it may call, each resource those tools touch, and any route around the gateway, such as a direct network path to a database the agent should only reach through a tool. The report is meant to be read in a security review.

```text
AGENT  support/support-triage      identity: spiffe://wickhold.example/ns/support/sa/triage
  tools allowed            2
  tools requiring approval 1
  tools denied             14
  bypass routes            1
    pod can reach postgres.support.svc:5432 directly (no NetworkPolicy)
```

Bypass routes matter more than anything else in that output. A gateway that an agent can walk around enforces nothing.

## How it works

Leashgate has two parts, the gateway and the policy controller.

**The gateway** runs as a sidecar next to the agent or as a shared Deployment in the namespace. Agents point their tool endpoints at the gateway, either over HTTP or as an MCP server that proxies upstream MCP servers. For each call, the gateway verifies agent identity, evaluates the tool-call policy, writes a decision record and forwards or refuses the call. A refused call returns a structured error the agent can read, so a well-built agent can recover or ask for help rather than retry in a loop.

**The policy controller** watches `ToolCallPolicy` objects, validates them and distributes them to gateways. Gateways cache the last valid policy. If the gateway cannot evaluate a call for any reason, it refuses it. Leashgate fails closed, which means an outage of the gateway stops the agent's tools. That is the right behavior for a security control, and teams need to plan for it.

Install is one Helm chart, early access users only:

```bash
helm install leashgate wickhold/leashgate \
  --namespace wickhold-system \
  --set earlyAccess.token="$EA_TOKEN" \
  --set gateway.mode=sidecar
kubectl label namespace support leashgate.wickhold.example/inject=enabled
```

Requirements during early access: Kubernetes, any recent release, containerd, and agents that make tool calls over HTTP or MCP. Frameworks that call tools in-process, as plain function calls inside the agent's own memory, are out of scope unless the tool itself is reached over the network.

### With Quenchline

Leashgate can ask Quenchline to act. If a policy marks a repeated-denial pattern as suspicious, it can request a containment action, normally isolating the agent pod's network, through the same pipeline Quenchline uses for its own detections. This requires Quenchline on the node. The feature is off by default.

Every decision record goes to the same export path as Quenchline's, so a SIEM rule can correlate a denied tool call with the runtime events around it.

## Walkthrough: the support agent

This is the demo story, and it is the one we use with design partners.

A support triage agent reads incoming tickets and updates them. A customer email contains hidden text telling the agent to export the customer list to an outside address. The agent, doing what agents do, tries it.

1. The agent calls `crm.export` through the gateway. The policy says `requireApproval`, so the call waits.
2. A support lead sees the request in Slack, with the agent identity, the arguments and the ticket that triggered it. They decline.
3. The agent tries `shell.exec` to get at the data another way. Policy denies it, and the gateway returns a structured refusal.
4. After a third denial in a minute, a rule marks the pattern as suspicious. Leashgate requests network isolation from Quenchline, and the pod is contained.
5. The on-call engineer gets a timeline with four decision records and the ticket ID.

The agent was fooled, and the demo does not pretend otherwise. What matters is how little it managed to do afterward.

## What it does not do

- It does not read or judge the model's prompts, reasoning or output. It sees tool calls and their arguments.
- It does not decide whether an allowed call was wise. A policy that allows `tickets.update` allows a bad ticket update.
- It does not cover agents running outside Kubernetes during early access.
- It does not secure the tools themselves. A vulnerable internal API is still vulnerable to any caller.
- It has no published latency figures yet. We are measuring with design partners. Do not quote a number.

## Early access: what partners get

- Named engineering contact and a shared Slack channel
- Monthly policy review with the product team
- Roadmap input on tool adapters and approval workflows
- Support during business hours, Denver time. There is no SLA during early access
- Limit of a small number of clusters per customer, agreed in the addendum

What we ask in return: a named platform owner, a real agent in at least a staging environment, and permission to learn from anonymized policy patterns.

## Who to talk to first

Platform leads who have been asked to get an agent into production and have a security review standing in their way. They already have the concern and the budget conversation under way. The secondary contact is a security architect writing internal rules for agent use, who needs something more enforceable than a policy document.

Avoid leading with AI safety in general. We are selling a control point for tool calls in a cluster. If a conversation moves to model quality or hallucination, say plainly that this is outside what Leashgate looks at.

## Messaging draft

Headline options for the early access page:

- Runtime policy for AI agents
- Know what your agents can reach
- Every tool call, checked against policy

Subhead:

> Wickhold Leashgate, in early access, gives each agent an identity and puts a policy in front of every tool call, so a bad day for one agent stays small.

Platform engineer version:

> One sidecar. `defaultAction: deny`. Tool calls go through a gateway that checks agent identity and arguments, writes a decision record, and refuses anything your `ToolCallPolicy` does not allow. Your agent framework stays the same.

Security leader version:

> Before an agent goes live, you need to know its blast radius. Wickhold Leashgate, in early access, reports what each agent could reach and enforces the limit, with a record of every decision for your auditors.

Bad example, from an early brainstorm:

> AI agents are the next attack surface and the clock is ticking. Is your organization ready?

That is fear with a question on the front of it, and it tells a platform lead nothing. The same goes for anything calling agents "rogue".

## Open items

- Pricing for Leashgate after early access is undecided. Say it is included with the Enterprise tier for the early access period and leave it there.
- Adapter list for approval workflows is still moving. Slack is working, others are planned.
- Screenshot set for the web page is due from design. The console view is not final, so use diagrams until then.

Questions go to Product Marketing. Noor Eskelund is reviewing naming, and Dov Achterberg is the technical reviewer.
