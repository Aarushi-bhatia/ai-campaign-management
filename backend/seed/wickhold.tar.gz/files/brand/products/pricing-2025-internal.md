Wickhold Security rate card
INTERNAL. Sales and SEs only. Please don't forward outside the company.

Pulled together by Sales Ops so everyone stops quoting from old decks!! If your deck has different numbers, your deck is wrong.

PER NODE, PER MONTH, BILLED ANNUALLY

| Plan | List price | What's in it |
|---|---|---|
| Core | $15 | Quenchline: runtime detection and containment, standard detection rules, 30 days of event history |
| Team | $24 | Everything in Core, plus Tallowatch posture management and shared console |
| Scale | $36 | Everything in Team, plus 13 months of event history, priority support, SSO/SCIM and a named SE |

## Which plan do I lead with?

Lead with Team. Every time. Tallowatch is what gets the security side of the buying committee into the room, and a Core deal with no Tallowatch is the deal most likely to churn at renewal.

Quick rules of thumb from Q4:

- Under 100 nodes, one cluster: Core is fine. Don't waste a cycle pushing up.
- Multi-cloud, or an audit coming up in the next two quarters: Team.
- Regulated, more than one security team, or asks about retention in the first call: Scale tier. Don't wait for them to ask. Retention is the thing that moves them.

## Scale tier talking points

- 13 months of history covers a full audit year plus a month, which is why we picked that number
- Named SE, which the customer feels right away
- Priority support: P1 response in under an hour, 24x7
- SSO and SCIM are Scale-only. Yes, people complain. No, we're not moving them down this year

## Worked examples (for the quote tool)

| Customer profile | Plan | Math | Annual |
|---|---|---|---|
| 120 nodes | Core | 120 × $15 × 12 | $21,600 |
| 400 nodes | Team | 400 × $24 × 12 | $115,200 |
| 1,000 nodes | Scale | 1,000 × $36 × 12 | $432,000 |

## Node counting

Worker nodes only. Count at signature, true up annually. Tallowatch-only cloud accounts with no Kubernetes aren't something we quote. Send those to your manager.

## Non-standard terms

Anything off this card goes to Sales Ops before it goes to the customer. Multi-year, unusual payment schedules, pilots, paper changes: all of it. Attach the opportunity link. Turnaround is usually two business days, longer at quarter end, so don't leave it until the 30th.

## Moving plans

Upgrades mid-term are prorated from the first of the next month. Downgrades wait for renewal. If someone moves from Scale to Team at renewal they lose history past 30 days, so warn them before the data ages out. Export is possible but it's a support ticket.

## Renewals

CSMs start renewal conversations 120 days out. Use the card that's current at renewal, not the one on the original order form.

## FAQ

**Is there a monthly option?** No. Annual only.

**Do prospects get to see this?** Core, Team and Scale list prices are fine to share once you're in an active opportunity. The sheet itself stays internal.

**Who owns this?** Sales Ops. Questions in the deal-desk Slack channel.

Rev. 3, Jan 2025
