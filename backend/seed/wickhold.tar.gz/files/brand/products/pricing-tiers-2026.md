---
title: Pricing tiers
effective: March 2026
owner: Ilse Varga-Holm
---

# Pricing tiers, 2026

These tiers took effect in March 2026 and replace every earlier price list. All plans are billed annually, per node, with a $24,000 annual minimum.

| Tier | Price | Includes |
|---|---|---|
| Core | $18 per node per month | Wickhold Quenchline |
| Team | $29 per node per month | Quenchline + Wickhold Evenburn |
| Enterprise | Talk to sales | All products, plus Wickhold Leashgate early access |

## What may be published

Publish Core and Team prices only. Never publish an Enterprise figure, in any form: no "starting at", no range, no per-node estimate, no worked example. On the website, in decks and in replies to public questions, the Enterprise row reads "Talk to sales". This holds even when a customer's own Enterprise price is already known to the person writing.

Show the two prices the way the table does, as dollars per node per month, and include "billed annually" and the annual minimum near them. A per-node price without the minimum gives a small team the wrong idea. The rest of the public-copy pricing rule is kept with the sales notes.

Good:

> Core is $18 per node per month, billed annually, with a $24,000 annual minimum.

Bad example:

> Enterprise usually lands somewhere around the Team price plus a bit.

## How nodes are counted

A node is any Kubernetes worker node in a cluster connected to Wickhold. Control plane nodes that a managed Kubernetes service runs for you are not counted. Self-managed control plane nodes count only if an agent is installed on them.

The contract states a committed node count for the year. Clusters grow and shrink, so true-up is once a year at renewal, using the average of monthly node counts. Autoscaling spikes do not trigger an invoice during the term.

Evenburn has no node agent, but it is still priced by node, based on the cluster nodes it covers. Cloud accounts themselves carry no separate charge.

## The minimum in practice

The annual minimum applies to every Core and Team contract.

| Example | Calculation | Annual price |
|---|---|---|
| 80 nodes on Core | 80 × $18 × 12 = $17,280 | $24,000 (minimum applies) |
| 150 nodes on Core | 150 × $18 × 12 = $32,400 | $32,400 |
| 60 nodes on Team | 60 × $29 × 12 = $20,880 | $24,000 (minimum applies) |
| 300 nodes on Team | 300 × $29 × 12 = $104,400 | $104,400 |

The minimum is reached at 112 nodes on Core and 69 nodes on Team. Teams well below those counts are usually better served by a conversation with sales about scope before anyone sends a quote.

## Choosing a tier

**Core** suits a team whose first concern is runtime: they want containment on their clusters and already have some way of handling configuration.

**Team** suits most customers we talk to, because exposure paths and runtime detections are more useful in one console. Moving from Core to Team mid-term is prorated.

**Enterprise** is for customers who need Leashgate early access or have procurement and support requirements that the first two tiers do not cover. Leashgate is available only here while it is in early access.

## Common questions

**Is there a monthly plan?** No. All tiers are billed annually.

**Are prices in US dollars?** Yes, and taxes are extra where they apply.

**Does the Team price include the cloud accounts Evenburn reads?** Yes. Pricing follows nodes, however many accounts the customer connects.

**Can a customer buy Evenburn on its own?** That is not a listed tier. Refer anyone who asks to sales.

**What does a customer on Core see in the console?** Quenchline only. Evenburn views appear after a move to Team.

**What should the website say about Leashgate pricing?** Only that Leashgate early access is part of the Enterprise tier. There is no separate price to show.

## Changes to this page

Changes go through Ilse Varga-Holm, with Finance sign-off. Web, sales and the renewal team get notice before a change goes live, so a customer never sees a price on the site that their account manager has not seen.
