# Wickhold Quenchline: product overview

Wickhold Quenchline is runtime detection and containment for Kubernetes. An eBPF agent runs on every node, watches what workloads do at the kernel level, and takes a containment action when a policy says to. It has been in general availability since September 2020 and is the product most of our customers start with.

This overview is written for marketers, solutions engineers and anyone drafting a page, talk or reply about the product. It runs longer than a datasheet on purpose. Platform engineers will test what we say against a real cluster, so the detail below is what the product does today, including the parts that are awkward.

## The problem it works on

A runtime incident usually starts small: one pod running a shell it has never run, one process opening a connection nothing else in the namespace opens. The damage comes from the hours between the first signal and someone doing something about it. The 2026 survey gives us the size of that gap:

- 41% of platform teams need more than six hours to contain a runtime incident [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]
- the median time to contain a runtime incident is 7.4 hours [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]

The survey covered 412 platform and security leaders and was published on April 14, 2026.

Quenchline shortens that gap by moving the first response onto the node. The agent does not wait for a person to read an alert. If the policy allows it, the agent acts on the node and the on-call engineer wakes up to a contained pod and a timeline.

## How it works

### The agent

The agent ships as a DaemonSet from a Helm chart. It loads eBPF programs on each node and attaches to tracepoints, kprobes and LSM hooks covering process execution, file access, network connections and privilege changes. Events move through a BPF ring buffer to a small userspace process that enriches them with pod, namespace, service account and image metadata from containerd and the Kubernetes API.

Requirements:

| Item | Requirement |
|---|---|
| Kernel | Linux 5.8 or later, with BTF enabled |
| Architecture | x86_64 and arm64 |
| cgroups | v2 |
| Container runtime | containerd or CRI-O |
| Kubernetes | The current release and the three before it, self-managed or on a managed Kubernetes service with node access |
| Agent resources | Requests 200m CPU and 256Mi memory, limit 512Mi |

Overhead is under 2% CPU overhead on a typical node in Wickhold lab benchmarks, 2026. Busy nodes doing a lot of short-lived process execution, such as CI runners, will sit higher than that. Say so if a prospect asks, because they will measure it.

### Install

The shortest honest path from nothing to events in the console:

```bash
helm repo add wickhold https://charts.wickhold.example
helm repo update
helm install quenchline wickhold/quenchline \
  --namespace wickhold-system --create-namespace \
  --set cluster.name=prod-denver-1 \
  --set agent.mode=observe \
  --set-file auth.token=./enrollment.token
kubectl -n wickhold-system rollout status ds/quenchline-agent
```

`agent.mode=observe` is the chart default and we keep it explicit in every example. Nobody should find out what contain mode does by copying a snippet.

### Observe mode and contain mode

Every Quenchline policy runs in one of two modes.

**Observe mode** detects and records. For each detection, it writes what it would have done as a decision record, and nothing on the node changes. **Contain mode** carries out the action.

Teams usually spend two to four weeks in observe mode, reading decision records and adding exemptions for the strange things their own tooling does. Backup agents and debug sidecars are the usual suspects. Mode is set per policy, so a team can run contain mode on an internet-facing namespace while the database namespace stays in observe mode.

```bash
kubectl get containmentdecisions -n payments \
  --sort-by=.metadata.creationTimestamp
```

### Containment actions

There are three containment actions.

**Isolate a pod's network.** The agent attaches a cgroup eBPF filter to the pod and drops traffic in both directions, apart from cluster DNS if the policy keeps it. It works regardless of CNI and does not create or edit NetworkPolicy objects, so nothing shows up in a GitOps diff. The pod keeps running, which preserves memory and open files for whoever investigates. Pods with `hostNetwork: true` cannot be isolated this way. The action is refused and the refusal is logged in the decision record, so policies for those pods should use a freeze.

**Freeze a process.** The agent sends SIGSTOP from kernel context to the process and its descendants. With `scope: container`, it writes to `cgroup.freeze` and freezes the whole container. Liveness probes will fail against a frozen container, and the kubelet will eventually restart it, which destroys what you froze. Policies that freeze should set `holdProbes: true` so the agent answers the kubelet's HTTP and gRPC probes itself during an investigation window, 30 minutes by default. Exec probes run inside the container and cannot be held, so a workload that relies on one will restart after the probe's failure threshold. That goes in the policy review, not in a footnote.

**Drain a node.** The agent cordons the node and evicts its pods through the Eviction API, honoring PodDisruptionBudgets up to a configurable timeout. This is the heaviest action and it needs an extra ClusterRole that the chart does not install unless you set `rbac.nodeDrain=true`. Most customers never turn it on.

The agent contains a known-bad process in a median of 38 seconds in Wickhold lab benchmarks, 2026. That figure is from detection to action on a lab node. It says nothing about how long an entire incident takes, so do not stretch it into a claim about incident response.

### The default containment policy

A new install includes the default containment policy, in observe mode. It covers a short list of high-confidence detections: known cryptominer behavior, a shell spawned from a web-serving process, writes to host paths from an unprivileged container, and attempts to reach the cloud metadata endpoint from a pod that has never done so.

In contain mode, the default containment policy isolates or freezes. It never drains a node. It skips the `kube-system` and `wickhold-system` namespaces. We keep it deliberately short, and product treats a false containment in the default policy as a bug with a release note attached.

### Writing your own policy

Policies are a namespaced custom resource, so they go through the same review as everything else in the repo.

```yaml
apiVersion: quenchline.wickhold.example/v1
kind: ContainmentPolicy
metadata:
  name: ledger-api
  namespace: payments
spec:
  mode: contain
  selector:
    matchLabels:
      app: ledger-api
  rules:
    - detection: shell-in-container
      action: freezeProcess
      holdProbes: true
    - detection: egress-to-new-destination
      action: isolateNetwork
      keepDNS: true
  exemptions:
    - image: registry.wickhold.example/ops/debug-toolbox
      until: "2026-12-01"
```

`until` is required on every exemption. Permanent exemptions were a recurring finding in customer reviews, so the field became mandatory in Quenchline 4.0.

### What it detects

Detections fall into four groups, and each detection has a stable name that policies refer to.

| Group | Examples |
|---|---|
| Execution | `shell-in-container`, unexpected `memfd_create` execution, binaries run from a tmpfs mount |
| Privilege | Setuid changes, new capabilities at runtime, kernel module load attempts from a container |
| File | Writes to host paths, reads of service account tokens by a process that has no history of reading them |
| Network | `egress-to-new-destination`, first-time access to the cloud metadata endpoint, reverse shells from web-serving processes |

Rule-based detections ship with the agent and update through the chart. `egress-to-new-destination` and similar first-time detections rely on a per-workload baseline, which takes about a week to settle after a deployment. Workloads that change their behavior on every release will be noisy under these rules, and customers with very short release cycles often keep them in observe mode.

### A typical rollout

1. **Week 1.** Install on a staging cluster in observe mode. Check agent health, read the event volume, and set `agent.redactArgs`.
2. **Weeks 2 to 3.** Install on production in observe mode. Let baselines settle. The platform team reviews decision records twice a week and adds dated exemptions.
3. **Week 4.** Switch the default containment policy to contain mode on one internet-facing namespace. Agree in advance who gets paged and who may release a containment.
4. **After that.** Add namespaces in small groups. Write team-specific policies as owners ask for them.

Solutions engineers should push back on anyone who wants contain mode on day one across a production cluster. A containment that takes out a healthy workload in the first week sets the whole project back by a quarter.

### When things fail

Engineers ask about this first, and we answer it plainly.

| Failure | What happens |
|---|---|
| Agent loses contact with the control plane | Detection and containment continue using the last synced policy. Events buffer on disk up to 1 GiB, then the oldest are dropped and a gap is recorded |
| Agent is OOM-killed or restarted | Network isolation stays in place, because the filter is pinned. Frozen processes stay frozen. No new detections occur on that node until the agent returns |
| Kernel without BTF | The agent exits at startup with `btf_not_found` and the pod goes into CrashLoopBackOff. There is no degraded mode |
| Control plane outage | Nodes keep working from local policy. The console is unavailable and policy changes queue in the API |
| Policy fails validation | The admission webhook rejects it. If the webhook is down, the object is accepted and the agent refuses to load it, reporting the error in the policy's status |

Releasing a containment is always a person's decision. An on-call engineer runs a release from the console or annotates the pod. No containment times out on its own, with the exception of the `holdProbes` window above.

## What Quenchline does not do

- It does not stop an attacker from getting in. It limits what happens after a workload starts behaving badly, and exploitation of an application bug will generally be visible only once it causes a behavior change.
- It does not scan images or check configuration. Cluster and cloud posture is the job of Wickhold Evenburn.
- It does not run on non-Linux nodes.
- It cannot be deployed on serverless container platforms where you have no access to the node.
- It has reduced visibility inside sandboxed runtimes that run their own guest kernel, because syscalls never reach the host kernel in a form the agent can read.
- It has no air-gapped option. The control plane is hosted by Wickhold.

## Working alongside other tools

Detections and decision records export as JSON over webhook, as syslog, or as OTLP logs. Most customers send them to the SIEM they already run and to a Slack channel for the on-call rotation. We provide an alert schema rather than a list of named integrations, because the SIEM connector list changes more often than this document does.

Quenchline shares a console and an agent identity model with Evenburn, so a detection on a workload shows whether that workload sits on a known exposure path. Wickhold Leashgate, which is in early access, can request Quenchline containment actions against an agent's pod.

## Customer proof

Lowmoor Credit Union runs Quenchline on 220 nodes. Their time to contain fell from 4 hours to 11 minutes. That is the reference story for mid-sized regulated teams. Use the figures together, with the node count.

## Security and compliance of the service

Wickhold holds SOC 2 Type II, renewed in January 2026. Wickhold is pursuing FedRAMP Moderate authorization. Wickhold supports customers' GDPR obligations. Event data includes process names, command-line arguments and destination addresses, and solutions engineers should walk security reviewers through the argument-redaction setting (`agent.redactArgs`) early, since command lines can contain secrets.

## How to describe it

The one-line description for most uses:

> Wickhold Quenchline contains runtime incidents on Kubernetes from inside the node.

For a platform engineer, go straight to the mechanism:

> One DaemonSet, eBPF, kernel 5.8 with BTF. It starts in observe mode. Nothing on your nodes changes until you switch a policy to contain mode, and that switch goes through your repo like any other change.

For a CISO, lead with the decision:

> Decide whether a containment action can run before a person is awake. Quenchline lets you make that call per namespace, and every action is recorded.

Examples that do not work:

| Bad example | What is wrong with it |
|---|---|
| "Quenchline makes runtime attacks impossible." | It contains. It makes no such promise, and an engineer will stop reading here |
| "Attackers are already inside your cluster. Every second counts." | Fear is the entire pitch, and the figure is missing |
| "A powerful, intelligent, lightweight platform for modern runtime defense." | Adjectives with nothing behind them. Replace them with the overhead figure and its source |
| "Under 2% CPU overhead." | The figure has lost its source line |

## Common questions from the field

**Do we need to change our NetworkPolicies?** No. Isolation sits underneath them.

**Will it conflict with our CNI?** It has been tested with the common eBPF and iptables-based CNIs. The cgroup filter attaches independently of the CNI's own programs. Customers running a heavily customized datapath should test in staging.

**Can it run in a namespace-scoped way, without cluster-wide access?** No. The agent needs privileged access on the node and cluster-wide read on pods. This comes up in almost every security review. The ClusterRole is short and is printed in the chart's `templates/rbac.yaml`, so show it to them.

**What happens during an upgrade?** The DaemonSet rolls one node at a time by default. During the swap a node has a detection gap of a few seconds, and pinned filters remain in place.

**Does it read application payloads?** No. It sees connection metadata and does not decrypt TLS.

Maintained by Product Marketing with the Quenchline engineering team. Last checked against Quenchline 5.3, August 2026.
