# Wickhold Security release notes, 2024 and 2025

Everything we shipped, oldest first. Quenchline and Tallowatch ship on separate trains, so version numbers won't line up. Agent and chart versions are listed per entry. Questions? Ask your account team!

## 2024

### January 16, 2024: Tallowatch 2.1
- New CIS Benchmarks profiles for Kubernetes 1.28 and 1.29
- Tallowatch now flags pods running with `hostPID` as high severity by default
- Faster first inventory on large cloud accounts
- Fixed: benchmark results missing for clusters with custom API server ports

### February 6, 2024: Quenchline 3.2
Big one for busy clusters! The agent now uses a BPF ring buffer in place of per-CPU perf buffers on kernels that support it, for much lower event loss under load.
- New detection: reverse shell from a web-serving process
- Fixed: agent memory growth on nodes with very high pod churn

Upgrade note: the new buffer is on by default. Set `agent.ringBuffer=false` if you need to stay on perf buffers while you investigate anything unexpected.

### February 20, 2024: Quenchline 3.2.1
Patch release. Fixes a crash in the metadata enricher when a container exited before its first event was processed. All 3.2 customers should upgrade.

### March 12, 2024: Tallowatch 2.2
Introducing **exposure paths**! Tallowatch now connects internet-facing load balancers, pods, service accounts and cloud roles into one graph, so you get a single pane of glass for cloud and cluster risk. See exactly how an outsider could reach your most sensitive data!
Here's how it works: Tallowatch reads your cloud accounts and clusters, then searches for chains of real connections from the internet to the things that matter most. Each step in a path is backed by a live configuration fact, so you can hand the path straight to the team that owns it.

- Preview for all Tallowatch customers
- Read-only role templates updated for all three major public clouds

### April 9, 2024: Quenchline 3.3
- Decision records are now available in observe mode, so you can see exactly what a policy would have done
- `kubectl get containmentdecisions` support via new CRD
- Fixed: CRI-O metadata lookups timing out on first event from a new pod

### May 14, 2024: Tallowatch 2.3
- Risk score added to every finding (0 to 100)
- Slack notifications for new critical findings
- Fixed: duplicate findings on clusters registered twice

### May 28, 2024: Quenchline 3.3.2
Patch release. Fixes a rare kernel verifier rejection on nodes with very large numbers of CPUs. Thanks to the customers who sent us logs!

### June 4, 2024: Quenchline 3.4
Seamless Helm upgrades are here! Pinned network isolation filters now survive agent restarts and upgrades, so a contained pod stays contained during a rollout.
- DaemonSet rolling update defaults changed to one node at a time
- New agent health metrics for ring buffer drops and policy sync age

### June 25, 2024: Tallowatch 2.3.2
Patch release. Fixes an exposure path timeout on accounts with thousands of security groups, and corrects a broken link in Slack notifications.

### July 16, 2024: Tallowatch 2.4
- Drift detection for Helm releases (beta)! See when what's running no longer matches what you shipped
- Tallowatch collector now runs as a single Deployment, down from two
- New evidence report templates for SOC 2 and PCI DSS

Upgrade note: remove the old `tallowatch-watcher` Deployment after upgrading if your values file pinned it.

### August 20, 2024: Quenchline 3.6
arm64 nodes are now fully supported! The same chart installs on mixed-architecture clusters.
Before this release, arm64 pools had to run an experimental image with detections missing. That image is retired. If you pinned `image.tag` to the old `-arm64-exp` suffix, remove the pin before upgrading, or the chart will refuse to render.

- Support for Kubernetes 1.31
- New detection: writes to host paths from unprivileged containers
- 3.5 was an internal build and was not released

### September 2024: Slow Burn Summit release
Announced on stage in Denver! What a week:
- Default containment policy for Quenchline, shipped in observe mode
- Tallowatch drift detection leaves beta
- Tallowatch exposure paths now cross cloud accounts

### Where things stood at the end of Q3 2024

| Product | Supported versions | Minimum kernel | Notes |
|---|---|---|---|
| Quenchline | 3.4, 3.6 | 4.19 | arm64 from 3.6 |
| Tallowatch collector | 2.3, 2.4 | n/a | One Deployment from 2.4 |

Support covers the two most recent minor versions of each product. Older agents keep running, but we'll ask you to upgrade before we can look into a bug.

### October 15, 2024: Tallowatch 2.6
- Git repo connection as a declared source for drift
- Ignore rules for drift, scoped by namespace, kind and field path
- Tallowatch auto-fix private preview opens to design partners

Note: 2.5 was skipped to keep the Summit build separate from the regular train.

### November 19, 2024: Quenchline 3.8
- `holdProbes` for frozen workloads, so the kubelet doesn't restart what you froze
- Argument redaction with `agent.redactArgs`
- Fixed: false positive on package managers in init containers

Known issue: `holdProbes` does not apply to exec probes. That is a limit of how exec probes run and it will not change.

### December 10, 2024: Tallowatch 2.7
- First version of **fix order**: findings ranked by risk score and paths closed
Instead of an endless list sorted by severity, fix order shows the short list of changes that matter most. Our design partners cut through months of backlog with it, and we can't wait to hear what you do with it!

- Our most robust evidence reports yet, now with HIPAA control mapping
- Tested against Kubernetes 1.32 release candidates

## 2025

### January 21, 2025: Quenchline 3.9
- OTLP log export joins webhook and syslog
- Support for Kubernetes 1.32
- Last release supporting kernels below 5.8. Plan your node upgrades!

Deprecation: 3.x remains supported for six months after 4.0 ships. Security fixes only during that window.

### January 28, 2025: Tallowatch 2.7.1
Patch release. Fixes a fix order ranking bug where paths through the same load balancer were counted twice, which pushed some items higher than they should have been. Rankings may shift after you upgrade. That's expected!

### February 18, 2025: Tallowatch 2.8
- Tallowatch can now use Quenchline process data to mark packages as loaded or never loaded
- Fixed: exposure path graph missing some ingress controllers
- Support for Kubernetes 1.32

### March 4, 2025: Tallowatch 2.8.1
Patch release. Fixes incorrect loaded-package status on images that share layers. If you built fix lists on 2.8 data, recheck them after upgrading.

### March 25, 2025: Quenchline 4.0
Our biggest agent release ever! Quenchline 4.0 is a rewrite of the loader around BTF and CO-RE, so one agent binary runs across kernels with no per-kernel builds. No more waiting on us after a node image update!
- **Breaking:** requires Linux 5.8 or later with BTF enabled
- **Breaking:** requires cgroup v2
- **Breaking:** `until` is now required on every policy exemption
- Agent exits with `btf_not_found` on unsupported kernels

Upgrade path: run `helm template` with your values and apply to one node pool first. Exemptions with no `until` will fail validation, so add dates before you upgrade the chart.

### April 22, 2025: Tallowatch 3.0
- Fix order rebuilt around exposure paths closed. The 0 to 100 risk score is gone, by popular demand!
- New Tallowatch graph engine: full recalculation is much faster on large estates
- Auto-fix private preview closed
- Support for Kubernetes 1.33 (preview)

### May 20, 2025: Quenchline 4.1
- Network isolation now keeps cluster DNS on request with `keepDNS`
- Hot reload of policy, with no agent restart
- Fixed: LSM hook attach failure on some hardened kernels

### June 17, 2025: Tallowatch 3.1
- Audit log streaming for faster cloud drift results
- Snooze for fix order items, with an expiry date
- Support for Kubernetes 1.33

### July 15, 2025: Quenchline 4.2
- Node drain containment action now requires `rbac.nodeDrain=true`
- New detection: first-time access to the cloud metadata endpoint
- Support for Kubernetes 1.33

Heads up: if you use node drain today, set the value before upgrading or drain actions will be refused for lack of RBAC.

### August 12, 2025: Tallowatch 3.2
- Custom YAML checks in the console
- Tallowatch check library now includes per-customer noise reporting
- Fixed: stale role bindings shown after cluster re-registration

### August 19, 2025: Quenchline 3.9.4
Final security patch for the 3.x line. Support for 3.x ended this month, on schedule. If you're still on 3.x, please move to 4.x now. Your account team can help plan node upgrades for kernels below 5.8.

### August 26, 2025: Quenchline 4.3
- Per-workload baselines for first-time network and file detections
- `egress-to-new-destination` detection, available for all customers
- Console: filter decision records by policy and mode

### September 2025: Slow Burn Summit release
Thanks to everyone who came out to Denver! Shipped alongside the event:
This was the most requested feature of the year, and it's finally here. One login, one timeline and one place to see runtime detections next to the configuration behind them.

- Unified console for Quenchline and Tallowatch customers on the Team and Scale plans
- Quenchline detections now show exposure paths through the pod
- Tallowatch fix order available per namespace for application teams

### October 21, 2025: Quenchline 4.4
- Support for Kubernetes 1.34
- Container-scope freeze via `cgroup.freeze`
- Fixed: drain timeout ignored when a PodDisruptionBudget blocked all evictions

### November 18, 2025: Tallowatch 3.3
- Webhook export for fix order, to feed your ticketing system
- Tallowatch collector memory reduced on clusters with many CRDs
- Fixed: Secret metadata view missing on aggregated ClusterRoles
- Support for Kubernetes 1.34

### December 9, 2025: Quenchline 4.5 and Tallowatch 3.3.1
- Last releases of the year. Happy holidays from all of us at Wickhold Security!
- Support for Kubernetes 1.35 preview in both agents
- Tallowatch: fixed CIS Benchmarks mapping for two control plane checks
- Quenchline: chart now validates `cluster.name` at install

### Where things stand at the end of 2025

| Product | Supported versions | Minimum kernel | Notes |
|---|---|---|---|
| Quenchline | 4.4, 4.5 | 5.8 with BTF | cgroup v2 required |
| Tallowatch collector | 3.2, 3.3 | n/a | Cloud collector is hosted and always current |

That's a wrap on 2025. Thank you for building with us, and see you in the new year!
