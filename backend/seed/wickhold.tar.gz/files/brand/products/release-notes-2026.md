# Release notes 2026

Newest first. Maintained by the release manager on the Wickhold product team. Product names follow the name in use on the date of the entry, so anything before March 2 says Tallowatch.

## Supported versions, as of October 2026

| Product | Supported | Requirements |
|---|---|---|
| Wickhold Quenchline | 5.3, 5.4 | Linux 5.8 or later with BTF, cgroup v2 |
| Wickhold Evenburn cluster collector | 3.8, 3.9 | Kubernetes API access. The cloud collector is hosted |
| Wickhold Leashgate, in early access | Latest build only | Enterprise tier, signed addendum |

Support covers the two most recent minor versions. Upgrades to any version need `helm upgrade` with your existing values unless the entry says otherwise.

## Deprecations in progress

| Item | Replacement | Ends |
|---|---|---|
| `/v1/tallowatch/` API paths | `/v1/evenburn/` | March 2, 2027 |
| `v1beta2` containment policy API | `v1` | Quenchline 6.0, date not set |
| Syslog over UDP for event export | Syslog over TLS or OTLP | Quenchline 6.0, date not set |

## October 13, 2026: Wickhold Quenchline 5.4

Quenchline 5.4 adds a per-policy dry run. `kubectl annotate containmentpolicy ledger-api quenchline.wickhold.example/dry-run=24h` runs a contain-mode policy in observe mode for the stated window, then returns it to contain mode. The change is recorded in the policy status so reviewers can see why no containment fired.

- Support for Kubernetes 1.37
- Reduced ring buffer drops on nodes running many short-lived CI jobs
- Fixed: `holdProbes` window ignored when a container had a gRPC liveness probe

Upgrade note: the chart now sets `priorityClassName: system-node-critical` by default. Customers with a resource quota in `wickhold-system` that restricts that class must update it before upgrading, or the DaemonSet rollout will stall.

## October 6, 2026: Quenchline 5.3.2

Patch release. Fixes a policy sync loop that raised control plane traffic on clusters with several thousand ContainmentPolicy objects. No customer-visible change in behavior apart from lower API load. Customers on 5.3 can skip this and take 5.4.

## September 30, 2026: final `wickhold/tallowatch` chart

The old chart stopped receiving releases today, as announced on March 2. Existing installs keep working but will fall out of support with the next Evenburn minor release. Metrics with the `tallowatch_` prefix are no longer emitted from Evenburn 3.9.1 on. Update any remaining dashboards and alert rules.

## September 29, 2026: Wickhold Evenburn 3.9

Evenburn 3.9 improves how exposure paths handle service meshes. Paths now account for mesh authorization policies, so a route the mesh denies no longer appears as open.

- Fix order can now be grouped by owning team, using a label the customer chooses
- New CIS Benchmarks profile for Kubernetes 1.36
- Fixed: drift false positive on fields defaulted by the API server after a version upgrade

Known limit: mesh awareness covers sidecar-based meshes in this release. Ambient-style meshes appear as if no mesh policy exists, so paths may be over-reported.

Upgrade note: the collector needs `get` on mesh authorization resources for this feature. The chart adds them to the ClusterRole, so customers who manage RBAC separately must add them by hand. Without that permission, paths are calculated as before and a console notice explains why.

## September 15, 2026: Slow Burn Summit release

Shipped during the summit in Denver, September 15–16.

- Quenchline: decision records now link to a replay of the process tree in the console
- Evenburn: new evidence report layout, with one PDF per control family
- Wickhold Leashgate, in early access: blast radius report now flags bypass routes through cluster DNS names, and approvals can be answered from Slack

Replay is the piece people asked about most at the summit. It shows the parent chain, the arguments as redacted by policy, and the containment action on one timeline, and it reads from the same retained events as the rest of the console.

## August 25, 2026: Leashgate early access build 0.6

Second schema migration of the early access. `spec.tools` is renamed `spec.rules`, with a conversion webhook that handles existing objects. The `v1alpha1` API version stays. Partners running the sidecar mode must restart agent pods so that the injected gateway matches the controller.

- Gateway decision records now include the argument names that failed validation, never the values
- Fixed: requireApproval timeouts returned a 500 in place of a structured refusal

## August 11, 2026: Quenchline 5.3

- Support for Kubernetes 1.36 on arm64 nodes with 64K pages
- New detection: unexpected `memfd_create` execution
- OTLP export now batches, with `export.otlp.batchSize` to tune it
- Fixed: agent reported `Ready` before LSM hooks were attached

## August 4, 2026: Leashgate early access build 0.5

- Blast radius report now reads Secret mounts as well as RBAC
- Shared gateway mode, as a Deployment in the namespace, joins sidecar mode
- Known issue: the shared gateway does not yet pass through human-user identity. Partners who rely on that should stay in sidecar mode

## July 21, 2026: Evenburn 3.8

- Exposure paths now include workload identity bindings across namespaces
- Ignore rules can carry an expiry date
- Cloud collector templates updated. Customers using customized read-only roles should compare theirs against the new template, since three read permissions were added

## July 7, 2026: Quenchline 5.2.1

Patch release. Fixes `keepDNS` on clusters where the DNS service uses a non-default ClusterIP range, and improves the error message when a pod's cgroup cannot be found during isolation.

## June 23, 2026: Leashgate early access build 0.4

First schema migration. Argument constraints moved under `rules[].arguments`. Policies need rewriting by hand in this one case, and partners have a migration note from their engineering contact.

- MCP proxy mode now supports multiple upstream servers per gateway
- Human-user identity can be passed through to policy evaluation
- Agent credential lifetime is configurable, default 15 minutes

## June 9, 2026: Quenchline 5.2

- Isolation refusals for `hostNetwork` pods now raise a console warning when the policy is created, in addition to the record at runtime
- `kubectl get containmentpolicies -o wide` shows mode and last action
- Fixed: event buffer could exceed its 1 GiB limit by one segment

## May 26, 2026: Evenburn 3.7

- Drift records now show the audit log actor when audit streaming is connected
- Custom checks can match on CRD fields
- Fixed: fix order patches generated the wrong JSON path for RoleBindings with a single subject

## May 2026: Leashgate early access build 0.3

Fix release for the first partners. Corrects sidecar injection on namespaces with restrictive pod security settings and adds a readiness gate so an agent pod does not start before its gateway.

## May 2026: Leashgate early access opens

Wickhold Leashgate is in early access from this release, build 0.2, for Enterprise customers who have signed the addendum. It provides runtime policy for AI agents and their tool calls: agent identity, tool-call policy and a blast radius report. See the product overview for scope.

Chart: `wickhold/leashgate`. API: `leashgate.wickhold.example/v1alpha1`. No SLA applies.

### Leashgate naming: early access label

Added by the release manager at Product Marketing's request, since release notes get quoted more than anything else we write.

Until general availability is announced, Leashgate is always labeled early access in external copy. The label applies to release notes, docs, web pages, emails, decks, event programs and social posts. Approved wording is "Wickhold Leashgate, in early access" on first mention and "Leashgate early access" or "Leashgate (early access)" after that. The short form "Leashgate" alone is fine in a sentence where the label has already appeared in the same paragraph.

Internal tickets, standups and Slack threads can drop the label. External copy cannot, including quotes from partners, which we ask them to word the same way.

Build numbers are not a status. A 1.0 tag, a stable chart channel or a customer in production does not change the Leashgate label. The early access label comes off when Product Marketing announces general availability, and not before.

## April 28, 2026: Evenburn 3.6

- Evenburn console pages now load the fix order from cache, with a freshness timestamp
- New evidence mapping for the PCI DSS 4.0 requirements
- Fixed: exposure path severity not updating after a tag change on an object store

## April 14, 2026: Quenchline 5.1

- Decision records now include the policy revision that fired
- `agent.redactArgs` patterns can be set per namespace
- New default exemption: node-local DNS caches in the isolation path

## March 2, 2026: Wickhold Tallowatch is now Wickhold Evenburn

Wickhold Tallowatch is renamed Wickhold Evenburn, starting with release 3.5. Nothing about the product, contract or data changes.

What customers need to do:

1. Update the chart reference from `wickhold/tallowatch` to `wickhold/evenburn`. The old chart keeps receiving releases until September 30, 2026.
2. Run `helm upgrade` with the existing values file. Values keys are unchanged.
3. Update dashboards and alerts. Metrics now use the `evenburn_` prefix, and the `tallowatch_` prefix is emitted alongside it until the old chart ends.

API paths under `/v1/tallowatch/` redirect to `/v1/evenburn/` for 12 months. Webhook payloads keep their field names, and the `source` field changes value on the same schedule as the chart.

Other changes in 3.5:

- Console and report covers carry the new name
- Fixed: benchmark report date range off by one day in some time zones

## March 2026: pricing

New Core and Team prices took effect this month. No product entitlement changed for existing contracts until renewal.

## February 24, 2026: Quenchline 5.0

- New policy API version `v1`. `v1beta2` objects are converted automatically and served until Quenchline 6.0
- Container runtime check at install now fails early with a clear message
- Support for Kubernetes 1.35

## February 10, 2026: console update

The console, docs site and Helm chart README carry the new Wickhold identity from today, including the Ember accent and new logo. No functional changes.

## February 3, 2026: Quenchline 4.6.1

Patch release. Fixes an isolation filter that was not cleaned up when a pod was deleted during a containment, which left a stale pinned map on the node until the agent restarted.

## January 27, 2026: Tallowatch 3.4

- Faster graph recalculation after single-resource changes
- Fixed: role templates missing a read permission for managed Kubernetes clusters
- Tallowatch collector now reports its own version drift against the control plane

## January 13, 2026: Quenchline 4.6

- New detection: kernel module load attempt from a container
- Agent logs moved to structured JSON
- Fixed: `kubectl get containmentdecisions` slow in namespaces with long history

Coming later this year: some changes to how we present the company and its products. Details soon.
