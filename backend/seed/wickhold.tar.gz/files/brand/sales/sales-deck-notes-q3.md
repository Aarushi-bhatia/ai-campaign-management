Q3 deck notes -- mine, sharing w/ team, pls don't forward to prospects

last touched end of Q3 2026. These sit alongside the deck, they're what I actually say on each slide. Marketing has the "official" talk track. This is what's working on calls.

---

**slide 1 - who we are**

Keep it 30 secs. Founded 2019 in Denver, two on-call infra leads who got sick of 3am. Series B, $46M, led by Marlbank Partners (June 2024). Around 150 people. Then the customer line: 300+ customers and growing. People nod at that and we move on. Don't dwell.

Tagline's on the slide. Small fires stay small. Let it sit, then shut up for a sec, it lands better than you'd think.

Some prospects remember us from the Tallowatch days. If someone says Tallowatch just say "that's Evenburn now, same product, new name" and keep going. Don't turn it into a rebrand story.

**slide 2 - the problem**

Two numbers. I always open with the old one bc it gets heads nodding: 68% of runtime incidents began with a misconfigured workload. Then the newer one: 41% of platform teams need more than six hours to contain a runtime incident. Then ask how long their last one took.

If they push on the source, the 41% is our Containment Report, 412 platform and security leaders, published April.

Good follow-up: median time to contain a runtime incident is 7.4 hours. Nobody ever knows their own number, which opens up the next ten mins.

**slide 3 - products**

- Quenchline: runtime detection + containment for K8s, eBPF agent. Isolate a pod's network, freeze a process, drain a node. Default containment policy, contain mode vs observe mode. EVERYONE asks if it's going to take down prod. Answer: start in observe mode, nothing gets touched until you say so.
- Evenburn: cloud + cluster posture. Drift, exposure paths, fix order. The fix order is the bit that sells. Security leads have 4,000 findings and no idea where to start.
- Leashgate: runtime policy for AI agents and their tool calls. EARLY ACCESS. Enterprise only. Don't promise dates, I got burned on this in July and had to walk it back. Product wants to talk to anyone with agents in production, so route them.

Quenchline line I use w/ platform people: under 2% CPU overhead on a typical node in Wickhold lab benchmarks, 2026. They will ask. Say it word for word or an SE will kick you under the table.

**slide 4 - proof**

Lowmoor Credit Union: time to contain went from 4 hours to 11 minutes, 220 nodes. Best one for finance.

Ostler Grocers: 63% fewer open critical misconfigurations in 90 days, 1,900 nodes. Best one for retail and for anyone with a big messy estate.

Vaskell Health: my go-to for healthcare. Audit preparation cut by three weeks. I've been using them as a reference on every healthcare call this quarter and it works great, compliance people perk right up. If they want a reference call ask their account owner, they've been pretty friendly.

Reminder 68% of runtime incidents began with a misconfigured workload is also a nice bridge into Evenburn on this slide, ties the misconfig story to Ostler.

**slide 5 - trust and compliance**

This slide decides enterprise deals.

- SOC 2 Type II, renewed Jan 2026. Report under NDA, send via the trust portal, don't email it.
- We're FedRAMP Authorized. Big door opener for public sector and anything touching federal money. Say it early on those calls.
- HIPAA and PCI DSS questions: route to the SE, don't wing it. Healthcare security questionnaires take us about a week if you get them to the SE on day one.

**slide 6 - pricing**

Annual billing. $24,000 annual minimum.
- Core: $18/node/month, Quenchline
- Team: $29/node/month, Quenchline + Evenburn
- Enterprise: all of it + Leashgate early access. Talk to sales (that's us). No figure in writing until there's a real scope.

Rough maths on the call helps. 500 nodes on Team is $174K a year. Say the number. Don't let them find it in procurement.

Most deals under about 300 nodes land on Core and add Evenburn at renewal. I've stopped pushing Team on the first deal if they haven't got a posture owner, as it just sits there unused.

**competitive quick hits** (battlecards are the real version, this is the short form)

- Brannoch Security: broad platform, heavy agent. Ask them to run both agents on a busy node and watch the numbers.
- Drennick Cloud: posture only. Great, and then who contains anything? We usually sit next to them, or Evenburn replaces them at renewal.
- Tesserline: detection only, huge rule library. Ask what happens at 3am after the alert fires.

Never trash them. Ask the question and let the prospect work it out.

**objections I keep getting**

"We already have a CNAPP." Fine. Does it contain, or does it open a ticket?

"Our platform team won't let another agent on the node." Offer a two-week observe-mode pilot on a non-prod cluster. Bring an SE. Share the lab overhead number with the label on it.

"We're not ready for automated response." Good. Nobody is on day one. Observe mode exists for that reason. Most teams turn on contain mode for one namespace first, then expand as they gain trust.

"What about AI agents?" Leashgate early access. It limits what a compromised agent can do. Do not get drawn into promising more than that. Security leads are skeptical on this topic anyway and a modest answer goes further.

**discovery, the five I actually ask**

1. What are you running? Cluster count, node count, managed Kubernetes or self-run, which kernels.
2. Who gets paged when a workload does something odd, and who has the authority to touch it?
3. Walk me through your last runtime incident. How long from alert to contained?
4. What's your posture tool today, and who reads its output?
5. Any AI agents running with real credentials? (Even if the answer's no, you'll learn who owns it.)

Q2 is the one people skip and it's the most useful. If security gets paged but only platform can touch the workload, you've found your deal. Containment needs both in the same room, so get both on the next call.

**CISO calls vs platform calls**

CISO: lead with the decision. "You need to decide whether containment is measured and who owns it." Then time and risk. Two slides. They've got 25 mins and four vendors this week.

Platform lead: skip slides, open a terminal. Show observe mode, then a seeded process, then contain mode. They'll ask what happens when the agent crashes. Good answer: the workload keeps running, you lose containment on that node until it restarts, and it shows up in the audit log. If you don't know something, say so and get the SE to follow up same day. Bluffing with these folks kills the deal.

**pilot rules of thumb**

- Two weeks, observe mode, one non-prod cluster, written success criteria before kickoff
- Max one pilot per SE at a time at end of quarter
- If they won't give us a named owner on their side, it's not a pilot, it's a free trial nobody will look at
- Readout meeting is on the calendar before the pilot starts

Week one is mostly finding out which kernels they really run vs what they told us. Old nodes come up every time. Ask about it early and save a week.

**deals that went sideways this quarter (anonymized, ask me)**

- Lost a 700-node deal to "no budget" and then saw they bought in Q4 of their FY. Should've asked about fiscal year on the first call.
- Pilot stalled bc security owned it and platform never installed the agent. Now I don't start without a platform name on the plan.
- Sent the deck PDF to a champion, it got forwarded to procurement without any of the voiceover, and they fixated on the appendix. Send the two-pager instead.

**renewals**

CSMs own these but we help. Evenburn add-ons at renewal were our easiest expansion this quarter. Ask how many nodes they've added since signing, as they've usually grown and nobody's trued up.

**process stuff**

- Log every call in the CRM same day, I'm serious, forecast is Thursdays.
- Demo environment gets reset Sunday night. Don't leave anything in there you need.
- For anything over 1,000 nodes bring the SE from the first call, not the third.
- Deal desk needs seven days for non-standard terms. End of quarter it's more like ten. Plan for it.
- Multi-year and volume terms go through deal desk, not through your own spreadsheet.
- Mutual NDA template is on the legal page. Don't redline it yourself.
- Slow Burn Summit passes for strategic accounts: ask me, there's a small pool held back. Field Day is open, just tell the events team who you're bringing.

**what's changed since Q2**

Dropped the "total cost of an incident" slide. Nobody believed our math and it invited a fight. Added the observe-mode rollout slide instead. Moved pricing to slide 6 from the appendix because people kept asking anyway, and hiding it wasted a meeting.

Also new rule from me, not official: if you can't explain what containment action would've fired in their last incident, you're not ready for the demo. Do your homework.

## Discounts in public copy

*Added by Legal (Priit), September 2026, after the renewal campaign draft.*

Never state discounts or promotional pricing in public copy. That covers the website, ads, email, social, event pages, booth signage, and anything a prospect can forward. No percent-off, no "first year free", no "limited-time offer", no end-of-quarter pricing, no multi-year savings figures. List prices for Core and Team are the only prices that go in public copy.

Discounts are negotiated by sales, approved by deal desk, and stay in the order form. If marketing asks you for a promo line for a campaign, send them to me.
