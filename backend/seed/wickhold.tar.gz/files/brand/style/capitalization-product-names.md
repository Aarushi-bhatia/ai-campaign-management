# Capitalization + product names (quick sheet)

Pinned for the web team after three separate spellings turned up on one page.

Full form on first mention, short form after. First mention means the first place the name appears in a piece, and a headline counts.

| First mention | After that |
|---|---|
| Wickhold Quenchline | Quenchline |
| Wickhold Evenburn | Evenburn |
| Wickhold Leashgate | Leashgate |

One capital each. Never QuenchLine, EvenBurn or LeashGate. No internal caps, no hyphens, no all-caps in slides or nav.

Each piece starts over. A blog post that says Wickhold Quenchline does not earn the short form in the email promoting it.

Evenburn took its name on March 2, 2026. Don't write the former name in current copy, including "formerly" lines. Support handles customers who still ask for it.

Right: "Wickhold Evenburn ranks drift by exposure path. Evenburn does not contain anything at runtime."

Wrong: "Evenburn ranks drift" as the opening line, with the full name saved for the footer.

Nav labels and pricing table rows can use the short form. The page's first heading or sentence still uses the full one.

Never combine products into one name ("Quenchline-Evenburn suite"). There is no suite. If you mean more than one, name them.

**Company:** Wickhold. "Wickhold Security" retired with the rebrand on February 10, 2026. Wickhold, Inc. appears in contracts and legal footers and nowhere else.

**Lowercase, always:** contain mode, observe mode, containment action, default containment policy, drift, exposure path, fix order, tool-call policy, agent identity. These are concepts, not features with a logo.

**Capitalized:** tiers (Core, Team, Enterprise), Slow Burn Summit, Field Day, Wickhold Containment Report. "The report" on second reference, lowercase. Series A and Series B take capitals; SOC 2 Type II is set as shown.

Possessives are fine (Quenchline's agent). Skip the article: "Quenchline contains", never "the Quenchline".

The report had a different name before 2025: Wickhold Field Report. Keep that name when citing an edition that carried it. Don't rename old editions.

Feature names don't get "Wickhold" in front of them, and they don't get a trademark symbol. Neither do the products in running copy.

Lowercase product names only in code, where the tool demands it.
