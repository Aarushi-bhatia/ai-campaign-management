---
title: Content style guide
version: 4
owner: Noor Eskelund
updated: 2026-07-09
---

# Content style guide

The house rules for how Wickhold copy is set on the page. Voice lives elsewhere. This is commas, numbers and headlines. Where a rule here seems fussy, it is usually because somebody spent an afternoon arguing about it and the team would rather not repeat that.

The first three sections are the ones reviewers send back most often.

## 1. Headlines

**Headlines are in sentence case.** Capitalize the first word and any proper noun. Everything else is lowercase.

This covers page titles, blog titles, section headings, email subject lines, slide titles, buttons, nav labels, form labels, table headers and any text set over an image. If it looks like a heading, it is one.

| Right | Wrong |
|---|---|
| What contain mode does to a running pod | What Contain Mode Does To A Running Pod |
| Wickhold Containment Report 2026 | WICKHOLD CONTAINMENT REPORT 2026 |
| How Ostler Grocers cut its open critical misconfigurations | How Ostler Grocers Cut Its Open Critical Misconfigurations |

Details:

- Product names, event names and the report title keep their capitals, as do Kubernetes, Helm, CVE and the rest of the proper vocabulary. `containerd` and `eBPF` keep their lowercase starts even as the first word, though it's nicer to rewrite so that neither opens a headline.
- The word after a colon is lowercase: "Drift: what it is and how to read it".
- No full stop on headlines. The tagline is the one exception, and it keeps its full stop everywhere.
- No code formatting in headlines. They break in email clients and in link previews.
- Keep a headline to one idea. If it needs a colon and a dash, it's two headlines.

The old sheet used Title Case for everything over 24px. That went in the rebrand, and pages still carrying it get fixed when someone next touches them.

## 2. First lines

**No rhetorical question as the first line of any asset.** Blog post, landing page hero, email (subject line and first sentence both), LinkedIn post, X post, video script, slide one of a deck.

"Is your cluster ready for the next incident?" tells the reader nothing and asks them to do the writer's work. It's also the most common opening in our category, so it reads as noise. Open on a fact, an event or a claim.

| Don't open with | Open with |
|---|---|
| What would you do if a pod started a shell at 3am? | A pod in `checkout` started a shell at 03:14 UTC. |
| Tired of alert fatigue? | Most alerts at 3am are about something that already stopped mattering. |

Real questions later in a piece are fine. An FAQ section is full of them and that's what it is for, as long as the page opens on a statement.

## 3. Citations

**Citations give the source name, the year and the link, in brackets, right after the claim.**

The shape, exactly:

```text
41% of platform teams need more than six hours to contain a runtime incident [Wickhold Containment Report, 2026, https://wickhold.example/containment-report].
```

- Source name in full, as the source spells it.
- Comma, year. Comma, link. The full stop for the sentence goes outside the bracket.
- Link goes to the report or page itself, not a press release about it and not a search result. In a PDF or on a slide print the link out, because hyperlinks do not survive a screenshot.
- Use the same form everywhere, including LinkedIn and X. Yes, it's long on X. Plan the post around it.
- Two sources for one claim: two brackets. Do not merge them.
- A source we did not produce gets its own name in the bracket, even when a Wickhold page quotes it. Cite the original.
- In long pieces (report summaries, the blog), mention the survey base once near the first figure: "a survey of 412 platform and security leaders".

We tried numbered footnotes on the blog through most of 2025 and dropped them. The claim got quoted on LinkedIn, the footnote stayed behind, and the number went around with no source. A bracket travels with the sentence.

Customer results don't take a bracket when the customer is named in the sentence and the case study is linked from the page. Naming them is the source.

## 4. Numbers

### Percentages

**Percentages use digits and the % symbol.** Always, including at the start of a sentence, in headlines, in legal-reviewed copy and in speech written for a stage.

- Right: 41% of platform teams, 63% fewer open critical misconfigurations.
- Wrong: forty-one percent, 41 percent, 41 per cent, 63pc.

No space before the symbol. "Percentage points" is written out when you mean the difference between two percentages, and it's rare enough in our copy that a reviewer will ask if you're sure.

### Everything else

- **Measurements take digits, always.** Anything with a unit: 220 nodes, 11 minutes, 7.4 hours, 90 days, 38 seconds, 1,900 nodes.
- **Counts of ordinary things** spell out one to nine and use digits from 10: "three clusters", "12 namespaces". Mixed in one sentence, go with digits.
- **Commas from 1,000 up.** No "1.9k nodes", not even on social.
- **Keep the decimal the source gave you.** 7.4 hours stays 7.4 hours. Don't round to "about seven hours", and don't add precision the source lacks.
- **Approved sentences stay as approved.** The report line says "more than six hours", spelled out, and that's how it runs in every piece. The same goes for "more than 140 customers", which never becomes "140+". Legal approved the sentence, and this guide doesn't get to tidy it.
- **Don't do arithmetic on claims.** Lowmoor went from 4 hours to 11 minutes. Do not convert that into a percentage or an "x times faster". The figures we can stand behind are the two figures we were given. Same for adding results from different customers together.
- **No "up to".** "Up to" numbers are a best case wearing a fact's clothes. Give the median, or say which run you mean.
- **No tildes or "approx."** in published copy. If a figure is an estimate, say "about".

### Money

- Dollars with the symbol: $18, $29. No ".00".
- Node pricing is written in full: "$18 per node per month". Not "/node/mo", not "per-node", not "$18 pnpm", which someone did actually write in a deck.
- Funding and other large sums use a capital M and no space: $46M. Don't write "$46 million" in one place and "$46M" in another; pick the M.

### Comparisons

"Faster than" needs a "than what". If the sentence compares to a named thing, that thing must be in the sentence. If it compares to a previous version of our own product, say which version.

## 5. Dates and times

- **Dates:** month, day, year, spelled out: April 14, 2026. No ordinals, no "14th of April".
- **Month and year:** March 2022, no comma. **Year only:** 2026.
- **Ranges:** an en dash with no spaces within a month: September 15–16. Use "to" across months: "March 30 to April 2".
- **Tables, logs, front matter:** ISO, 2026-04-14. Never slashes. 04/10 has already caused one wrong webinar invite, and that's enough.
- **Quarters:** fine internally. In public copy, name the month.
- **Avoid relative dates** in anything that stays online. "Recently", "last year", "this spring" and "soon" all rot. Write the date. Press releases and dated posts can say "today".
- **Roadmap language:** no dates, no "coming soon". Product marketing has a separate process for that.

**Times.** Incident timelines use 24-hour UTC with the zone on every line or at the top of the block: 03:14 UTC. It's how our readers' tools show it. Event and webinar times use 12-hour with the zone: 2:00 p.m. MT. In prose, "3am" with no space is fine as a phrase, and the voice document uses it constantly. It's a figure of speech and shouldn't be used for an actual appointment.

## 6. Grammar and punctuation

- **American spelling** in all copy, including copy going to UK and EU readers. Containerize, not containerise.
- **Oxford comma**, always. It has settled more than one argument in Kubernetes prose, where lists of nouns can double as lists of objects.
- **Active voice** with a named actor, wherever the actor is known. "Wickhold Quenchline drained the node." If the passive is hiding who did it and that person is us, it goes.
- **Tense.** Past for what happened, present for what the product does, and nothing in the future except where a date is public.
- **Contractions** are fine in the blog, on social and in email. Skip them on legal pages and in anything aimed at a board.
- **Colons** are our favorite punctuation mark and they're doing fine. Use them to introduce the fact.
- **Semicolons** at most once a page. If there are two, one wants to be a full stop.
- **Em dashes** rarely in body copy. Most are a full stop that lost its nerve. Spaced en dashes are not a substitute.
- **Parentheses** for the short aside only. If the aside matters, promote it to a sentence.
- **Quotation marks:** double, with commas and full stops inside, American style, except for literal strings in technical writing where the punctuation would change the meaning. Single quotes only inside double.
- **Italics:** titles of reports and the occasional stress only. They disappear on Soot grounds and in email.
- **Bold:** for scanning in long documents, once or twice per section. Bold on a landing page means the design isn't working.
- **Ampersands:** only in proper names. Plain "and" in headlines too.
- **"And/or"** is a legal term. Pick one.
- **Slashes** as a shortcut ("platform/security teams") get rewritten: "platform and security teams".

## 7. Lists

Bullets are for parallel things. If a list reads like an argument, it's a paragraph.

- Sentences in a list get full stops. Fragments don't. Don't mix them in one list.
- Keep the first word of every item in the same form: all verbs or all nouns.
- Numbered lists are for a real sequence: steps in a runbook, order of operations.
- Five items is usually the end of what a reader holds. A longer list wants grouping.
- Never write a list whose only job is to look thorough. Reviewers will count it.

## 8. Technical writing in marketing copy

Kofi Anselm's team reviews anything containing code, and their rules are short.

- **Code formatting** for commands, flags, file names, field names, namespaces, node names and anything a person might type: `kubectl get pods`, `--namespace`, `values.yaml`.
- **Every snippet is run before it's published.** Say which version it was run against. A snippet nobody ran does not go out, even in a slide.
- **Placeholder values** look like placeholders or like real workloads: `payments`, `checkout`, `worker-7`. Don't use `foo`, and don't use the name of a real company, a real customer or a celebrity.
- **Domains and email addresses in examples** use `wickhold.example`.
- **Long output** gets trimmed, with a line saying so. Don't silently edit output.
- **Failure modes** are part of the example. If a command fails in a common way, say how it looks.

### Terms we set one way

| Write | Not |
|---|---|
| Kubernetes | K8s, kube (fine in Slack, not in copy) |
| eBPF | EBPF, ebpf, e-BPF |
| containerd | Containerd, ContainerD |
| Helm, Helm chart | helm chart |
| pod, node, cluster, namespace | Pod, Node, Cluster, Namespace (unless it's the literal field or kind in code) |
| runtime (one word, all uses) | run-time, run time |
| on-call (adjective, plus the noun in our value "the next on-call"), on call (otherwise) | oncall |
| open source (noun), open-source (adjective) | opensource |
| cloud-native (adjective) | cloud native |
| tool call (noun), tool-call policy (adjective) | toolcall |
| AI agent | agentic AI, "AI worker", "digital employee" |
| CVE (uppercase, spell the ID in full: CVE-YYYY-NNNNN) | Cve, "a CVE" as a synonym for "an exploit" |
| CIS Benchmarks | CIS benchmarks |
| SOC 2 Type II (space, Roman numerals) | SOC2, SOC 2 Type 2 |
| PCI DSS | PCI-DSS |

Spell out an abbreviation on first use only if the reader might not know it. Platform engineers know what a CVE is. Board-level readers may need "time to contain" rather than an acronym we made up, and we don't use MTTC anywhere, because we'd then have to explain it.

**Security language.** Allowlist and denylist, not whitelist and blacklist. Primary and replica, not master and slave. If Kubernetes itself retains an old term in a literal field name, leave the field as it is.

## 9. People and companies

- Full name and title on first mention, in this order: Hana Brandvold, CISO, Lowmoor Credit Union.
- After that, surname for external people, in the press-release style: Brandvold said. First name for our founders only where they signed the piece.
- Job titles are capitalized in a byline or attribution line and lowercase in a sentence: "the company's head of developer relations".
- Companies are singular. "Wickhold is", "Ostler Grocers has".
- Use "they" for an unnamed person. "On-call lead", not "on-call guy". "Staffed", not "manned".
- Teams are lowercase: the platform team, the brand team.

## 10. Links

Link text names the thing the reader will get: "the 2026 Containment Report", "the Helm values reference". The surrounding sentence should still read correctly if the link is dead. Don't link a whole sentence. Internal pages open in the same tab.

UTM parameters come from the campaign tracker, not from memory. Marketing ops reject hand-typed ones.

## 11. Tables, charts and captions

- A table needs a header row and at least two rows of content. One row is a sentence.
- Right-align numbers in tables. Keep units in the header, not in each cell.
- A chart title states the finding in sentence case: "41% of platform teams need more than six hours to contain a runtime incident". The axis says what was measured.
- Every chart carries its citation in the same bracket form, set small under the chart, so it survives being cropped into a slide.
- Captions are sentences. They end with a full stop and they don't begin "Figure 1 shows".
- No 3D, no donuts, and no chart for a single number. Write the number.

## 12. Social and email formatting

- No emoji in brand posts or email. Founders can do as they like on their own accounts within reason.
- One link per post. Put it where it reads naturally; shortened links are for tracking and shouldn't appear as bare text where the full domain would fit.
- Line breaks on LinkedIn mark real paragraph breaks. No one-sentence-per-line posts.
- Greeting in email: "Hi Sam," with the first name and a comma, or no greeting for a broadcast. No "Dear". No "Hey there".
- Plain sign-off: name, job, company, or the team name on a broadcast. Nobody signs "Cheers" on a customer notice.
- In email, check that the piece reads correctly with images off.

## 13. Updating published pieces

Blog posts and pages get corrected in place. Add a line at the top: "Updated June 2, 2026: corrected the node count in the second section." Don't change the original publish date, and don't quietly fix a factual error. A typo can be fixed without a note. If the correction changes what the piece argues, Noor decides whether it stays up.

Old posts that use a previous product or company name stay as published until someone updates them for another reason. Don't run find-and-replace across the blog. It was done once in March, and it rewrote a quote.

## 14. Bylines and bios

- Blog bylines: full name and title. "By Kofi Anselm, Head of Developer Relations".
- A byline doesn't change the voice. Posts by staff are written like every other piece of company copy. Founder posts have their own treatment, covered in the voice document.
- Bios run one sentence and state a job. Not "passionate about", not "self-described", no hobbies unless the hobby is funny enough for Noor to let it through.
- Don't feature former staff in new pieces. If someone has left, their old byline stays on their old posts.

## 15. Usage notes

- **a/an:** go by sound. An eBPF agent, a SOC 2 report, an SRE.
- **back end** (noun), **back-end** (adjective).
- **cyber:** avoid as a prefix. Say what kind of security you mean.
- **data** is singular in our copy: "the data is".
- **drain:** a verb in Kubernetes and in our copy. "Drained the node."
- **e.g., i.e., etc.:** write "for example", "that is", or finish the list.
- **email:** no hyphen.
- **failover** (noun), **fail over** (verb).
- **in order to:** "to".
- **log in** (verb), **login** (noun). Same pattern for **set up / setup**, **roll out / rollout**, **shut down / shutdown**.
- **real time** (noun), **real-time** (adjective).
- **sidecar, service mesh:** lowercase, one and two words.
- **startup:** one word.
- **third party** (noun), **third-party** (adjective).
- **trade-off:** hyphenated.
- **utilize:** "use".
- **very, really, extremely:** delete and reread.
- **via:** "through", unless it's a technical path.
- **zero-day:** hyphenated, and only for an actual zero-day.

## 16. Headlines that get sent back

A short list from the last year of review comments, so you can save yourself the round trip.

- "The ultimate guide to" anything. It won't be.
- "X things every platform engineer should know". They know.
- "Why containment matters". Say what it changes.
- "Introducing". The reader can see that it's new. Say what it does.
- Any headline that would also fit a competitor's blog. Swap their name into your mental picture and check.

## 17. Accepted shortcuts and exceptions

- Internal documents (including this one) don't need to meet the citation form. They do need to be right.
- Slide speaker notes follow the same rules once they go into a shared deck, since decks get forwarded.
- Quoted customer language stays as approved, including its capitalization. If a quote has a problem, go back to the customer through the customer marketing owner; don't fix it in place.
- Text inside a screenshot is not edited. If a screenshot shows something out of date, take a new one.

## Changes

- **v4, July 2026.** Citation form restated after a run of pieces shipped with no year. Time formats added after the draft summit schedule mixed three of them.
- **v3.2, March 2026.** Product name sheet split out for the web team.
- **v3, February 2026.** Rewritten for the rebrand. Title Case removed. Oxford comma confirmed, again.
- **v2, 2024.** Footnotes adopted for the blog. They didn't last.

Questions: #brand-review. For anything about what a claim may say, ask legal, not this page.
