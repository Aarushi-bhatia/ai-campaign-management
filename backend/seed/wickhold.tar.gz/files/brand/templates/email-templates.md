# Email templates

Lifecycle marketing's working file. Copy a template into the sending platform and fill in the merge fields. `{{first_name}}` falls back to "there" in the platform, so nothing needs handling on your side. Rows marked with an owner mean that person reviews changes.

Last cleanup: September 2026, after the Summit sends.

## CTA format for all channels

This lives here because the email team wrote it down first, and it now applies to every channel: email, landing pages, paid, social, the blog, event pages.

A CTA, the call to action on a button or a link, is at most four words, and it starts with a verb. The same CTA wording rules apply wherever the button sits. "Learn more" and "Click here" are banned everywhere, including as link text inside a sentence.

| Fine | Not fine |
|---|---|
| Read the report | Learn more |
| Book a demo | Click here |
| See the rollout guide | Click here to see the rollout guide |
| Request early access | Early access request |
| Save your seat | Your seat is waiting for you |

Say what happens on the other side of the click. "Get started" is allowed but weak, so use something more specific if you can.

## Email preheader

Every email has a preheader of at most 90 characters. It shows beside or under the subject line in most inboxes, so treat it as the second half of the subject. It must add something. Don't repeat the subject, and don't leave the field empty, or the client will fill it with the first text in the email, which for us is often the "view in browser" line.

Good: `Survey of 412 platform and security leaders on what happens after detection.`

Bad: `Containment Report 2026 is out. Read the Containment Report 2026 today.`

## Older notes

From the nurture rebuild, September 2025:

- Emails can run to 250 words when there's a code sample or a step list, since those read faster than prose.
- Keep the button above the fold on desktop. On long sends, repeat it at the end.
- Don't send anything from a `noreply` address. Replies are how we find out about bad lists.

---

## T1. Report announcement

Owner: lifecycle. Audience: all opted-in prospects.

**Subject:** Containment Report 2026 is out
**Preheader:** Survey of 412 platform and security leaders on what happens after detection.

Hi {{first_name}},

The Wickhold Containment Report 2026 is out. We surveyed 412 platform and security leaders about what happens after a runtime alert fires.

The headline finding: 41% of platform teams need more than six hours to contain a runtime incident [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]. The median time to contain a runtime incident is 7.4 hours [Wickhold Containment Report, 2026, https://wickhold.example/containment-report].

The report covers how teams measure containment, who holds the authority to act on a workload, and where the hours go.

**[Read the report]**

The Wickhold team

## T2. Product update

Owner: lifecycle, with the product manager for the release. Customers first, prospects one day later.

**Subject:** Wickhold Quenchline {{month}} release notes
**Preheader:** What changed, what you need to do, and what stays the same.

Hi {{first_name}},

The {{month}} release of Wickhold Quenchline is rolling out to customers this week.

What changed:

- {{change_1}}
- {{change_2}}
- {{change_3}}

What you need to do: {{action_or_"Nothing. The agent updates on your normal schedule."}}

If you run contain mode with a custom default containment policy, read the upgrade notes before you roll this out to production clusters.

**[See the release notes]**

The Wickhold team

## T3. Slow Burn Summit invite

Owner: events. Goes out in June, with a reminder in August.

**Subject:** Slow Burn Summit: save your seat
**Preheader:** Two days in Denver with people who carry the pager. Customer talks and working sessions.

Hi {{first_name}},

Slow Burn Summit is back in Denver this September, on {{dates}}.

It's our customer conference, and it runs on working sessions. Platform teams walk through real rollouts and real containment actions, and our engineers take questions on the roadmap.

Bring someone from your on-call rotation. {{customer_seat_line}}

**[Save your seat]**

The Wickhold team

## T4. Field Day invite

Owner: events. Sent about four weeks ahead to customers and active prospects within driving distance.

**Subject:** Field Day in {{city}} on {{date}}
**Preheader:** An afternoon with other platform teams, a live containment session and an early dinner.

Hi {{first_name}},

We're bringing Field Day to {{city}} on {{date}}. It's a small meetup: about thirty people, a live containment session on a test cluster, and an early dinner.

There's no pitch, and laptops are welcome. Our engineers will be there, so bring the question you've been saving.

**[Save your seat]**

{{host_first_name}}, Wickhold

## T5. Newsletter shell

Owner: Kofi. Second Tuesday of each month.

**Subject:** {{lead_item_in_plain_words}}
**Preheader:** {{second_item_in_plain_words}}

**Lead item.** 60 to 80 words, one link.

**Also this month.** Three items, 25 words each, one link each. Usually a release, a blog post and a command.

**One command.** Something useful, in a code block, with what it shows. Example:

```bash
kubectl get events -A --field-selector type=Warning --sort-by=.lastTimestamp
```

Warning events across all namespaces, oldest first, so the newest sit at the bottom.

Kofi at Wickhold

## T6. Nurture, platform track, first email

Owner: lifecycle. Trigger: report download by a contact tagged platform.

**Subject:** A first namespace in contain mode
**Preheader:** Start in observe mode on one namespace. The guide takes about an hour.

Hi {{first_name}},

You read the Containment Report, so here's the practical follow-up.

Our rollout guide starts Wickhold Quenchline in observe mode on one namespace. After two to four weeks you'll see what it would have done. Then you move that namespace to contain mode, with one containment action turned on.

Most of the guide is flags and failure modes. It also covers what to do if the agent can't attach on an old kernel.

**[See the rollout guide]**

The Wickhold team

## T7. Nurture, CISO track, first email

Owner: lifecycle. Trigger: report download by a contact tagged security leadership.

**Subject:** A question for your next board update
**Preheader:** The median time to contain a runtime incident is 7.4 hours.

Hi {{first_name}},

The decision for you is whether your team measures how long it takes to contain a runtime incident, and who owns that number. You will be asked for it. In our survey of 412 platform and security leaders, the median time to contain a runtime incident is 7.4 hours [Wickhold Containment Report, 2026, https://wickhold.example/containment-report].

The report sets out how other teams track it and report it upward.

**[Read the report]**

The Wickhold team

## T8. Leashgate early access invite

Owner: lifecycle, with product. Sent only to accounts product has approved.

**Subject:** Wickhold Leashgate, in early access
**Preheader:** Tool-call policy for AI agents, in early access for a limited group of teams.

Hi {{first_name}},

Your team is running AI agents with access to real tools, so you may want to look at Wickhold Leashgate, in early access.

Leashgate (early access) sets tool-call policy at runtime and gives each agent an identity. If an agent is compromised, the policy limits what a compromised agent can do. It keeps the blast radius of an agent to what you've allowed.

Early access means you work directly with our engineers and the product will change while you use it.

**[Request early access]**

{{account_owner_first_name}}, Wickhold

## T8a. Demo follow-up

Owner: sales development. Sent by the rep the day after a demo, edited by hand. This one must not go out unedited.

**Subject:** Notes from {{demo_day}}'s demo
**Preheader:** What we showed, what you asked, and the next step we agreed on.

Hi {{first_name}},

Thanks for the time on {{demo_day}}. Here's what we covered and where we landed.

You asked about {{question_1}}. {{one_line_answer_with_link}}

Next step: {{agreed_step}}, owned by {{owner}}, by {{date}}.

If a two-week observe-mode pilot still makes sense, we'll set it up with one of our solutions engineers.

**[Book a pilot call]**

{{rep_first_name}}, Wickhold

## T8b. Field Day follow-up

Owner: the Field Day host. Plain text, within two days of the event.

**Subject:** What we showed at Field Day {{city}}
**Preheader:** The commands from the live session, and the answer to the question we ran out of time on.

Hi {{first_name}},

Thanks for coming on {{date}}. The commands from the live session are on the page below, with the seeded incident if you want to run it yourself.

We ran out of time on {{open_question}}. {{short_answer}}

**[See the session notes]**

{{host_first_name}}, Wickhold

## T8c. Renewal notice

Owner: customer success. Sent 90 days before the renewal date, from the account's CSM.

**Subject:** Your Wickhold renewal on {{renewal_date}}
**Preheader:** Your current plan and node count, and who to talk to about changes.

Hi {{first_name}},

Your Wickhold subscription renews on {{renewal_date}}.

Current plan: {{tier}}. Nodes on contract: {{node_count}}.

If your node count has changed, or you'd like to look at adding Wickhold Evenburn, reply here and we'll go through it together. Otherwise there's nothing you need to do yet.

**[Review your plan]**

{{csm_first_name}}, Wickhold

## T8d. Deprecation notice

Owner: product. At least 60 days ahead of the change.

**Subject:** {{feature}} ends on {{date}}
**Preheader:** What's changing, who is affected and how to move before then.

Hi {{first_name}},

On {{date}} we're removing {{feature}} from {{product}}.

**Who is affected.** Clusters running {{condition}}.

**What to do.** {{numbered_steps}}

**What happens if you don't.** {{plain_failure_mode}}

Reply to this email if the date doesn't work for your change window, and we'll talk.

**[Read the migration guide]**

The Wickhold team

## T9. Customer security notice

Owner: Dov. Marketing edits for clarity only. No template variations and no cross-promotion.

**Subject:** CVE note: {{short_component_name}}
**Preheader:** What happened, what we've checked, and what to do next.

Hi {{first_name}},

**What happened.** {{CVE_id}} was published on {{date}}. It affects {{component}}.

**What we've checked.** {{facts_about_Wickhold_products}}

**What to do.** {{numbered_steps_with_commands}}

We'll update this notice if anything changes. If you need help, reply to this email and it will reach the on-call engineer.

Dov Achterberg
CTO, Wickhold

## T10. Founder note

Owner: Maren. She writes it. This shell only gives the mail merge something to hold.

**Subject:** {{Maren's subject, in plain words}}
**Preheader:** {{one line from the note}}

{{first_name}},

{{body, first person, under 200 words}}

Maren

## Retired

The "abandoned demo form" reminder went away in January 2026 because it felt like surveillance. The "We miss you" re-engagement email is also gone, and the replacement is one plain note asking whether to keep sending, with a single "Stay subscribed" button.
