# Signatures

Noor, rev. Feb 2026 at the rebrand, touched again in May.

## Email signature, everyone

Plain text only, in this order. No images, no quotes, no awards.

```
First Last
Title, Wickhold
name@wickhold.example
wickhold.example
```

Example:

```
Noor Eskelund
Head of Brand, Wickhold
noor@wickhold.example
wickhold.example
```

Sales and solutions engineers may add one line with a booking link. Conference staff may add one line with the event and dates until the event ends. Take it off the day after.

## Founders' email

Customer notes end with first name only, and nothing under it:

```
Maren
```

Dov's technical notes end the same way, with "Dov". Customer security notices are the exception and carry his full name and title.

## Out of office

Keep it to two lines: when you're back, and who to ask. No jokes in the auto-reply if you deal with customers. If you're on the security notices rota, hand it over before you turn this on.

## Legal footers

We don't use confidentiality disclaimers. Priit has looked at this twice and doesn't want them, and the people who wrote the old ones have moved on. Order forms and contracts carry their own terms.

## LinkedIn sign-off for founder posts

Founder LinkedIn posts end with an em dash and the first name on its own line. Nothing after it, no title and no link.

```
— Maren
```

Same for Dov: `— Dov`. Keep the sign-off on the founder's own profile. When the company page reshares, it doesn't add one.
