# Visual rules common to every image

Owner: Noor Eskelund, Head of Brand. Last edited September 2026, after the Slow Burn Summit push showed us how many people pick images without opening the metadata.

These rules apply to every image Wickhold publishes: a blog hero, a chart in a white paper, a slide a sales engineer drops into a customer call, a banner at a Field Day. If you are holding an image and wondering whether this page applies, it does.

## How the visual rules are layered

Three layers, read in this order.

1. **This page.** Applies to everything.
2. **The category.** What kind of image is it? Photo, illustration, icon, logo, product screenshot, chart, social graphic, event graphic, legal and trust imagery, anything showing a person.
3. **The content type.** Where is it going? Blog hero, LinkedIn, X, email header, landing page.

Most images touch one rule from each layer, and some touch two categories. A photo of a staff member at a customer site is photography and consent at once, and it has to pass both.

A lower layer can narrow a higher one. The illustration category accepts several formats, for example, and the blog hero page accepts fewer of them. In that case follow the narrower rule for that placement, and the broader rule stays true everywhere else. A lower layer cannot loosen this page. If a content-type page seems to let you do something this page forbids, bring it to Brand, because one of the two pages is wrong and we want to fix it.

Per-campaign exceptions go through Noor's exception log. Without an entry there, if a campaign needs something new, the rule changes for everybody or the campaign changes.

## The two rules that come up every week

### No generated text in any image

No image contains text produced by an image model or baked into artwork by a tool that does not treat it as live type. Models misspell product names, invent letterforms and produce near-English that survives one quick look and then gets screenshotted by a customer. We had a test hero in spring where a wall sign read almost like "Quenchline". Nobody caught it until it was in a review deck.

Text in a Wickhold image is set by a person, in the design tool, in the brand typefaces, as a separate layer over finished art. That covers overlays, labels, chart annotations and callouts.

Three things do not count as generated text:

- Words that are really in the scene: a printed rack label, a whiteboard someone wrote on, a door sign. Check that they say nothing embarrassing and name nobody outside the company.
- Real interface text in a true product screenshot.
- The wordmark, which is a vector file, placed by a person.

Some placements allow no overlay at all and others cap it. The content-type page has the number.

### One focal point

Every image has one focal point. A reader should be able to say what the image is of after a second's look. If two things compete, crop or pick another image.

Tests we use in review:

- Squint at it. One shape or area should hold.
- Shrink it to a thumbnail. Something should still be identifiable.
- Describe it in one short sentence without "and". "An engineer reading a terminal in a dark room" passes. "A team at a table and a wall of monitors and a logo on the door" does not.

Collages, split screens and before-and-after pairs fail this unless they are charts, where the comparison is the single point.

## Other rules for all images

**Current identity only.** Ember `#C2501F`, Soot `#15181C`, Tallow `#F4EFE6`, with Whetstone `#5E6B73` and Verdigris `#2F8F83` as secondary colors. Bricolage Grotesque, IBM Plex Sans and IBM Plex Mono for any type on an image. Anything leaning on the 2024 blue palette or the 2024 logo is out, however good it looks. Some of those images are still in the library with no flag on them, so your eye is part of this check.

**No third-party marks.** No real product logos on laptop lids, no cloud provider marks on diagrams, no conference logos in a crop unless the agreement with that organizer allows it. Customer marks are a legal matter and go through Legal first.

**No watermarks,** no preview overlays, no leftover crop marks. If an image arrived with a watermark, its rights are not what you think they are.

**Do not stretch, tint or recolor library files.** Crop freely within the category's limits. Stretching breaks the proportions of the art and recoloring breaks the palette. Filters are out too: the warm look comes from the source image, and a filter laid on a cool image only makes it look cool and filtered. If an image needs a color change to fit, it is the wrong image.

**Export for the placement.** WebP or PNG for web, PNG where transparency matters, SVG for logos and icons when the placement accepts it. Keep web images under 400 KB unless the content-type page says otherwise. JPEG artifacts around Ember shapes are very visible, so check flat illustration at full size after compressing.

**Nothing that frightens.** Images follow the same stance as the copy. Show the small fire or the calm room, and skip the alarm. Red alert screens, countdown timers, sirens and skulls have no place here, even as a joke in an engineering post.

## The image library and its metadata

Every approved image lives in the image library, and every image in it has a metadata record. Do not pick from the thumbnail grid and stop there. The thumbnail does not show you the limits on the image.

| Field | What it tells you |
|---|---|
| `id`, `filename` | Identity. Filenames were set by different people across several years and tell you little. |
| `type`, `title` | Rough category and a human label. |
| `description` | What is in the picture. Often thin, sometimes empty. |
| `tags` | Search help. Inconsistent, so never treat a missing tag as meaning anything. |
| `usage_rights` | The grant we hold for the file. |
| `restrictions` | The limits on this particular image. See below. |
| `added_date` | When it entered the library, which is not when it was made. |
| `source`, `attribution` | Where it came from. In-house work reads `internal-production`, and `attribution` is usually empty or names the in-house team. Empty attribution means no credit line is needed. |
| `width`, `height` | Pixel size. Check before you plan a crop. |
| `background` | How the image relates to what sits behind it. See below. |
| `safe_on` | Which grounds it can sit on. See below. |
| `variant_of` | Points at the parent when the image is one version of another. |

### `restrictions`: check it before every use

Read `restrictions` before you use an image, every time, including images you have used before. Restrictions are added after an image enters the library, so last quarter's check does not count.

The field is free text, written by whoever had the reason. There is no fixed vocabulary, so read the sentence instead of searching for a keyword. Three kinds of note turn up in practice:

- **Retirement.** The image is deprecated and must not be used. Some retired files look entirely normal in the grid and carry no other sign. Their tags and titles may even look current.
- **A limited context.** The image may be used in the named context and nowhere else. A note limiting an image to internal use keeps it out of anything a customer, a prospect or the press will see, and that includes sales decks.
- **A person or place.** Something about who or what is shown has changed.

A restriction binds even when the image would be perfect, when a senior person asks for it, and when you found it already published somewhere. If you think one is out of date, ask Brand to change the record. Do not use the image and sort it out later.

An empty `restrictions` field means nobody has recorded a limit. It does not mean the image is on brand. The field is one check among several, and the current-identity rule above still has to pass on your own judgment.

If `restrictions` and `tags` seem to disagree, `restrictions` wins. If `restrictions` and `description` disagree, stop and ask.

### `background`

Three values.

- `transparent`: no ground at all. The image takes on whatever is behind it, which is why `safe_on` matters so much for these files.
- `solid`: a flat ground is part of the file, such as a logo on its panel or a hero illustration on Tallow.
- `scene`: the image has its own environment, as every photograph does. You never cut a scene out of its background, and we do not mask people or equipment out of photos.

A file marked `transparent` should be previewed on the actual ground before it ships. A bright fringe can look fine on one ground and show on another.

### `safe_on`

Three values, each describing the ground the image is designed to sit on.

- `light`: Tallow and other pale grounds only.
- `dark`: Soot and other deep grounds only.
- `any`: holds up on both.

Treat `safe_on` as a limit, the same way you treat `restrictions`. A `light` image on a dark layout is a defect even if you can still more or less see it. The layout's ground is what matters: a dark band halfway down a light page is a dark ground. When an image sits on a photo, or on Ember or Whetstone, neither word applies directly. Use a `solid` version, or test it and show Brand.

### `variant_of`

If the record points to a parent, or other records point at this one, you have siblings. Look at them before you decide the image does not work. The version for your ground often already exists.

## Picking an image: the order

1. Decide the category and read that page.
2. Decide the content type and read that page.
3. Search the library. Search by description and by a few different words, since tags are uneven.
4. Open the record. Read `restrictions` and `usage_rights` first, then `background`, `safe_on` and size.
5. Look at the picture itself at full size against the current identity. Metadata does not catch everything.
6. Check it against the rest of the layout, on the real ground.
7. Add it to the draft with its `id` noted in the review comment, so Brand can trace it.

## Three picks, worked through

**A blog post on draining nodes before an upgrade.** The writer finds a warm photo of a rack door. The title and tags look right and `restrictions` is empty. At full size, the photo is clean and it passes. It needs a crop, so the writer checks `width` and `height` first and confirms the focal point stays in frame.

**A dark section on a pricing comparison page.** The designer drops in a spot illustration that looked good on the last page. The record says `background: transparent` and `safe_on: light`, so it fails on this band. The record has no `variant_of`, but another record points at it as a parent, and that sibling is `safe_on: dark`. Problem solved in two minutes.

**A customer webinar invitation.** The perfect team photo has a line in `restrictions` that the writer almost skipped, because the thumbnail looked fine and the image had been used on the website last year. The line changes the answer. The image stays out, whatever last year's page did, and the writer picks again.

## Asking for something new

If the library has nothing suitable, do not borrow from the web, do not pull an image from a past deck, and do not take it from a teammate's desktop. Files outside the library have no record and nobody can check their rights.

Requests go to the brand designers through the design queue with the placement, the deadline and one sentence on what the image should show. Allow five working days for illustration and more for photography that needs a shoot. Anything made for you gets a metadata record before it ships.

## Review

Brand reviews every new image and every first use of a library image in paid, press and homepage work. Anything else can ship on the owner's own check against this page, and Brand samples it monthly. Pull anything that fails the sample, even if it has already gone out.

Legal review is separate. It looks at claims, customer marks and consent. A pass from Legal is not a pass from Brand, and the other way around.
