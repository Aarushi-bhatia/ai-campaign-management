# Image accessibility

Web lead's notes, cleaned up by Brand in May 2026 after the customer procurement questionnaire asked us about this and we had no document to point to.

## Alt text on every image

Every image has alt text. This covers blog images, email images, landing pages, social uploads where the platform offers the field, and images in PDFs. The author of the piece writes it, because the designer usually does not know why the image is there.

Write what the reader would lose if the image failed to load. One or two plain sentences, under about 125 characters when you can manage it. Skip "image of" and "picture of". Do not stuff keywords. Do not paste the `description` field from the library: that describes the file, and alt text describes what the image is doing in this piece.

| Image | Bad | Good |
|---|---|---|
| Photo | "Engineer, Kubernetes, security, on-call, data center" | "An engineer reads a terminal in a dim equipment room." |
| Product screenshot | "Screenshot of dashboard" | "Quenchline shows one pod isolated, with network access removed and the process frozen." |
| Chart | "Bar chart" | "Median time to contain a runtime incident is 7.4 hours. Wickhold Containment Report 2026." |
| Logo | "logo.png" | "Wickhold logo" |
| Illustration | "Decorative graphic" | "A cut-paper wick with a single small Ember flame." |

Charts and screenshots carry the finding in the alt text, and the reader should not need the picture to get the number. If the chart has more than about four values, put the values in a table or the body copy under it and let the alt text state the point.

Any text set on an image must also appear in the alt text or the surrounding copy. Screen readers cannot read a stat card.

The "every image" part holds for decorative images too. If an image truly adds nothing, the first question is why it is in the piece. Background textures set in CSS are not images for this purpose and need no alt.

## Contrast: 4.5:1 for text

Text on any image or graphic meets at least 4.5:1 against what is directly behind it. We apply the same floor to all sizes, including large headlines. A designer will point out that the web standard relaxes for large type. We know. The single number is easier to check, and a stat card shrinks to thumbnail size in a feed, where large type stops being large. This floor governs images. Layouts follow the logo and color addendum.

Measured ratios for the palette:

| Pair | Ratio | Text allowed? |
|---|---|---|
| Soot on Tallow | 15.5:1 | Yes |
| Tallow on Soot | 15.5:1 | Yes |
| Whetstone on Tallow | 4.8:1 | Yes |
| Verdigris on Soot | 4.5:1 | Yes, just. Test your export |
| Ember on Tallow | 4.1:1 | No |
| Soot on Ember | 3.8:1 | No |
| Ember on Soot | 3.8:1 | No |
| Tallow on Ember | 4.1:1 | No |
| Verdigris on Tallow | 3.4:1 | No |
| Whetstone on Soot | 3.2:1 | No |

This surprises people: Ember does not carry text on our grounds, and no text sits on Ember in an image. Ember is for shapes, rules and the focal element. Headlines on Tallow are Soot. Headlines on Soot are Tallow.

Over a photo, measure against the lightest spot behind the letters for Tallow text and the darkest spot for Soot text. An even-looking dark photo often has one bright lamp right under the word. If the text fails anywhere, put it on a solid Soot or Tallow panel. Do not add a gradient scrim: our illustration and graphic language has no gradients, and scrims tend to fail at their edges anyway.

## Color alone

Do not use color as the only signal. Ember and Verdigris are close in lightness and can merge for a reader with red-green color blindness. Label things directly.

## Motion

Looping GIFs stop after three loops, or ship as static. Nothing flashes more than three times a second. A product demo clip on a landing page has a pause control and does not autoplay with sound.

## Checks before publishing

- Alt text present and written for this placement
- Text on image measured, with the worst spot checked
- Image still makes sense at 320px wide
- Meaning does not depend on color alone
