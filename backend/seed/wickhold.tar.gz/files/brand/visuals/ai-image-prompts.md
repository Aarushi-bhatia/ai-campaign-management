# AI image prompts

Maintained by the brand designers. Updated August 2026.

We use an image model for scene photography, illustration and abstract backgrounds. Every prompt is built from three parts, in this order, with nothing else added:

**shared style prompt + the category system prompt + one subject line**

Keep the subject line to one sentence. Longer subject lines drift off style, and we tested that at length in June. When the category uses reference images, attach the current approved style references from the design queue. Do not attach anything from the old brand, even as a "not like this" example.

## What is never generated

| Category | How it is made |
|---|---|
| Logos | Hand-built vector files. Models misspell and redraw them |
| Icons | Hand-drawn on the icon grid |
| Product screenshots | Real product, or an HTML render from the demo environment, captured with Playwright |
| Charts | Built from the data |
| Social templates | HTML and Playwright |

If a scene needs a logo on a wall or a shirt, generate the scene blank and composite the vector afterwards.

## Shared style prompt

Paste this first, every time.

```text
You are producing an image for the visual library of a Kubernetes runtime
security company. Calm, specific, grown-up. The image has one clear subject and
plenty of quiet space. Warm palette anchored in burnt orange (#C2501F), near
black (#15181C) and warm off-white (#F4EFE6), with slate gray (#5E6B73) and
muted teal (#2F8F83) only in small amounts. No cool blue color cast.

The image contains no text of any kind: no letters, numerals, signage, screen
text, captions or labels. It contains no logos, no watermarks, no real brands
or products, and no likeness of any real person.
```

## Category system prompts

### Photography

```text
Documentary photograph taken in available light. A working room or real
infrastructure: an equipment room, a cable tray, a small office late in the
day, a kitchen table with a laptop during an on-call shift. Warm and slightly
underexposed, natural grain, shallow but believable depth of field. People, if
any, are mid-task, not posing, and not looking at the camera. They are ordinary
working adults with real skin texture, visible pores and lines, uneven skin
tone, flyaway hair, natural facial asymmetry and creased everyday clothes. It
should look like a real photograph a colleague could have taken, shot like a
35mm film photograph at eye level: unposed and slightly imperfect, with no
glamorization, no heavy retouching, no cinematic lighting and no dramatic color
grading. No symbolic security objects. Screens are angled away or dark. Landscape 3:2 unless the
subject line says portrait.
```

### Hero illustration

```text
Flat cut-paper illustration. Layered matte paper shapes with crisp hand-cut
edges and a hard flat shadow in a single darker tone. One burnt-orange focal
element. The ground is warm off-white or near black, as the subject line
states. No gradients, no glow, no soft shadow, no outlines, no 3D. Wide 3:2
composition with the focal element off center and room around it.
```

### Spot illustration

```text
Single flat cut-paper object on a fully transparent background. Square format,
centered, with an even margin. One burnt-orange focal element and at most one
secondary color. No ground plane, no cast shadow beyond the paper shape, no
gradients. Do not draw a checkerboard or any pattern to represent transparency.
```

### Abstract background

```text
Wide, low-detail background made of overlapping flat paper planes in near black
or warm off-white. Very low contrast between planes. No focal object, since
live type will be set on top of this later. No gradients and no glow.
```

### Legal and trust illustration

```text
Flat cut-paper illustration of an everyday record-keeping object, such as a
stack of pages, a ledger or a folder tied with string. One burnt-orange focal
element on warm off-white. Quiet and plain. No people or faces, no shields, no
seals, no stamps that resemble a certification mark, no checkmark badges.
```

### Event and social background plate

```text
Plain environmental background for a composited layout: a warm wall, a paper
texture, a dim room out of focus. Leave the left half of the frame empty for
type to be added later in design. No subject that competes with the layout.
```

## Subject lines

Good:

- `A coil of unlit wick beside one lit match on a steel tray`
- `An engineer's hands on a laptop in a dim equipment room at night`

Bad, and why:

- `A secure cloud protecting businesses from cyber attacks`: a concept with nothing to draw, so the model reaches for clichés
- `A dashboard showing Quenchline results`: this is not a generated category, and it asks for text
- `The CEO at a whiteboard`: a real person's likeness

## A full prompt, assembled

For a hero illustration the request to the model reads, top to bottom: the shared style prompt, the hero illustration prompt, then this line.

```text
Subject: a small flame on a wick inside a tray of folded paper, on a near-black
ground, focal element in the right third.
```

Name the ground in the subject line, since the system prompt leaves it open. Do not add adjectives such as "stunning", "cinematic" or "ultra detailed". They pull the output toward the polished look we are trying to avoid.

## Reference images

Illustration and any recurring person use references, because prompts alone do not hold a style across a batch. Use two or three approved style references at most. With more than that, the model averages them and the paper edges go soft. A recurring figure needs the same reference face in every image of a set, and a generated figure is still never presented as a real person.

We tried a longer negative list in the spring, about thirty items. Results got worse: the model began drawing some of the things we had listed. The short list in the shared prompt is deliberate. Please do not grow it after one bad output.

## After generation

Check every output before it goes to Brand:

- Zoom in on anything that resembles writing. Rack labels and spines are the usual offenders.
- On transparent files, confirm the corners are truly empty, that no fake checkerboard is baked into the pixels, and that there is no pale halo. View on Tallow and on Soot side by side.
- Look for real-brand lookalikes on laptops and shirts.

Failed outputs get rerun with the same prompt. Do not retouch a failure into shape. Files that pass need a full metadata record before they enter the library, with `source: internal-production`.
