# Blog hero images

Content team working rules, June 2026.

**Every blog post has one hero. It is a 16:9 illustration or photo. It is never a dashboard.**

Product UI in the hero looks like an ad on top of an article, and the detail goes illegible at the size most people see it, which is the preview card. If a post is about a product screen, put the screenshot in the body, at a size where it can be read.

## Narrower than the category pages

Not everything in the illustration category qualifies here:

- **Hero illustrations only.** A spot illustration is transparent and square, and it sits inside body copy. Set as a hero, it leaves a small object floating in a wide band, so it is out.
- **No abstract backgrounds.** They have no focal point on their own, and a hero has no type set over it.
- **Tallow or Soot, matched to the post.** Illustration category rules allow either. For blog heroes, default to Tallow. Use Soot for incident retrospectives and long technical posts, so that the list page has some rhythm.

And from photography:

- **Landscape only.** Portrait photos in the library cannot become 16:9 without losing most of the frame.
- **A person is allowed as the subject, but the post has to be about the work** and not a staff profile.

No text on the hero at all, including the post title. The blog template sets the title in live type below the image. Older posts had titles burned into the image, and they looked wrong in every preview card that also printed the title.

## Size and crop

Export at 1600x900. Most library heroes and photos are 3:2, so you will lose some height. Crop from the top and bottom, then check that the focal point has survived. A hero illustration's focal element usually sits off center and the quiet part can go. Some platforms crop preview cards further, so keep the focal point out of the outer tenth of the frame.

Do not upscale. A 1536-wide source enlarged to 1600 is about the limit, and it should look clean at full size.

## Choosing by post type

| Post | Hero |
|---|---|
| Founder essay, signed by Maren | Photo of a working room, or a quiet illustration |
| Technical post by Dov or the engineering team | Infrastructure photo or a concept illustration tied to the mechanism |
| Customer story | Photo from that customer's site if released, otherwise an illustration. Never a stand-in photo that implies it is their site |
| Containment Report findings | Illustration. Save the charts for the body |
| Comparison post | Neutral illustration. No competitor logos or product screens |
| Incident analysis or a post about a breach | Quiet illustration without flame, or an empty-room photo. Keep it plain |

The hero is chosen for the idea in the post. A post on default containment policies should not get a generic "engineer with laptop". Find the one object that matches: a tray under a wick, a closed rack door, a hand on a breaker.

## Avoiding repeats

Check the last ten posts on the blog before you commit. The same image twice in a month makes the blog look thin, and readers on the index page see them side by side. Since a hero image goes out in the social card by default, check the record's `restrictions` as you would for social use.

## Open graph card

The hero doubles as the social preview card unless a separate card is uploaded. Look at the preview before publishing, as the crop differs from the page. If the preview loses the focal point, upload a separate crop.

## Series and guest posts

A multi-part series uses one hero object across all its parts, changed slightly each time. Guest posts from customers follow the same rules, and a guest's own company image only runs if Brand has checked it. Never accept a stock image from a contributor.

## Credit and caption

No caption on heroes. No credit line unless the record's `attribution` calls for one.

## Who picks

The post's author proposes and the blog editor approves. The first use of a new hero in a homepage feature goes through Brand review.
