# Email header images

From the lifecycle marketing manager, March-May 2026 tests, tidied in June.

## Spec

**600px wide. No text in the image.**

The file itself is 600px wide. We tried a 1200px source scaled down in the HTML, and a couple of older desktop mail apps rendered it at full width and broke the layout. So: exactly 600, height between 150 and 240, under 150 KB.

No text means none, and it is stricter than other placements that allow overlay set in design. A large share of readers load email with images off, and headers get blocked first. If the headline is in the picture, those readers get an empty box. Headlines, dates and CTAs go in live HTML. A header image that says "Slow Burn Summit" in type is out, even when a designer set it properly and even if the art is otherwise approved. Put the event name in the first line of the HTML.

That also rules out the social templates, which all carry type, and charts, which need labels.

## What to use

- A hero illustration crop, on Tallow, with one Ember focal element in the center third
- A photo crop with a calm, simple subject

600 wide by 200 tall is a thin strip from a 3:2 source. Pick images whose focal point fits in a band, such as a row of tiles or a cable tray. A person's face at this crop rarely works, because it either fills the strip or gets cut off.

## Transparency and dark mode

Do not use transparent PNGs in email headers. Spot illustrations and other `background: transparent` files are out here, whatever their `safe_on` says. Several mail apps darken the message in dark mode, and they do it unevenly: some swap the ground and leave images alone, and some invert parts of both. A flat ground inside the image keeps the header predictable. Always send a `solid` or `scene` image.

The wordmark sits in its own table cell above the header image, as a panel variant, with alt text. Do not bake the logo into the header picture, since the header is blocked more often than a small logo and you lose the sender's identity with it.

## When to skip the header

Plain-text style emails from Maren or Dov have no header image at all, because an image makes them look like a campaign. The same goes for service notices about incidents or maintenance. Reserve headers for newsletters, event invitations and report announcements.

## By email type

| Email | Header |
|---|---|
| Monthly newsletter | One hero illustration crop, changed each issue |
| Report announcement | Illustration taken from the report cover art, with its title removed |
| Event invitation | Photo crop or illustration, cleared for event use |
| Product update | Usually none. A small product crop in the body does more |
| Sales follow-up | None |
| Renewal or billing notice | None |

Do not animate headers. Some mail apps only show the first frame, which then has to work alone. Do not slice a header into several image cells. That technique causes hairline gaps in the same older apps that dislike large images.

Keep one crop per campaign and reuse it across the sequence, so that the second and third sends read as a set. Each one still gets its image record checked, because `restrictions` can change between sends.

## Before sending

Send a test to the seed list. Check with images off, and in dark mode on a phone. The email should read completely with the header missing.
