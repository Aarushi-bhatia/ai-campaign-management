# Landing page imagery

Web team and Brand, last updated September 2026.

## The hero

**A landing page hero shows product UI or a working room.** Those two options only.

That excludes illustration from the hero slot, even though we use it heavily elsewhere. Visitors on a landing page are deciding whether Wickhold is real. A screen from the product, or a real room where this work happens, answers that faster than a metaphor.

Use product UI when the page is about a product or a capability. Use a working room when the page speaks to a role or a problem and there is no single screen to show.

| Page | Hero |
|---|---|
| Quenchline product page | Product UI: one containment action |
| Evenburn product page | Product UI: exposure path or fix order |
| Leashgate early access page | Product UI: a tool-call policy, with the early access pill in frame |
| Platform engineering solutions page | Working room, or a terminal-adjacent product view |
| CISO or board-facing page | Working room. No people posing |
| Campaign page for the Containment Report | Working room |
| Event registration | A working session photographed at a past Slow Burn Summit, cleared for this use |

## Narrower than the screenshot rules

Product screenshots in general may show a full frame or a crop. In a landing hero:

- **A crop only.** No full-dashboard views. The hero width on a laptop leaves about 700px for the image, and a 1600x1000 frame shrinks to illegible at that size
- **One callout at most.** Up to three are allowed elsewhere
- **A mobile check.** At 390px wide the crop has to show something readable. If it cannot, supply a tighter mobile crop

For working rooms, narrower than photography:

- **No visible screens with content,** so that the eye goes to the headline
- **The photo has to work with the headline beside it.** Type does not sit over the room. The layout is split, or the image sits below

## Legal pages carry no people

Terms, privacy, subprocessors, the DPA page, and the like: no people in any image on these pages. That covers portraits, illustrated silhouettes, hands in a shot and a team in the footer strip. The same applies to the legal section of any combined page.

## Further down the page

Sections below the hero have more room. Spot illustrations work in feature rows. Check each section's ground, since landing pages usually alternate Tallow and Soot bands, and a `safe_on: light` file dropped in a Soot band disappears. Nav and footer logos need checking band by band as well.

Screenshots in the body can run larger and carry callouts. Keep one image per section at most.

Customer logo strips: only what Legal has approved, and no more than the approved set, even when a strip looks empty. Keep them in one tone. Do not recolor logos in Ember.

Quote portraits go through the people and consent check first.

## Performance

Hero image under 250 KB on the wire. Serve WebP with sizes set, and do not lazy-load the hero. SVG for logos and icons. Everything below the fold lazy-loads. A slow page is a credibility problem for a company that sells to platform engineers, and they will open dev tools.

## Video in a hero

Allowed: a silent loop of a containment action, under ten seconds, with a poster frame that passes the hero rule by itself. Not allowed: a talking-head brand film. We tried one on the old homepage and the bounce numbers were bad enough to end the debate.

## Reuse across pages

A/B test variants use the same hero rule. If you test a hero, both arms must pass. An illustration "just for the test" still fails, and test pages have a way of becoming permanent.

Do not use the same working-room photo on two product pages. Visitors move between them, and a repeated picture makes the site look small.

## Common hero rejections

| Submitted | Problem |
|---|---|
| Illustration of a wick on the Quenchline page | Good art, wrong slot. Move it to a feature row |
| Full incident page, shrunk | Illegible. Crop to the one action |
| Bright stock-looking meeting room | Fails the working-room test, and it could be any company |
| Product UI floating on a laptop mockup | Adds a second object. Use the crop alone |
| Abstract background with a headline | No product and no room, so it answers nothing |

## Open graph and paid variants

Each page needs its own preview image, built from the hero crop. A preview with a product crop needs a larger, simpler view of the same action. Paid campaign pages should reuse the same hero as the ad, so that the click feels continuous.

Region-specific pages use the same imagery unless Legal says otherwise. Do not localize by swapping in a landmark photo.

## Review

Every landing page hero is a first use for that page and goes through Brand. Paid landing pages also go to Legal for the claims on the page, and the image goes along with them, because a screenshot can make a claim too.

Allow two working days for Brand. Campaign deadlines are not exempt, so book it when the page is scoped.
