# LinkedIn images

Social lead's notes, updated August 2026.

## The spec

- **1200x627.** Export at exactly this size. Anything else gets cropped by the platform, and the crop rarely helps
- **At most seven words of overlay text**
- **Overlay text is added in design**, as live type in the template, over a finished image

Seven words means seven, counted the plain way. A hyphenated word is one word, and a number is one word. The logo does not count. A source line does count, so most stat images move the source into the post copy, which is where we want it anyway.

The seven-word cap narrows what the social graphics rules allow. A stat card on any other surface can carry a measure line and a source. On LinkedIn it gets the number and the short label only.

| Overlay | Words | Verdict |
|---|---|---|
| Small fires stay small. | 4 | Good |
| Median time to contain: 7.4 hours | 6 | Good, source in the post |
| 11 minutes, down from 4 hours | 6 | Good, with Lowmoor named in the post |
| Contain first. Then find out what happened. | 7 | Good |
| What Wickhold learned from surveying 412 platform and security leaders | 10 | Too long |
| Is your team ready for a runtime incident? | 8 | Too long, and it is a question |

## What goes in the frame

Use, in rough order of how well they have done for us:

1. A photo of real work, with no overlay at all
2. A stat card from the social templates. Quote cards rarely fit the cap
3. A short product crop showing one action, large enough to read in the feed
4. A hero illustration, cropped

Library images are 3:2, so a 1200x627 crop loses about a fifth of the height. Keep the focal point near the vertical center. Spot illustrations should sit on a solid Tallow or Soot layout from the template. They are transparent and LinkedIn will show them on its own background if you upload them as they are.

Do not run overlay text across a photo's focal point. Text goes on a solid band or in the quiet side of the frame.

## By account

**Company page.** Follows all of the above. Logo present on designed images, absent on plain photos.

**Founder accounts.** Maren's and Dov's posts take a plain photo or no image. Designed cards with a company logo look like an ad under a personal post, so skip them. No overlay text on founder images unless Maren asks for it.

**Staff.** Anyone can use the approved templates. Reshare the file as it is.

## Document posts and video

PDF document posts are off the plan, for the same reasons as carousels. Native video follows the screenshot rules for captures. A title frame counts as an image and falls under the seven-word cap.

## Timing against the event calendar

Dated images age badly. A card that names a date comes down from the scheduled queue the moment the date moves. After the event, do not reuse it. Set `restrictions` on the record when you file it, as with any time-limited card.

## Series that have worked

Monthly "from the Containment Report" posts with one number and no other decoration. Plain photos in Field Day recaps, chosen with the people rules in mind. Short "what changed in this release" crops. What has not worked: anything that looks like a slide. If a LinkedIn image looks as if it came from a deck, redo it.

## Checks

- 1200x627 exactly
- Count the words
- Overlay legible at phone width
- Image record read, including `restrictions`

The picture should still make sense with the post text collapsed, since the image is often all a reader sees before "see more".

The most common error in the last quarter was a logo dropped on without checking the ground. The second was a stat shortened until it no longer said what the source said. If shortening changes the meaning, use a different stat or use no overlay.
