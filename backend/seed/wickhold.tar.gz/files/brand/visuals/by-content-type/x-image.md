# X images

An image on X is optional. Most of our best posts have none. Add one only when it shows something the words cannot: a chart, a config snippet, a piece of the product doing its job.

**Never a stock photo.** Nothing bought or licensed, and nothing from the library that could pass for one. X is where our engineering audience spends its time, and a generic office shot under a technical post costs us credibility in that thread. A photo from the library is allowed only if it shows something real and specific, such as a rack or a cable run we can name.

## What works

- A code or YAML card on Soot, from the engineering post format
- A tight product crop of one containment action
- One chart with its title
- A spot illustration, flattened on Tallow or Soot, for a light post

This is narrower than the social graphics rules in two ways. No overlay text on photos here, since the feed crop is unpredictable. And no quote cards: on X, type the quote into the post with the customer's name.

## Size

16:9, 1600x900. Keep the focal point in the middle, as the timeline crops and phone previews trim the edges. Long screenshots of text get a "show more" crop, so do not post them. Write a thread.

## Crops and overlays, good and bad

Good: a 40-line policy file cut down to the eight lines that matter, in IBM Plex Mono on Soot.

Good: one bar chart from the Containment Report, with its title readable at phone width and the source in the post.

Bad: a LinkedIn card reposted as it stands. X crops the bottom edge off, which is where the logo sits. A bad image is worse than no image here, so when an image needs a third round of fixes, drop it and post the text alone.

Product posts about Leashgate deserve an extra look, since a tight crop can lose the early access pill. Keep it in frame or pick a different crop.

## Replies and threads

One image per post at most, and no images in replies to strangers. In a thread, only the first post needs one, if any. Do not attach a marketing card when replying to someone who raised a problem in public.

Memes and reaction images: no. Most use third-party material, and the voice doesn't need them.

Kofi's team can post without a Brand review if the image passes the common checks. Company account images go through the social lead.
