# Data visualization

Charts are built from data by a person, in code or the design tool. They are never drawn by an image model and never traced from somebody else's report. Written for the 2026 Containment Report and kept for everything since.

## What a chart is for

A Wickhold chart makes one point. Write the point as the title, in a full sentence, in sentence case. The chart then shows why that sentence is true.

| Bad title | Good title |
|---|---|
| Time to contain by team size | Median time to contain is 7.4 hours |
| Survey results | 41% of platform teams need more than six hours to contain a runtime incident |
| Lowmoor Credit Union performance | Lowmoor's time to contain fell from 4 hours to 11 minutes |

If you cannot write the sentence, you do not have a chart yet. You have a table, and a table is often the better choice. Engineers like tables. For fewer than three numbers, set the number in type and skip the chart.

## Data you can chart

Only approved figures go into public charts. A chart does not launder a number: the rules on claims, ages of statistics and lab figures apply to the chart the same way they apply to a sentence.

- Survey data carries its report name and year, and the sample where there is space. The 2026 report surveyed 412 platform and security leaders.
- Customer results appear only with approved customers, with node counts: Lowmoor at 220 nodes, Ostler at 1,900 nodes.
- A lab figure keeps its label on the chart itself: "in Wickhold lab benchmarks, 2026". Do not move it to a footnote on another page.

No invented or "illustrative" numbers in published charts, even on an unlabeled axis. A rising line with no scale is a claim with nothing behind it.

Every chart carries a source line at the bottom, in the citation format from the style guide, small and in Whetstone on Tallow.

## Color

Bars and lines use the palette.

- **Ember for the one series or bar that makes the point.** All others are Whetstone.
- On Soot, use Tallow for context series, with Ember as the highlight. Whetstone is too dim to read there.
- Verdigris is the second highlight, used only when two series truly need names, such as before and after.
- No Ember tints. If you need a ramp for ordered data, use Soot to Whetstone to pale Tallow steps.

Ember, Whetstone and Verdigris sit very close together in lightness. Printed in grayscale, or viewed by a reader with color blindness, they merge. So hue never works alone: label each series directly on the line or bar, and separate adjacent bars with a gap. Legends are a last resort, since they send the reader back and forth.

Red and green are not used for bad and good. A chart about containment should not look like a stock ticker or an alert console.

## Form

- Horizontal bars for comparing named things, since labels fit
- Lines for change over time, with no more than four lines
- A single before-and-after pair for customer results
- Bars start at zero. Always. Line charts may start elsewhere, with a labeled axis and a reason
- Time axes use real intervals. Do not compress the gap between 4 hours and 11 minutes with a broken axis to make the chart prettier. The small bar is the story

Not used: pie charts, doughnuts, gauges, radar charts, 3D anything, dual axes, stacked areas with more than three bands, bubble charts, Sankey diagrams in marketing, and world maps with glowing dots. We tried a Sankey in the Containment Report draft to show incident paths. It took a paragraph to explain and everyone hated it.

## Type and labels

Chart titles in Bricolage Grotesque. Axis labels and data labels in IBM Plex Sans. Commands and metric names, where they appear, in IBM Plex Mono.

Label units every time, and spell out units in axis titles ("hours to contain"). Round to the precision of the source: 7.4 hours stays 7.4, and it does not become "about 7" or "7.40".

Gridlines are thin, Whetstone at a low weight, and only where they help a reader estimate a value. If each bar has a data label, delete the gridlines and the axis.

## Diagrams

Architecture diagrams fall under this page. Boxes are flat, with a 1.5px Soot stroke or a solid Tallow fill on Soot. Arrows are straight or right-angled, and each one is labeled with what actually passes along it. The eBPF agent, the node, the pod and the control plane are drawn the same way each time. One Ember element marks the part the diagram is about. No cloud vendor icons, and no clouds drawn as clouds. A diagram with more than about nine boxes should be split into two.

## Grounds and export

Charts go on Tallow or Soot, the same as illustrations. Keep an editable source file and record where it lives in the `description` field of the library record. Export PNG at twice the display size, or SVG for the web if the page supports it. Charts that will sit on either ground are exported twice, and the second file gets `variant_of` pointing at the first.

## Tables

When a table is the right call, keep it plain: horizontal rules only, Soot text on Tallow, numbers right-aligned in IBM Plex Mono so that digits line up. Highlight one row with an Ember rule at its left edge. Do not zebra-stripe.

## Good and bad chart notes

**Good annotation:** "Teams with a default containment policy" with a short rule pointing at one bar.

**Bad annotation:** "Shocking gap!" Or any wording that treats a survey number as a threat. The numbers carry enough on their own.

**Good source line:** the report name, the year and a link, formatted as the style guide asks.

**Bad source line:** "Source: industry research."

## Review

Data checked by whoever owns the source: product marketing for the Containment Report, Legal for customer results. Brand checks form and color. Do not skip the first of these because the chart "only reuses" a number from an earlier piece.
