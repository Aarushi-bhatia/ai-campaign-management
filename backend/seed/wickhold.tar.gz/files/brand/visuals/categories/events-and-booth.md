# Events and booth graphics

From the events team and Brand. Rewritten after Slow Burn Summit 2026 (September 15–16, Denver) while the mistakes were still fresh, in time for the booth at the big cloud-native conference in November.

This covers anything physical or on a stage: booth walls, banners, lanyards, stage slides, signage, printed handouts. Scheduling, budgets and staffing are the events team's business and are not here.

## Reading distance decides everything

A booth wall is read from across an aisle by someone walking past. A rough guide: 1 inch of cap height for every 10 feet of viewing distance. A back wall read from 30 feet needs 3-inch caps, and that is the floor. If the sentence does not fit at that size, it is too long.

One booth wall carries one idea:

- Good: "Small fires stay small." with the logo and nothing else
- Good: "Median time to contain: 7.4 hours" with the report name small underneath
- Bad: three columns of product features, a QR code, four customer logos and a tagline

Detail belongs on the demo screen and in the conversation. Our best booth to date had a plain Soot wall and one person standing at a laptop.

## Materials and color

Ember shifts in print more than any other color we have. On fabric it tends to go red, and on vinyl it can go brown. Always get a physical proof from the printer, on the actual material, and compare it with the printed color reference that Brand keeps. A PDF proof does not count. This step was skipped for the 2026 Summit stage banner, and it arrived closer to tomato than Ember. It got used anyway, because the print ran the day before.

Tallow is hard to hold on white fabric: it turns cream or pinkish. Soot backdrops are forgiving and hide dirt. For a multi-day show, prefer Soot on anything people will lean on.

Keep these with every print order:

- Vector logo files, never PNG, for anything larger than tabloid
- All type outlined or fonts embedded
- 0.125-inch bleed on print, or what the vendor specifies for fabric
- Name of the person who approved the proof

## Slow Burn Summit

Slow Burn Summit is our own conference, so we control every surface. The look uses Soot rooms, Tallow signage and one Ember element per surface. The Ember element is the same each year, the wick dot, enlarged, on the main stage wall. Do not add a yearly theme graphic. The edition year is set as plain type.

Stage slides are 16:9, Soot ground, Tallow text, minimum 32 pt. Speakers get the template six weeks ahead. Customer speakers can use their own company template if they want to, with our logo on neither their title slide nor their closing slide. It is their talk.

## Field Day

Field Days are small regional meetups, with a modest kit: one pull-up banner, name tags, a printed agenda. The kit ships in one box. Do not add a booth wall or backdrop for a room of 30 people. Printed agendas are Tallow stock with Soot text. City names are set in type, with no skyline illustrations. We dropped those after the first round because they looked like a tourism brochure.

## Third-party shows

At a booth in someone else's hall, you will be surrounded by glowing walls and very loud screens. Do not compete on brightness. A quiet Soot booth stands out on that floor. Check the show's rule sheet for height limits and fire-retardant fabric certificates before artwork starts, since these can force a redesign.

Sponsor walls on the organizer's side are their layout. Send the correct logo variant for their ground, and ask to see the ground. Sponsor packs usually request "logo on transparent" and then place it on a dark LED wall.

Booth screens run the demo environment, never a live customer tenant. Rehearse with the venue's lighting and turn screen brightness down from the store default.

Printed panels live for a long time and cannot be edited on the show floor. Any panel mentioning product status, pricing, certifications or customer names goes to Legal before it goes to print, and the deadline for that is three weeks before the printer's cut-off. Panels get reused from show to show, so re-check old panels before they ship.

## Badges, signage and QR codes

Name badges carry the first name large, then the company small. No job titles in large type, since people read them from across a table. Ribbons for "speaker" or "staff" are Tallow with Soot type. Wayfinding signs use one arrow and two or three words, in Bricolage Grotesque, and hang at a height people can see over a crowd.

QR codes go on one surface per booth at most, at a size that scans from a yard or so, with a short URL printed underneath. Test the printed proof with two different phones. A QR code on a back wall has never worked for us.

## Webinars and virtual events

A virtual event uses the same stage template. Keep the lower third empty, since the platform puts names and captions there. Provide speakers with one background image at most, and it must be a plain Tallow or Soot ground. Check the logo against the template's real ground before the session, in full-screen mode.

## Swag

Fewer things, better made. Dark Soot shirts with the reversed mark on the chest, small. Enamel pins of the mark are popular. Wick-themed items are fine, such as a plain match box. No actual candles at venues, as most of them forbid open flame on the fine print, and we learned this the awkward way at a hotel venue. No stress balls, no padded shields, no slogans about hackers on anything.

## Photographing our events

Each event gets a named person responsible for photos. The shot list includes working moments: hallway talks, whiteboard sessions, people at the demo laptop. Skip the wide shots of empty chairs. Stage photos should be taken from the side, where the lighting is more natural than from the front.

When the shoot is ingested, the events team fills in the metadata, including `restrictions`, on the same day. Files with no record stay out of the library. Check who is recognizable before anything is used. The people rules apply to attendees as well as staff.

## After the event

Collect leftovers. Return reusable panels to storage with a note on what is out of date. Send Brand photos of what actually got built, including what went wrong. The tomato banner is now the first slide of the print briefing.
