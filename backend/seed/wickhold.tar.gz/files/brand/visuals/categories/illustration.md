---
title: Illustration
owner: Brand design
reviewed: 2026-06-18
---

# Illustration

Everything we draw looks like it was cut from paper and laid on a table. That style came out of the rebrand work, and it is deliberately easy to recognize at a small size next to a competitor's glowing network diagram.

## The style

**Flat cut-paper shapes.** Crisp edges with a slight hand-cut irregularity. Layers can overlap. Depth comes from stacking, and the only shadow allowed is a hard offset shape in one flat, darker tone.

**One Ember focal element.** Exactly one thing in the picture is Ember. That is where the eye goes. Everything else is Soot, Tallow, or a small amount of Whetstone or Verdigris.

**On Tallow or Soot.** Those are the only two grounds for finished illustration. An Ember ground removes the focal element, because nothing can stand out from it. Whetstone and Verdigris grounds look muddy.

**No gradients.** None, anywhere: no soft shadows, glows, blurs, mesh fills or textured airbrush. If a shape needs to look lit, cut a second shape. In review, this is the rule most often broken by accident, usually by a shadow effect left on by default in the design tool or by an export that adds banding.

Also out: outlines around shapes, 3D, isometric projection, photographic textures pasted on shapes, and stock vector packs. We tried isometric cluster diagrams in January. They looked like every infrastructure startup's site, and they required a depth that flat paper cannot give.

## What to draw

The brand idea is a wick: the place where a fire is allowed to exist. Use that vocabulary and its everyday relatives.

| Idea | Shapes that work |
|---|---|
| Containment | A ring around a small flame, a tray, a snuffer held above a wick, a firebreak cut through paper grass |
| Isolation of a workload | One tile lifted out of a grid, a pod shape with a paper band around it |
| Posture and drift (Evenburn) | A row of even flames with one leaning, a level, a line of tiles slightly out of true |
| Tool-call policy (Leashgate) | A short tether, a gate latch, a loop of cord around a post |
| On-call | A lamp and a mug, a single lit window in a dark paper building |
| Fix order | Steps cut from paper, three stones across a stream |

Keep the flame small. A small flame contained is the entire idea, and a large one means disaster, so the flame should stay well under a tenth of the frame. If the concept seems to need a wall of fire, the concept is wrong.

Kubernetes has its own visual habit of hexagons and ship wheels. Do not draw the Kubernetes logo, which is someone else's mark. Pods are tiles. Nodes are trays or shelves. Clusters are groups of those on a shared ground.

## People in illustrations

Rarely. When a figure is needed, show a simple paper silhouette with no face, working at something. Do not use characters, mascots or recurring cartoon engineers. We had a proposed mascot in the rebrand round, a little candle with eyes, and we all agreed to pretend it never happened.

## Formats in the library

| Format | Size | `background` | Use |
|---|---|---|---|
| Hero illustration | 1536x1024 | `solid` | Wide placements, full scene with ground included |
| Spot illustration | 1024x1024 | `transparent` | Inline in body copy, feature grids, beside text |
| Abstract background | 1536x1024 | `solid` | Behind type in designed layouts. No focal element |

Hero illustrations already contain their ground. Check whether the file is the Tallow or the Soot version and place it in a section where it does not produce a visible box edge against a slightly different ground. Sample the color: if the layout ground is exactly Tallow or Soot, the edge disappears, which is what you want.

Spot illustrations take on whatever sits behind them, so `safe_on` matters. Many spots use Soot shapes and are `safe_on: light`, and those shapes vanish on a dark layout, leaving a floating Ember fragment. Others are built for dark and carry Tallow shapes. Check the record, look at `variant_of` for a sibling, and preview on the real ground. If an image is `any`, still look for a pale fringe along cut edges on Soot.

Do not put a spot illustration on a photograph. Do not put a spot on an Ember band. Do not put a box behind a spot to make it safe on the wrong ground, because the box will look like a mistake. Use the correct version or ask for one.

Abstract backgrounds exist to carry type. On their own they have no focal point, so they are never published without the layout on top of them.

## Composition

- Hero: focal element off center, with at least a third of the frame quiet. That quiet space is where crops happen.
- Spot: centered, with an even margin. No shape touches the edge of the canvas.
- Scale: one size jump between focal element and supporting shapes. Eleven small shapes around one medium shape reads as confetti.
- Fewer shapes than you think. Most good spots have under eight pieces of paper.

## Color limits

Ember appears once, as a single element. Two separated Ember shapes means two focal points. If the composition needs a second accent, use Verdigris, and keep it small. Whetstone is good for the supporting middle layers on Tallow, although its value is close to Ember's, so it does not provide much separation when placed directly next to the focal element. Leave a Soot or Tallow gap between them.

All colors are exact palette values. Do not use tints of Ember. Tints turn it toward pink and off brand.

## Series

When a piece needs several illustrations, such as a report with chapter openers, vary the object and keep the ground, scale and Ember position consistent. Mixing Tallow and Soot grounds within one piece is fine only if it follows the document's structure, for example one dark chapter opener per part.

## Report covers and chapter openers

Long pieces earn one larger concept. The Containment Report cover uses one cut-paper object at a large scale on Soot, with the title set as live type by a designer. Chapter openers repeat that object in a changed state, for instance the tray filling up or a wick burned further down. This gives a long PDF a thread through it without any extra Ember.

## Concepts that failed in review

| Concept | Why it failed |
|---|---|
| Paper flame in a glass jar | Reads as a candle ad, and the jar needed a highlight, which needs a gradient |
| A fire engine | Cute, and it suggests rescue after the damage is done |
| A forest fire with one saved tree | Too much fire, plus sentimental |
| A dog on a leash for Leashgate | Everyone laughed, then nobody could explain the agent. The tether alone works |
| A map of connected glowing nodes | Off style, and it looks like every other vendor |

## Export checklist

PNG for transparent files, with a real alpha channel. Open the file on Tallow and on Soot, then zoom to 200% on the cut edges. Check that the Ember value samples at `#C2501F`, since color profiles in some export paths move it slightly. Save the editable vector source beside the export and record where it lives.

## Requests and review

Give the designer the idea in one sentence and the placement. Do not sketch the metaphor yourself in the request unless you are sure of it: people usually ask for a shield, and we do not draw those. New illustrations get a review at thumbnail size and at full size on both grounds. Once approved, the file enters the library with a complete record, including `background`, `safe_on` and `variant_of` for any ground-specific sibling.

Good request: "Blog post about draining a node before an upgrade. Calm, procedural."

Bad request: "Something cool and techy with flames and a shield for our big launch!!"
