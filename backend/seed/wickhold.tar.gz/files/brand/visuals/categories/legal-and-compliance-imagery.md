# Legal, compliance and trust imagery

Agreed between Noor Eskelund (Brand) and Priit Salonen (General Counsel), April 2026. Changes need both of them.

Applies to the trust center, security and compliance pages, the privacy and terms pages, subprocessor lists, security questionnaires we send as designed PDFs, and any section of a sales document that is about certifications.

## Illustration only

**Legal, compliance and trust pages use illustration only.** No photographs and no product screenshots.

Readers on those pages are auditors, procurement staff and security reviewers. They are assessing evidence. A photo of a confident person in an office adds nothing and makes the page look like marketing. A product screenshot implies that a specific feature is part of the compliance claim, and Legal does not want that inference made on a page that carries contractual weight.

Illustration on these pages follows the normal cut-paper style, with a narrower range of subjects:

- Records and paperwork: a stack of pages, a ledger, a folder tied with string, a date stamp with no text
- Calm, procedural objects: a checklist with blank lines, a small key on a hook
- Wick and ring motifs, used sparingly

Tallow grounds only. A Soot ground reads as dramatic here. Keep flames out altogether on these pages: a fire on the page where we discuss audit results sends the wrong message.

No shield shapes of any kind. Besides being category clichés, they echo the retired logo and they resemble a certification seal, which is the problem the next section deals with.

## No badges for certifications we do not hold

A badge is a claim. The rule: **a certification's mark or badge appears only if Wickhold holds that certification today.** Status at the time of publishing is what counts. Legal keeps the current status, and you should check it rather than rely on what a past page showed.

| Program | Badge allowed? | Notes |
|---|---|---|
| SOC 2 Type II | **Yes** | Held, renewed January 2026. Use the official artwork Legal supplies, unmodified |
| FedRAMP | **No** | No mark, no logo, no badge in any form, on any page, in any deck |
| Any other program (GDPR, HIPAA, PCI DSS and so on) | **No** | We hold no badge for these. Text explains how we support customers |

FedRAMP is the one people push on. We are working toward it, and that is a sentence, in legal's approved wording, set as plain text. A designer should not visualize it. The following are all off the table, because each of them would look like an authorization at a glance:

- A grayed-out or outlined FedRAMP mark
- A badge reading "in process" or "coming soon"
- A progress bar or timeline graphic about authorization
- A government-themed seal, star or eagle motif
- A row of badges with an empty slot

The same goes for home-made seals of any kind: "Enterprise grade" stamps, "Trusted" ribbons, checkmark rosettes, a "Secure" tick in a circle. If an auditor did not issue it, it does not go on the page.

## Using the SOC 2 badge

- Source it from Legal. Do not take it from a past web page, and do not redraw or recolor it
- Place it next to the sentence it supports, with a date or period where the page gives one
- Use it on the trust center and in security documents. It may appear on a landing page footer or in a sales deck if Legal has seen that layout
- Keep it at a size where it can be read, and on a Tallow ground
- When the status changes in any way, Legal notifies Brand and the badge comes down the same day. The library record gets a `restrictions` note

Check `restrictions` on any compliance-looking file in the image library, especially older exports. Older files may show marks or claims we would not make today, and a clean-looking thumbnail proves nothing.

## Documents outside the website

Security questionnaires, audit summaries and data-handling documents follow the same rules in PDF. Sales decks are where trouble usually starts: somebody builds a "trust" slide by copying logos from the web. A trust slide in a deck uses the same approved set as the website and nothing more. If a prospect's procurement form asks for a logo or badge we do not hold, the answer is a sentence and no artwork.

Partner-supplied graphics are a common source of unapproved marks. If a partner offers a "certified partner" or "marketplace verified" badge, it counts as a badge under this page and goes to Legal.

## Layout on trust pages

One illustration near the top of the page is enough. Sections below it are text, tables and links to documents. Do not pair each section with a spot illustration, because a trust page that looks decorated reads as less serious. The SOC 2 badge sits beside its sentence and is the only graphic in that section. Status indicators such as "held" and "in process" are plain words in a table: no green dots or colored pills, which can read as a pass.

## Sign-off

Every new image on these pages goes to Legal as well as Brand. There is no self-serve route here, which differs from most imagery. Allow three working days.
