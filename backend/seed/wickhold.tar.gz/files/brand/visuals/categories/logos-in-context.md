# Logos in context

How to pick the right logo file for what is behind it. Clear space and minimum sizes live with the logo specification. This page is about choosing the variant, and it exists because we keep getting this wrong in a way that is easy to miss on a bright monitor.

Noor Eskelund, Brand. April 2026, with an example added in August.

## The rule

**Choose the logo variant by the background it will sit on. Ink on light. Reversed on dark.**

An ink logo on a transparent file vanishes on a dark layout. A file with no background has no ground of its own, so the Soot strokes land on Soot or near-Soot and disappear. All that remains is the Ember dot floating by itself.

In August a partner webinar deck went out with exactly that on every slide. The title slide was Soot, the ink logo was dropped in from the last deck, and the preview thumbnail had a pale checkerboard behind the logo, so it looked fine in the slide sorter. On the shared screen there was an orange dot in the corner of every slide and no name. Nobody in the rehearsal said anything, because a small dot looks like a design choice.

## The four variants

| Variant | `background` | `safe_on` | Use on |
|---|---|---|---|
| Ink on transparent | `transparent` | `light` | Tallow, white paper stock, other pale grounds |
| Reversed on transparent | `transparent` | `dark` | Soot, deep grounds, the dark bands of a light page |
| On Tallow panel | `solid` | check the record | Busy or mixed grounds, photos |
| On Soot panel | `solid` | check the record | Busy or mixed grounds, photos |

The mark and the mark-with-wordmark both exist in these variants. All of them are linked through `variant_of`, so if you have found one, you can find the others from its record. If the only logo file you can find in a folder is the ink one, you have not looked in the library.

The logo itself is the geometric W, with the center stroke rising as a wick and the one Ember dot at the tip. The dot stays Ember in every variant.

## Working out the ground

The ground is what is directly behind the logo in the finished layout. A file's name or the color of the page as a whole does not settle it.

- **Dark band on a light page:** that spot is a dark ground. Use reversed.
- **Footer:** most of our footers are Soot. People paste the header logo into the footer, and this is the most common error we see.
- **Slide decks:** title and section slides are often Soot while content slides are Tallow. One logo in the master will be wrong on half the slides. Set it per layout.
- **Dark mode:** a web page that follows the reader's system theme has both grounds. Swap the file with the theme. Do not rely on a CSS filter to invert it, because that turns the Ember dot blue-green.
- **Email:** assume the ground can change under you, since some mail apps darken the page. Use a panel variant.

Previewing does not count unless the preview shows the real ground. Design tools and slide apps show a checkerboard or a white canvas. Check on the layout itself at full size.

## Mid-tones and photos

Neither ink nor reversed is safe on Whetstone, Verdigris or Ember, and neither is safe on a photograph with a mix of light and dark behind the mark. Those are panel cases. A Tallow or Soot panel gives the logo its own known ground.

Choose the panel that sits quieter against the image. A dim, underexposed photo usually wants the Soot panel, placed on a corner of the frame where nothing important is happening.

Reversed directly on a photo is acceptable only where the area behind the whole logo is consistently dark, and it stays that way at every crop the platform might apply. In a responsive hero the crop changes with the window, so use a panel.

## Do not

- Recolor a variant to fix a contrast problem. There are no Ember, Whetstone or Verdigris logos
- Add a drop shadow, glow or outline to rescue an ink logo on a dark ground
- Put a pale rectangle behind an ink file to fake a panel. The real panel files have the correct proportions
- Redraw the logo or ask an image model for it. It will misspell the wordmark and it will not know where the dot goes
- Screenshot a logo from a web page
- Place the logo inside a generated scene by prompting for it. Generate the scene and composite the vector afterwards

## The old logo

The old shield logo is retired, and it must not be used anywhere, including on "throwback" content. Copies remain in the library, and some of their records show the retirement only in `restrictions`. If a logo search turns up something with a flame inside a shield, that is the old one. Do not use it. Tell Brand if a live page still carries it.

## Other companies' logos

Where our logo appears next to another organization's, such as a partner slide or a sponsor wall, both logos need their proper ground and their own clear space. Do not set both on a shared panel in one color unless the other company has agreed. Whether a customer's logo can appear at all is a Legal question and depends on the approved customer list.

## Small placements

Social avatars, favicons and app tiles use the mark alone, on its panel. The wordmark does not survive at those sizes. The avatar uses the Soot panel across all company accounts, so the dot reads at feed size.

## Quick answers

| Layout | Use |
|---|---|
| Blog page header on Tallow | Ink on transparent |
| Soot slide | Reversed on transparent |
| Soot footer of a Tallow page | Reversed on transparent |
| Corner of a photo | Soot or Tallow panel |
| Conference lanyard in Ember | Panel. There is no Ember logo |
| Email header area | Panel |
| Page that follows system theme | Swap ink and reversed with the theme |

If you are unsure, ask Brand and send a screenshot of the actual layout, not the logo file.
