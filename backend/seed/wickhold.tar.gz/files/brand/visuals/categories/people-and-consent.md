# People and consent

Owner: Noor Eskelund, with Priit Salonen for the release form. Revised July 2026.

Any image in which a person can be recognized falls under this page, whatever its other category. That includes photos, video stills, conference shots, webinar screenshots with faces in the tiles, and group pictures where the person is in the background. Recognizable means someone who knows them could say who it is. A tattoo, a name badge or a distinctive jacket can do that with no face in view.

## Signed releases

**Customer sites and staff need a signed release.** Nothing recognizable from either goes into Wickhold material without one on file.

**Staff.** Every employee who appears in Wickhold imagery signs the image release. It is a separate form from the employment paperwork, so joining the company does not cover it. People can say no, and saying no has no consequences for them. Do not put pressure on anyone. If one person in a team photo has not signed, retake the photo or pick another. Do not ask a designer to cut them out.

**Customer sites.** A photo taken at a customer's premises needs a site release signed by someone with the authority to give it. In practice that means a facilities or communications lead at the customer, and rarely the friendly engineer who let us in. This release covers the location, and each recognizable person there signs their own. Check the frame for the customer's screens, whiteboards, door signs and badges.

An approved customer quote is not a release. If the Lowmoor or Ostler contact has an approved quote, that approval covers the words. Their portrait needs its own signature. A customer being on the approved list likewise does not mean we may photograph their site.

**Contractors, partners, speakers.** They sign the same form as staff. Speaker agreements for Slow Burn Summit include a release clause, and the events team confirms it when someone is on stage. Check that it was signed, since a few speakers strike it out.

**Attendees.** Venue notices about photography cover wide shots of a crowd. A notice does not cover featuring an individual: if one attendee is the clear subject, get their signature or move on.

**People in the background of a shoot.** Same rule. Ask, or frame them out.

We do not photograph minors at all. If a family photo turns up in a founder story, Legal looks at it first.

## Where releases live

Signed forms are stored by Legal. The image library record should show that a release exists: look in `usage_rights`. A photo of a person with nothing there about a release should be treated as not cleared until you have checked with Legal. Do not take a coworker's word for it. Older files came over from a shared drive with thin records.

## Withdrawal

Anyone can withdraw consent. When that happens, Legal tells Brand, Brand adds a line to `restrictions` the same day, and new use stops immediately. Published pieces get replaced within five working days where we control the page. We do not chase old social posts unless the person asks us to.

## People who have left the company

**Never use photos of people who have left the company.** Check the metadata before you use any photo with a person in it.

This holds even when their release is on file, and even when the photo is excellent. A photo of a former employee in new material implies they still work here, and it can embarrass both sides. Some library photos show people who have left, and the record says so. The note is in the metadata, normally in `restrictions`, and you should read `description` as well.

The rule applies to the whole frame. A former employee standing at the back of a team shot rules that shot out, so do not crop around them. Crops get un-cropped when a file travels, and the original is what stays in the library.

The list of who has left changes faster than the library does:

- People Operations tells Brand about departures. Brand aims to update records within a week
- That leaves a gap. If you know someone in a photo has left and the record has not caught up, do not use it, and tell Brand
- If you do not recognize the people in a photo and it shows staff, ask. A quick message to Brand takes less time than a correction
- Senior field and customer-facing staff appear most often in our events photos, so give those the closest look

Existing published pieces stay as they are. We do not rewrite old blog posts because someone moved on, and archived content can keep its photos. New work, republished pieces and refreshed pages follow the rule. A case study you are updating counts as new work.

A person who is quoted or thanked in old content is a different matter from a photo in new content. If in doubt, ask Noor.

## Founders and executives

Maren and Dov have current portraits in the library. Use the most recent one and check `added_date`. A portrait gets retired about every 18 months. Other executives' portraits are for press, the about page and speaking materials, and we do not use them as generic decoration on a blog post.

## How people are shown

- Doing work. People at a task, in their normal clothes
- Respectfully. No catching someone mid-yawn, even if it's funny, and no photos of a person asleep at a desk after a long incident, even with their blessing. Our story about on-call work is not a joke at someone's expense
- As themselves. A staff photo is never captioned as a customer. A person is never presented as holding a role they do not hold
- Without badges or lanyards showing readable names, unless they are the named subject

Diversity in imagery comes from photographing the real team and the real customers across shoots. Do not stage it, and do not source a composite from elsewhere.

In generated scenes, recurring figures stay fictional, and customers stay at a distance. Recognizable employees belong in photographs, with a signed release. We do not present a generated face as an employee, a customer, or anyone who has not signed.

## Quick check before you publish

1. Is anyone in this image recognizable, even in the background?
2. Is a release recorded for each of them, and for the site if it is a customer's?
3. Have I read `restrictions` and `description` for a departure or a withdrawal?
4. Does the caption or the context imply something untrue about who they are?

Any "no" or "not sure" means the image waits.
