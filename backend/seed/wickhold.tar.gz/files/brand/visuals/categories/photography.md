# Photography

Brand team, revised July 2026. The look was set for the rebrand and has not changed. What changed this summer is the section on judging library photos by eye, because we kept seeing the same bad picks in drafts.

## The look

Wickhold photography looks like it was taken by someone who was already in the room.

**Available light.** Windows, overhead tubes, the glow of a laptop, a desk lamp. No strobes, ring lights or colored gels. If a room is too dark for the shot, use a longer exposure or find a better room.

**Warm and slightly underexposed.** Think of the last hour of a working day. Skin tones stay warm and natural. Shadows may go deep, though they should not go black across half the frame. If the image histogram crowds the right side, it is too bright for us.

**Working rooms and real infrastructure.** Equipment rooms, cable trays, network closets, a shared office with coffee rings on the table, a laptop open at a kitchen counter during an on-call shift. Places where the work of running Kubernetes actually happens. The subject of a security company's photo library is the people on call and the things they keep running.

**Honest mess.** Leave the cables. Leave the sticky notes (after reading them). A tidied room reads as staged, and staged reads as an advertisement.

## Subjects we want more of

- Hands on a keyboard, shot from the side, with screens angled away or dark
- Two people talking through a problem at a whiteboard, mid-sentence
- Rack doors, patch panels, labeled cable runs, in warm light
- A notebook with a hand-drawn cluster diagram
- A small team around one laptop late in the day
- The Denver office at the end of the afternoon
- Customer-side infrastructure, once the paperwork is done

## Stock clichés we do not use

These are banned in every Wickhold image, photographs above all:

- Hooded hackers, or any faceless figure at a keyboard in the dark
- Padlocks, physical or floating over a circuit board
- Glowing shields
- Matrix code, or any green-on-black rain of characters
- Blue server-room haze: aisles of racks lit cold blue, usually with fog or lens flare

The reason sits close to the voice. All five say "be afraid" or "we are a generic security vendor", and the brand exists to say neither. An engineer who sees a hooded figure on a Wickhold page will assume the rest of the page is equally lazy.

Close relatives count as the same failure: binary digits projected on a face, a globe wrapped in network lines, a hand reaching toward a holographic lock, a person in a suit pointing at a transparent screen.

## Judging library photos by eye

The library's metadata does not catch everything. Some old or off-brand photos are sitting in the library with an empty `restrictions` field, because nobody ever marked them. Some of them have sensible titles and tags. A clean record tells you nobody objected. You still have to look at the picture.

Open it at full size and ask:

1. **What color are the shadows?** Ours fall warm, toward brown or neutral. If the shadows go blue, it belongs to the 2024 era or to a stock site. The look of that era was bright, cold and very blue, and it clashes hard with Ember on the same page.
2. **Is the light real?** Even, shadowless light across a whole room means a set or a heavy edit.
3. **Is anybody posing?** Direct eye contact with the lens, crossed arms, a group laughing at a laptop: reject.
4. **Could this photo appear on any company's site?** If yes, reject it. We want to see a detail that belongs to this work.

If a photo fails one of these and has no restriction on it, do not use it, and tell Brand so the record can be updated. That second part helps the next person.

Examples from recent draft reviews:

| Draft used | Verdict | Note |
|---|---|---|
| Rack aisle, cold blue light, faint haze, no people | Rejected | Clean metadata, wrong look |
| Woman with headset smiling at the camera in a bright open office | Rejected | Posed and generic |
| Engineer's hands, laptop glow, dim closet behind | Approved | Warm, specific, one focal point |
| Three people at a whiteboard, one mid-gesture, late sun on the wall | Approved | Available light, real moment |

## Photos by setting

**Team and office.** Real desks, real clutter. Aim for moments between people, with one person clearly the focus of the frame. Conference-room shots work when something is happening on the table. The office kitchen works better than the boardroom.

**Infrastructure.** Shoot close. A patch panel with handwritten labels says more than a long aisle. Cables, breakers, fans, a rack door left open. Whatever the room's own lighting does, keep it warm in the edit, and if the room is lit cold and cannot be corrected, get closer to a warm lamp or drop the shot.

**Customer scenes.** The grocery distribution office, the credit union's back room, a store's network closet. These are the most valuable photos we have, since they show Kubernetes and its operators somewhere other than a startup. They also have the most paperwork behind them. A customer scene looks ordinary and that is the point: no hero angles.

**Remote on-call.** Kitchen tables and spare rooms, a laptop at dusk, a phone face-up beside it. On-call happens at home and most stock libraries do not show it. Keep faces turned away unless the person is a signed volunteer.

## Choosing for the audience

The same library serves different readers, so pick with them in mind.

- For platform engineers, prefer detail. A readable (and real) cable label will win more trust than any wide shot. Faces matter less.
- For CISOs, prefer a calm room and a person thinking. The frame should feel like a decision is being made. Skip anything that looks like a crisis in progress, including people crowding a screen.
- For a general or press audience, prefer one clear person doing one clear thing.

## Comments you will get in review

"Too clean." The room looks unused. Find a frame with evidence of work.

"Whose laptop is that?" A third-party logo or a sticker with a company name is visible. Remove it or pick another frame.

"What's on the whiteboard?" Someone has to read it. Customer names and incident details are the usual finds.

"Cold." The white balance is off. If warming it makes skin go orange, the original light was wrong, so reshoot.

## What the metadata means for photos

All photographs carry `background: scene`. A photograph keeps its environment: we do not cut people or objects out of their rooms, and we do not swap the sky through an office window. If you need a subject on a plain ground, you need an illustration.

Most photos are 1536x1024 landscape, with a few 1024x1536 portrait. Check `width` and `height` before you plan a layout around one. Upscaling a photo by more than about 20% shows.

`safe_on` is mostly `any` for photos, since a scene brings its own ground. A photo edge can still fight the layout. A dark, underexposed photo set straight on Soot loses its edges entirely, so give it margin or move it to a Tallow section.

`source` will read `internal-production` for in-house work, and `attribution` is often empty. We do not run photographer credits.

## Cropping

Crops are allowed and usually needed, because different placements want different shapes. Keep the focal point inside the middle two-thirds of the frame, so a further crop by a platform does not cut it off. Do not crop a person at the neck or the wrist. Rotation is limited to straightening a horizon by a degree or two.

## Light editing only

Allowed: exposure, white balance toward warm, gentle contrast, removing a stray sticky note with a password on it, removing a third-party logo from a laptop lid.

Not allowed: adding screens, adding people, removing people from a group shot to work around a restriction, adding atmosphere (smoke, glow, flares), or replacing what is on a monitor with invented UI. If a monitor needs to show the product, use a real capture composited at the correct perspective, reviewed by Brand. We tried fake monitor content in a March shoot and engineers spotted the impossible kubectl output within a day.

Keep the original. Save an edit as a new library record with `variant_of` set to the original, so the restrictions on the source can be traced.

## Shooting new photos

If you are booking a shoot, the brief should cover:

- Named location and who there has agreed to it
- A shot list of six to ten moments, written as things happening rather than as poses
- A warning to everyone to clear whiteboards, sticky notes and screens of customer names, credentials and anything from an active incident
- Who will enter the metadata. Files without a record do not enter the library

Shoot in the afternoon if you have a choice. Morning light in the Denver office is cold, and it takes more work to bring back to our look than it is worth.

Phone photos are welcome if they meet the look. Some of our best library images came from an engineer's phone in a colocation facility. Send the original file, not a screenshot of a chat.

## Things we tried and dropped

**Black-and-white.** Trialed for the founder story in spring. It looked serious and lost the warmth that sets us apart from the rest of the category.

**Ember color wash over photos.** Looked like a concert poster, and it tinted skin badly.

**Close-ups of fire.** One literal candle shot made the rebrand launch. After that the joke was used up, and flames in photographs began to read as disaster. A flame belongs in illustration, where it stays small.

**Drone shots of data centers.** Anonymous, and they could belong to anyone. They also raised a question about which site it was, which we could not answer.
