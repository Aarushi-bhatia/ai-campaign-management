# Product UI screenshots

Product marketing, with design review from Brand. Current as of the September release.

Screenshots are the one kind of image a platform engineer will inspect closely. They will read the pod names and check whether the timestamps make sense. Treat every screenshot as a claim about the product, because that is how it gets read.

## Where screenshots come from

Screens are captured from the product running in the demo environment, or rendered from the demo environment's HTML with Playwright at 1600x1000. Library dashboards are that size and opaque.

Never capture from:

- A customer tenant, even with their permission and even if you blur things
- Our own production tenant, which contains real incidents and real people's names
- A design file. Mockups of features that do not exist are not screenshots. If we need to show something unreleased, it must be labeled as a concept and approved by product marketing and Legal
- A model. Interface images are never generated

Do not paint over or blur a screenshot to hide data. Blurred regions imply the original had something worth hiding. Fix the demo data and take it again.

## Demo data

The demo environment is seeded with fictional clusters, namespaces and workloads. Keep it believable:

- Cluster and namespace names that look like real engineers wrote them: `payments-prod`, `batch-eu`, `ingest`. No `foo`, no `test123`, and nothing funny at a customer's expense
- Container images under `registry.wickhold.example`, so no real image names or registries appear
- People's names, where the screen shows an assignee, from the fictional demo roster. Do not use real staff, because staff leave. No names of customers, approved or otherwise
- Timestamps that agree with each other. An alert cannot be contained before it fired
- CVE IDs only when they are real, public and old. Do not imply a live incident

**Numbers on screen are claims.** A tile that shows a time to contain, a CPU figure or a count of findings fixed will be read as a result. Demo values must not look like a customer result or undercut an approved figure. If a tile reads like a brag, change the seed data, or crop it out. If you want to make a performance point, use an approved claim in the copy and keep it out of the picture.

Pricing and contract screens are never captured. Discount fields, billing pages and node counts tied to a plan stay out of marketing images.

## What to show

Each screenshot shows one action or one finding. That's the focal point, and the crop should make it obvious. Good subjects:

**Quenchline**
- One containment action in progress: isolating a pod's network, freezing a process, or draining a node
- The default containment policy view, with one rule highlighted
- Contain mode and observe mode side by side only if the page is explaining the difference. Otherwise pick one

**Evenburn**
- One piece of drift, showing expected and actual values
- An exposure path from a public entry point to a workload, short enough to read
- A fix order list, top three items

**Leashgate**
- One tool-call policy and the call it blocked or allowed
- An agent identity record
- The early access pill in the product header stays in frame. Do not crop it off

Avoid the whole-dashboard overview shot unless the point is the overview. A full 1600x1000 frame, shrunk to fit a column, is a gray rectangle full of illegible numbers.

## Cropping and framing

- Crop to the region that carries the point. Keep enough surrounding UI so that a reader knows where they are, usually the page title and one neighboring panel
- If UI text is too small to read at the published size, crop tighter or use a different screen
- No fake browser chrome and no device mockups. A floating laptop with a screenshot on it adds a second object and looks like a template
- No perspective tilts or 3D rotation
- Square corners, unless the layout's image style rounds everything equally
- A 1px Whetstone border is allowed when a screen with a light UI sits on Tallow and the edge gets lost

The interface has its own colors and they stay as they are. Do not recolor UI to suit a layout. Do not swap state colors to make something look calmer than it is.

## Annotations

Annotations are added in the design tool, on a separate layer, after the capture. One callout is usually enough, three at the most.

- Callouts use IBM Plex Sans in sentence case
- One Ember ring or arrow marks the focal area. No red boxes, no hand-drawn circles, no numbered badges over the UI
- Describe what happened. "Network isolated in this step" is good. "Instant protection!" is bad
- Commands and flags in callouts use IBM Plex Mono and must be real. Run them first

Example callouts:

| Good | Bad |
|---|---|
| Contain mode freezes the process and keeps its evidence | Stops every attack automatically |
| Drift found on 3 nodes, first in fix order | Full visibility across everything |
| Tool call denied by policy | AI threats eliminated |

## Terminals and CLI output

Engineers often trust a terminal capture over a dashboard. Use a plain terminal at a normal size with IBM Plex Mono, on a Soot background, with the prompt trimmed to `$`. The command has to be real and its output has to be pasted from a real run in the demo environment. Do not edit output to shorten it. Use `...` on its own line if you must cut something, and do so only where the cut changes nothing. Remove usernames, internal hostnames and tokens by fixing the environment and running it again.

## One screen, worked through

The request: show that Quenchline can freeze a process during an incident.

First attempt: the whole incident page at 1600x1000, with the timeline, three tiles, a side panel of pod details and a chat widget from the demo tenant. As a column image it was unreadable, and the one thing that mattered was a small status chip.

Second attempt: a crop to the timeline row showing the containment action and the status chip, with the page title kept above it. One Ember ring on the chip. One callout: "Process frozen, evidence kept". It reads at column width and it says one thing. That is the standard to aim for.

## Keeping screenshots current

Screens age quickly, and old ones do damage in specific ways:

- **Before March 2026, Evenburn screens carry the product's previous name** in the navigation and page titles. Check `added_date` and look at the header. A screen with the old name is unusable, even when the part you want is elsewhere in the frame. Crop-around is not a fix, since the layout and colors are dated too.
- **Before the February 2026 rebrand, the product UI used the old blue theme and the old logo** in the corner. Same answer.
- **Removed features.** Product marketing reviews the library's screenshots against the release notes at each major release, and adds a `restrictions` note to anything that no longer matches.

If a screenshot's record is clean and the picture still looks out of date against the live product, trust your eyes and take a fresh one. The demo environment is reset each Monday, so captures are straightforward. Anything that shows a feature's name, a label or a flow that has changed needs replacing before the next use.

## Metadata for new captures

Every new capture gets a record with `background` set, `source: internal-production`, the product name in `tags`, the release in `description`, and any limits in `restrictions`. If a capture shows a beta feature, say so in `restrictions`, with the date it should be reviewed.

## Video and GIF

Short looping captures follow all of the rules above. Each should show one action from start to finish in under ten seconds. Motion rules sit with the accessibility notes.

## Who signs off

Product marketing checks accuracy. Brand checks the crop and annotations. If a screenshot shows a feature that engineering has not shipped to all customers, the product manager for that area also signs off. Allow two working days.
