# Social graphics

For anything designed for a feed: stat cards, quote cards, announcement cards, event cards. A plain photo or a plain chart uploaded to a post is covered by its own category. This page is about designed layouts.

Last touched by the social lead, May 2026. Kofi's team added the engineering post notes.

## Templates first

The library holds a small set of social templates, built in HTML and rendered with Playwright so the type is live and the layout stays exact. Start from one. Copy it, change the content, render it. A file marked as a template is a master and should not be posted unfilled.

Do not rebuild a template in a slide app. That is where off-size margins and the wrong weight of Bricolage Grotesque come from.

If you need a layout the templates do not cover, ask a designer. Do not stretch the stat card to hold a quote.

## Card types

**Stat card.** One number, a short line that says what it measures, and a source. Number in Bricolage Grotesque, very large. Use approved figures only, and keep the wording of an approved stat intact when you shorten it for a card. "7.4 hours" with "median time to contain a runtime incident" beneath it is fine. "Teams are failing at containment" is not what the number says.

**Quote card.** Customer quotes come from approved customers only. Use the quote as approved, without trimming it to sound stronger. Add the name, title and company as they were approved. Portraits are optional, and a portrait has its own consent requirements, separate from approval of the words. Founder quotes follow the same layout.

**Announcement card.** A short headline in sentence case on Tallow or Soot, plus the logo. For a release, name the capability and skip the excitement. "Wickhold Evenburn now shows exposure paths across clusters" is a good model. "Big news coming your way!" is the opposite.

**Event card.** Name, date, city. Slow Burn Summit and Field Day have a shared treatment, set with the events team each year.

## Layout

Each card has one Ember element, and on a card that element is usually a short rule beside the headline or the wick dot. The layout's text is never in Ember. Keep a clear margin all around, because platforms crop and round corners differently.

Logo placement is bottom right on Tallow and Soot cards.

Grounds: Tallow or Soot. Photos may be used in the right-hand half of the split layout, and text never overlaps a busy image. An abstract background from the library is allowed behind type, and it counts as the ground.

Keep the type large. Assume the card is viewed on a phone, in a feed, by someone with a thumb already moving. If you have reduced the font to fit the words, cut words.

## Copy on cards

Cards follow the voice rules with no special allowance for being short. Good:

- Small fires stay small.
- 11 minutes to contain, down from 4 hours.
- Contain mode, explained.

Bad:

- Hackers never sleep. Neither do we.
- The future of cloud security is HERE!
- Is your cluster on fire right now?

The 11-minute line needs Lowmoor named in the post or on the card, so that the number has a source.

A card should not repeat the post word for word. Use the post to expand on the card.

## Engineering posts

For posts aimed at platform engineers, a clean terminal or YAML snippet is often better than a designed card. Set it in IBM Plex Mono on a Soot ground, in a real, tested snippet of no more than twelve lines. Dry humor in a code comment is acceptable. Check the audience first.

```yaml
# drains the node. does not drain your weekend.
spec:
  action: drain-node
  mode: contain
```

Code cards still get checked by someone who can run them. This is a sample of the style, and its field names are not a reference.

## Common rejections

| What came in | What we said |
|---|---|
| Stat with no source anywhere | Add the source in the post or the card, or drop it |
| Ember headline on Tallow | Fails contrast. Use Soot, and keep Ember for the rule |
| Three stats on one card | Pick one. Post the others another day |
| Portrait, quote, logo and a screenshot together | Four focal points. Keep the quote |
| Card reused from before the rebrand | Rebuild it from the current template |
| Customer logo added to a stat card | Needs Legal first. Usually the answer is to name them in the post |

## Timing and thumbnails

Check every card at thumbnail size before you schedule it, and on a dark-theme feed as well as a light one. A Tallow card is a bright rectangle in a dark feed and that works in our favor. A Soot card can melt into the page, so keep its margin clean and its type large. Do not add a border to compensate.

## Series and carousels

We tried multi-slide carousels through Q1 and got poor completion on anything past the third slide, and each one ate a designer's afternoon. They are no longer part of the plan unless the social lead asks for one. Numbered series ("3 of 5") read as content for its own sake, so run a single good post instead.

## Sensitive moments

Check the news before a scheduled card goes out. A cheerful release card next to a public incident in our field looks careless. Hold it and ask. Illustrated flames and fire language are the first things to pull.

## Staff reshares

Staff may reshare cards as they are. Please ask them not to crop the logo or add filters. Sales teams sometimes make their own versions, and we would rather they ask. If you see a home-made card with an old logo or old colors, send it to Brand and leave the person alone. Usually they found an old file in a shared folder.

## Filing

Published cards are saved back to the library with a record. Set `restrictions` if a card carries a dated event or a time-limited statistic, so that nobody reuses it next year.
