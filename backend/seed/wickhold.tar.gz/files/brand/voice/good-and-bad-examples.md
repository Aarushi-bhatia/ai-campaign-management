# Good and bad examples

Running file. Most of the bad ones started as real drafts that came through #brand-review, reworded enough to spare the writer. Noor Eskelund keeps it; Kofi Anselm added the engineering pairs. Add to it when a review comment keeps repeating.

Last batch added September 2026, after the summit.

---

**Landing page hero**

BAD
> Attackers Never Sleep. Neither Should Your Security.
> Next-gen runtime protection that will stop all threats before the damage is done.

GOOD
> Contain the failure while it's still small
> Wickhold Quenchline runs as an eBPF agent on each node. When a pod misbehaves, it isolates the network, freezes the process or drains the node. Quenchline does not patch the image the problem came from. That part is still yours.
>
> Button: See contain mode

The bad version has a threat actor, a banned term, a promise no product can keep and Title Case. The good one says what the product does, then names something it doesn't.

---

**Product claim**

BAD
> Our incredibly lightweight, blazingly fast agent delivers industry-leading performance.

GOOD
> The Wickhold Quenchline agent runs at under 2% CPU overhead on a typical node in Wickhold lab benchmarks, 2026.

Three adjectives, no figure, no source. The good line has one figure and says where it was measured.

---

**Customer result**

BAD
> Ostler Grocers leveraged our platform to dramatically reduce misconfigurations by over sixty percent!

GOOD
> Ostler Grocers saw 63% fewer open critical misconfigurations in 90 days across 1,900 nodes.

"Over sixty percent" isn't the approved number and it's spelled out. Digits, the % symbol, the time period and the node count are what make the claim checkable. Then stop. No "dramatically".

---

**Company LinkedIn post, brand voice**

BAD
> I've been thinking a lot about runtime security lately. We think most teams are not ready. Are you?

GOOD
> The 2026 Wickhold Containment Report is out. It surveyed 412 platform and security leaders.
>
> 41% of platform teams need more than six hours to contain a runtime incident [Wickhold Containment Report, 2026, https://wickhold.example/containment-report].
>
> Read the report

The company page has no "I" and no "we think". The bad version also ends on a question, which reads as a nudge, and the good one gives a figure and gets out of the way.

---

**Founder LinkedIn post**

BAD
> Wickhold is thrilled to share some thoughts from our CEO on why containment matters!

GOOD
> My worst night on call was in 2017. A batch job filled a disk, the disk took out a database, and by morning four teams were on a bridge arguing over whose fault it was.
>
> The batch job was never the problem. It took 11 people and most of a night to notice that it was only a small failure, and by then it wasn't small.
>
> I still think about that bridge when customers ask me what Wickhold is for. I don't have a clever answer. I want the first failure to stay the first failure, so nobody has to find out what the second one would have been.
>
> — Maren

First person, one story, one point, signed. A founder post can have a feeling in it. Note the absence of any product pitch.

---

**X post**

BAD
> Is your runtime security keeping up?? Our cutting-edge platform has you covered. Find out more! #Kubernetes #Security #CloudNative

GOOD
> A drained node at 3am is an annoyance. An undrained one can be a very long week.
>
> Wickhold Quenchline drains on policy, and tells you it did.

The bad post opens with a rhetorical question. The good one makes one dry observation and stops. Quenchline gets its full name because this is the first mention in the post.

---

**Email subject and preheader**

BAD
> Subject: DON'T MISS OUT: The Must-Read Security Report Of The Year!!!
> Preheader: Hi there, we hope this finds you well.

GOOD
> Subject: The 2026 Containment Report is out
> Preheader: Median time to contain a runtime incident: 7.4 hours. Full data inside.

The good subject says what the email is. The preheader adds the number instead of repeating the subject.

---

**Blog intro**

BAD
> Have you ever wondered how long it takes to deal with a runtime incident? In today's fast-paced threat landscape, holistic security has never been more important.

GOOD
> The median time to contain a runtime incident is 7.4 hours [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]. This post follows one incident through its first hour, with the commands, and shows where the time went.

The good intro opens on a sourced fact and tells the reader what they'll get.

---

**Writing for a platform engineer** (Kofi)

BAD
> Our solution empowers your DevOps teams with seamless, policy-driven outcomes that unlock business value.

GOOD
> Start in observe mode. Nothing gets isolated, frozen or drained:
>
> ```bash
> helm upgrade quenchline wickhold/quenchline --set agent.mode=observe
> ```
>
> If a namespace floods you with findings, it's usually a sidecar doing something legal but odd. Tune that first. Going to contain mode with an untuned policy means finding out at 3am what your service mesh does for a living.

The last line of the good version is about as funny as we get.

---

**Writing for a CISO**

BAD
> Ever had to tell your board about a breach? Ha, neither do we, and with our platform you'll never need to.

GOOD
> The decision for this quarter is whether production namespaces move to contain mode under the default containment policy. The median time to contain a runtime incident is 7.4 hours [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]. Lowmoor Credit Union went from 4 hours to 11 minutes across 220 nodes. The remaining risk is that a containment action affects a healthy workload, and that risk is reviewable before you commit.

Nothing in the good version is trying to charm anyone.

---

**Leashgate copy**

BAD
> Leashgate makes AI agents totally safe and blocks every attack.

GOOD
> Wickhold Leashgate, in early access, sets runtime policy for AI agents and their tool calls. It limits what a compromised agent can do.

The second sentence is legal's wording, unchanged. Nothing involving agents is "safe" in the absolute.

---

**Our own bad day, customer notice**

BAD
> We are aware of an issue impacting a subset of users. Your security is our top priority, and we apologize for any inconvenience.

GOOD
> At 14:02 UTC a policy update we shipped drained nodes it should have left alone in three customer clusters. We rolled it back at 14:19 UTC. Your workloads rescheduled, and we've listed the affected nodes below. We're sorry. We don't yet know why the update passed review. Next update at 15:00 UTC.

The sample figures are made up for this page. The shape is the point: what happened, what's done, what's unknown, when you'll next hear from us. One apology.

---

**Error message**

BAD
> Oops! Something went wrong. Please try again later.

GOOD
> Policy not applied: `payments` has no default containment policy. Nothing changed. Assign one and retry.

---

**Release note**

BAD
> Exciting improvements to performance and stability across the board!

GOOD
> Wickhold Quenchline: fixed a bug where the agent restarted during a node drain on containerd nodes.

---

**Pricing**

BAD
> Starting at just $18 a node! Amazing value for teams of any size.

GOOD
> Core is $18 per node per month and includes Wickhold Quenchline. Team is $29 per node per month and adds Wickhold Evenburn. Both are billed annually, with a $24,000 annual minimum.

---

**Trust page**

BAD
> Fully compliant with everything. Your auditors will love us.

GOOD
> We renewed SOC 2 Type II in January 2026. Wickhold is pursuing FedRAMP Moderate authorization. Wickhold supports customers' GDPR obligations.

Three statuses, each in approved or checkable wording, none of them dressed up.

---

**Field Day invitation email** (full)

BAD
> Subject: You Won't Want To Miss This!
>
> Hi there! I'm so excited to invite you to an exclusive, unforgettable experience. Don't wait, seats are going fast!

GOOD
> Subject: Field Day is coming to your region
> Preheader: A few hours with other on-call teams and the engineers behind Wickhold Quenchline.
>
> Hi Sam,
>
> Field Day is a small customer meetup. There are no keynotes. Two Wickhold engineers walk through a real incident timeline, then the room compares notes on what happened at their own sites.
>
> Bring a runbook you don't trust. Kofi Anselm's team will go through Quenchline policies with anyone who wants to, and you can leave with a tuned policy for one namespace.
>
> Date and venue are on the invite page.
>
> Save your seat
>
> The Wickhold team

The invite says what will happen in the room. There's no "exclusive" and no pressure.

---

**Report summary paragraph**

BAD
> Our groundbreaking research reveals the shocking truth: teams are woefully unprepared, and time is running out.

GOOD
> The 2026 Wickhold Containment Report surveyed 412 platform and security leaders. The median time to contain a runtime incident is 7.4 hours, and 41% of platform teams need more than six hours to contain a runtime incident [Wickhold Containment Report, 2026, https://wickhold.example/containment-report].

Same report, same reader. The good one keeps the numbers and lets go of everything else, including the ticking clock.

---

**Words, one line each**

| Bad | Good |
|---|---|
| Protect every asset in your environment | Contain a failing workload in your cluster |
| Trusted by our valued clients | Trusted by more than 140 customers |
| We believe containment is the future | Containment is where the time goes |
| Forty-one percent of teams | 41% of platform teams |
| How To Read An Exposure Path | How to read an exposure path |
| See Wickhold evenburn | See Wickhold Evenburn |
| A robust, best-in-class posture tool | Wickhold Evenburn finds drift and sets a fix order |
