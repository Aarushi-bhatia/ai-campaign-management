# Wickhold voice and tone

Noor Eskelund, Head of Brand. Written for the February 2026 rebrand, rewritten in April after the Containment Report went out, last edited in June. Comments go to #brand-review in Slack.

## Start at 3am

Anyone who writes for Wickhold should read an incident channel before writing a line of copy. Kofi Anselm's team keeps a few scrubbed transcripts for new hires. Skip the panic at the top of the thread and find the messages from whoever is running the incident. They tend to look like this:

> 03:14 UTC. A pod in `checkout` started a shell it has no reason to start.
> 03:14 UTC. Wickhold Quenchline froze the process and isolated the pod's network.
> 03:22 UTC. Rest of the namespace is quiet. Still unknown how the shell got there.
> Reading the image history now. Next update 03:45.

That is the voice. It says what happened, what is contained and what is next, in that order, and it stops. It has timestamps where other writers have adjectives. It admits the thing it does not know in the same flat tone as the thing it does. The person writing it is tired and is not going to make their tiredness your problem. Forty people are reading, half of them frightened, and the frightened ones calm down because of how the message is written.

Maren Tolliver and Dov Achterberg were on-call infrastructure leads before they founded this company in Denver in 2019. The voice is theirs by inheritance. The 2026 brand made it official: a wick is the one place a fire is allowed to exist. Production will catch fire in small ways, on ordinary nights, for dull reasons. The mission is to keep small failures from becoming big ones, and the copy should sound like it was written by people who consider that a normal day's work.

## The character

Wickhold is someone who has been paged more often than you have and is not going to bring it up.

**Unhurried.** Nothing in our copy is urgent. A page that hurries the reader is using the same trick as the alert fatigue they came to us to get away from.

**Exact.** "Isolated the pod's network" beats "took action". "220 nodes" beats "at scale". If two engineers would argue over what a sentence means, it isn't finished.

**Unimpressed by itself.** The product is useful. Copy that gasps at it reads as though the writer has not seen it fail. We have seen it fail, and the release notes say so.

**On your side of the pager.** The reader is a peer on the same rota, and we write to them as someone who could take the next shift. No lecturing, no "did you know", no explaining Kubernetes to people who run it.

When the character slips, it usually slips into one of four people:

- **The hero.** Rushes in, saves the day, gets the credit. Early rebrand drafts leaned on firefighters and helmets until Maren pointed out that a firefighter arriving means it already went badly. The customer's on-call team is the competent party in every story we tell.
- **The prophet.** Sees doom everywhere and sells shelter from it. The whole security industry's default register, which makes it invisible to the people we want to reach.
- **The buddy.** "Hey there, Kubernetes friends." Nobody paged at 3am wants a pal.
- **The analyst.** "In today's rapidly evolving threat landscape." Sentences with no one in them. If nothing would change when the paragraph is deleted, delete it.

## What Wickhold believes

These are opinions and we expect some readers to disagree with them. Copy that could have come from any vendor in the category has failed, even if it breaks no rule.

### Fear is not a sales tool

No threat-actor drama. No ticking clocks.

The rule is simple to state and gets broken constantly, because fear copy is the easiest copy in security to write. It covers attackers portrayed as characters with motives and nicknames, anything of the "while you read this" kind, countdowns, "it's only a matter of time", "every second counts", and any sentence that asks the reader to imagine the phone call to the board. Our readers carry a pager. They do not need help imagining it.

Give the same fact without the dread.

Bad: "Attackers are already inside your cluster, and the clock is ticking."

Good: "41% of platform teams need more than six hours to contain a runtime incident [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]."

The second sentence is more uncomfortable than the first, and it did not raise its voice. Trust the number to do that work.

Breach references have their own rules in the claims document. Read them before you mention one.

### Containment is the whole argument

Something will get through. Every serious engineer already knows this, and the companies who claim otherwise are talking to someone else. Wickhold's position is that the useful question is how far a failure gets and how fast it stops spreading. The whole product line follows from that, and so does most of our vocabulary. If a draft reads as though nothing bad will ever happen to the customer, it's arguing for a different company.

### Say the number, then stop

Claims carry a figure and a source. No adjective stacks.

"Fast" is not a claim. "A fast, powerful, highly scalable runtime platform" is three non-claims in a row. Write the number, say where it came from, and end the sentence. The urge to add a second sentence explaining why the number is impressive is the urge to resist. A reader who needs that sentence is the wrong reader; a reader who doesn't will think less of us for it.

Bad: "Lowmoor Credit Union saw an incredible, game-changing reduction in response times."

Good: "Lowmoor Credit Union cut time to contain from 4 hours to 11 minutes across 220 nodes."

Bad: "Quenchline is extremely lightweight and blazingly quick."

Good: "Wickhold Quenchline contains a known-bad process in a median of 38 seconds in Wickhold lab benchmarks, 2026."

If there is no figure, there is usually no claim, and the honest move is to describe what the product does in plain mechanical terms. "Isolates a pod's network" needs no number and no source. It's a description. "Industry-leading isolation" needs both and has neither.

### Admit limits

One of the company values, and the one marketing finds hardest. Every product we sell has an edge. Wickhold Evenburn finds drift and exposure paths; it does not contain anything. Quenchline contains what is running; it does not patch the image it came from. Saying so costs a little in the moment and buys a lot of belief for the next claim on the page. Engineers look for the catch. When they find we already named it, they keep reading.

### Specifics outrank concepts

Nobody's bad night was ever improved by a concept. Where a sentence can hold a pod, a node, a policy or a flag, put one in. "Runtime visibility" is a concept. "Which process opened that socket, and when" is something a person wants to know.

## Founder voice and brand voice

There are two voices at Wickhold, and they have one hard line between them.

**Founder voice is first person singular, and it is signed.** Maren writes as "I". Her posts carry her name. She gets to have feelings and doubts, tell a story from a bad night in 2017, and be wrong in public. Dov's technical posts work the same way and are signed "Dov".

**Brand voice never says "I" or "we think".** Website, product pages, company LinkedIn, the company X account, email, decks, reports: no first person singular, ever. "We believe", "we feel" and "in our view" are "we think" in different shoes, and they go too.

**Brand voice uses "Wickhold" or "we" for facts only.** Things that happened, things that are true of the company, things a lawyer could check.

| Fine in brand voice | Not in brand voice |
|---|---|
| We renewed SOC 2 Type II in January 2026. | We think SOC 2 matters. |
| Wickhold serves more than 140 customers. | I've talked to a lot of platform teams. |
| Containment is where incidents are won or lost. | We believe containment is where incidents are won or lost. |

The third row is the useful one. Brand voice still holds opinions. It states them as flat sentences, the way the on-call lead does, and lets the reader disagree. "We think" adds nothing except a hedge.

Practicalities. Nobody else writes as "I" in Wickhold content. Kofi's developer posts and anything from the wider team run in brand voice under a byline, because a byline is credit and a founder post is a person speaking for themselves. Customer quotes are quotes and say whatever was approved. If the content team drafts for Maren, she reads it and changes it before her name goes on, and a post that she has not read does not go out. In the spring a joint Maren-and-Dov byline was tried on one post; "I" became unreadable after two paragraphs, so that was dropped. One author per post.

## Tone by channel

The voice stays the same. How much of it you get changes with the room.

**Landing pages.** The flattest we get. Mechanical, confident, short. The reader is deciding whether to spend ten more minutes, so tell them what the thing does on a cluster and let them go. "Wickhold Quenchline isolates the pod, freezes the process or drains the node, then writes down what it did."

**Blog.** The most room to think. Brand-voice posts walk through how something fails. Dov's posts can argue, and they should. A good post leaves the reader able to do one thing they could not do before, even if they never buy. Avoid the summary paragraph at the end. If the post worked, the reader was there.

**LinkedIn.** The company page is brand voice. Founder posts are where the personality lives. A post runs about 200 words, which suits one story and one point. Write as a person with a job, not a thought leader: no line breaks after every sentence, no "here's what I learned", no lists of lessons from an outage.

**X.** One fact, or one observation, in a dry tone. The account does not chase the news and does not reply to arguments about vendors. It's fine for a post to be plain. "The median time to contain a runtime incident is 7.4 hours [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]. That is most of a night shift."

**Email.** One person writing to one person who is busy. Say why you are writing in the first sentence. Assume it is being read on a phone in a hallway. No "I hope this finds you well", and since these are brand emails, no "I" at all unless Maren signed it. Customer notices are the exception to everything else in this list and sound like the incident channel at the top of this document.

**Product UI and error text.** The closest thing we have to pure voice. What happened, what state things are in, what to do. "Containment action failed on node `ip-10-2-14-7`: agent unreachable. The pod is still running. Retry or drain the node." Chirpy empty states were tried in 2025 and came out after a customer saw one during a real incident.

**Case studies.** Third person, numbers up front, the customer's team as the subject of most sentences. Enough detail about their environment that a peer recognizes it. A case study that could describe any customer describes none of them.

**The Containment Report.** Annual, every April, and the most formal thing we publish. It reads like a clinical note: findings in flat declaratives, method stated early, no pitch in the body. The product can appear at the end, briefly, once the reader has had what they came for.

**Release notes.** Past tense, specific, no selling. A bug we fixed is described as a bug.

**Press.** Third person, plain, one idea per release. The quote from Maren is the only place with any warmth, and she writes it herself.

**Sales decks and talk tracks.** Same facts, same claims, slightly warmer because a person is in the room. If a slide would embarrass the on-call lead, it comes out.

**Webinars and video.** Script it as speech, then cut a third. Two people talking through a real incident timeline beats one person reading slides. No stock intro music with a heartbeat in it, and no voiceover that sounds like a trailer.

**Support replies.** These are written by the support team and we don't police them, but the same habit applies: repeat what you saw, say what you did, say what happens next. A reply that begins by thanking the customer for their patience has already lost them.

**Events.** Slow Burn Summit in Denver is the one place where we are among friends, and it can sound like that. The stage voice is relaxed and first-name, and the facts on the slides are still the facts. Field Day is smaller and closer to a conversation in a car park. Booth copy is brand voice: short, mechanical, no shouting.

## Tone by audience

Humor depends on the audience, see each persona.

The personas hold the working rules for each reader, including what goes first. What follows is only the register, meaning how the voice sounds once you have chosen your content.

**CISOs.** Level and measured. Assume the reader will forward your paragraph to an audit committee without editing it, and write something they can forward. Risk, time and board language are their native terms: exposure, time to contain, residual risk, ownership. Short sentences, complete ones, no shorthand. Every sentence should survive being read aloud in a room that includes a lawyer.

**Platform engineers.** A good pull-request comment from a colleague you respect. Exact, brief, assumes competence, and shows its working. If there is a YAML snippet that makes the point, the prose can get out of its way. Marketing English reads as noise here and the page will be closed.

**DevSecOps.** These readers sit between the review queue and the pipeline, and they spend their days being the person who says no. Write to someone who is outnumbered: practical, on their side, and specific about what lands in their queue and what stays out of it.

**Compliance leads.** Careful nouns. This reader will notice the difference between "supports" and "meets", and will quote you. Their persona is still being written, so if the piece is aimed mainly at them, ask Noor before guessing.

**Customers mid-incident.** Pure 3am voice. Nothing about the product, nothing about the relationship, no reassurance that isn't backed by a fact. What we see, what we've done, when the next update comes.

**Finance and procurement.** They read a small part of what we write and they read it closely. Plain sentences, the price in the standard form, the terms where they expect them. Anything that sounds like enthusiasm reads to them as a negotiating position.

**Journalists.** Assume no interest in the product and real interest in what is happening to teams. Offer the finding, the method and a person to talk to. Don't send them a story with a hook in it; they have their own.

**Candidates and the community.** Warmer, plainer, and allowed to mention that the work is interesting. The same no-drama rules hold. Nobody here is a rockstar.

## When the news is ours

We will have our own bad days: a bad agent release, a late fix, a false containment that drained a node it should have left alone. The values cover this before anything else does. Say what happened. Contain first. Admit limits. Leave it better for the next on-call.

In practice:

- Lead with what happened to the customer's systems, in their terms.
- Use "we" and an active verb. "We shipped a policy update that drained nodes it should not have." "An issue occurred" is not a sentence we publish.
- Apologize once, plainly, in one short sentence. Then get on with the facts.
- Say what is still unknown.
- Say when the next update comes, and hit that time even if there's nothing new.

Dov signs off anything technical. Priit Salonen reads anything that touches a contract. Nobody in marketing edits the facts for tone.

## One fact, three rooms

The same pair of numbers, set for three readers. The facts stay fixed and the weight moves.

On a landing page, where the reader is deciding whether to keep going:

> The median time to contain a runtime incident is 7.4 hours [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]. Wickhold Quenchline contains a known-bad process in a median of 38 seconds in Wickhold lab benchmarks, 2026.

In a note to a CISO, where the number has to fit a conversation about risk:

> The median time to contain a runtime incident is 7.4 hours [Wickhold Containment Report, 2026, https://wickhold.example/containment-report]. Your team's own figure is the one to bring to the risk committee.

In a post for platform engineers, where the first response to a lab figure is suspicion:

> Wickhold Quenchline contains a known-bad process in a median of 38 seconds in Wickhold lab benchmarks, 2026. Your cluster is not our lab. Run it in observe mode and read what it would have done.

None of the three is more honest than the others. Each one hands the reader the number in the form they can use.

## Subjects that pull the voice off course

Some topics drag writers back toward the register the rebrand left behind. These are the ones reviewers see most.

**AI agents.** Wickhold Leashgate, in early access, attracts the worst habits in the building, because the whole market is shouting about agents. Treat an agent as a workload with credentials and questionable judgment. Talk about tool calls, agent identity and the blast radius of an agent. Leave the future of work to other people. Anyone who has run production will recognize the problem from there, and that recognition is worth more than any amount of excitement.

**Compliance.** Dull on purpose. Certification status is a fact with one correct wording, and legal owns that wording. Copy the approved sentence and do not improve it. A nicer phrasing here is how a company ends up saying something untrue.

**Money.** Prices are stated flatly, with no "just", "only" or "starting from". Core is $18 per node per month. The reader can decide how they feel about that.

**Company news.** Funding, awards, headcount. Nobody is thrilled, excited or proud. The Series B was $46M in June 2024; that is a date and a number, and the sentence after it should say what changed for customers. If nothing changed for customers, ask whether the post needs to exist.

**Customers.** They did the work. Lowmoor Credit Union's on-call team runs its own incidents, and the product took one job off their list. Avoid "partnered with", "journey" and anything that casts us as the guide who showed them the way.

**Other approaches.** The voice doesn't sneer. Other kinds of product make real trade-offs, and a colleague would describe them as trade-offs: a heavier agent can see more and costs more on the node. Readers respect the writer who can state the other side accurately. Reviewers will cut anything that sounds like a playground.

**Open source.** Kubernetes, eBPF and Helm were here before us. We are users and we say so. Credit the projects, don't imply we invented the kernel feature, and don't describe a community as an "ecosystem we're proud to be part of".

## How the sentences go

**Short first.** Most sentences run under twenty words. The long ones earn it by carrying a real sequence of events.

**Verbs do the work.** Name who did what. "Quenchline froze the process" over "the process was frozen". Past tense for incidents, present tense for what the product does.

**End early.** Our most common edit is deleting the last line of a paragraph. Writers tend to add one that restates the point in a nicer rhythm. Readers don't need it. This goes double for the final line of a piece.

**Ration the fire.** The tagline is "Small fires stay small." It carries the metaphor so the copy doesn't have to. A piece gets at most one fire image, and many pieces should have none. Nothing ignites, sparks, blazes or fans the flames. Slow Burn Summit gets to keep its name.

**Plain words for plain things.** "Use", "start", "stop", "run". Reach for the fancier word and the reader assumes something is being hidden.

**Don't argue with the reader's experience.** Telling a platform engineer that alerts are overwhelming is telling them what they had for breakfast. Start from what they know and add something.

## What sounds like us

| Sounds like Wickhold | Doesn't |
|---|---|
| Here is what happened. | We're reaching out to share an important update. |
| We don't know yet. | We are actively investigating. |
| That part is still yours. | We've got you covered. |
| Start in observe mode. | Begin your containment journey. |
| It took 11 minutes. | In record time. |
| It's a trade-off. | No compromises. |
| The pod is still running. | Your environment remains protected. |

## One rewrite, start to finish

A draft that came through in May, lightly disguised:

> We're excited to announce that we think our powerful new drift capabilities will transform how modern teams approach cloud risk, giving you the confidence you need in an increasingly dangerous world.

The edit went like this.

"We're excited to announce" went first. The reader's interest in our excitement is zero.

"We think" is out, because this is brand voice.

"Powerful", "new" and "modern" were doing nothing. Remove them and the sentence gets more honest and no less informative.

"Increasingly dangerous world" is the fear habit, and it also isn't something we can source.

That left "drift capabilities will transform how teams approach cloud risk", which on inspection means nothing. So the reviewer asked the only useful question: what does a person see on the screen? The product manager's answer became the copy.

> Wickhold Evenburn lists the drift in a cluster and ranks it by exposure path, so the fix order is on one page. It does not contain anything at runtime.

That is shorter, it can be checked, and it names an edge. Nobody involved felt that it was a loss.

## Reading old copy

Pre-2026 material is everywhere: the archive, old decks, the sales team's memory. It sounds different for a reason. The old brand sold watching. It leaned on "always", "every" and "complete", and it got excited in public. A lot of it is competent copy for a company we no longer are.

If you are reusing something from before the rebrand, do not patch the sentences. Take the facts, check that they are still approved, and write it again. Look for these symptoms when reading a draft that someone has recycled: a promise of total coverage, a sentence about seeing with nothing about what happens next, and an excited tone that doesn't match the numbers beside it.

## Tried and dropped

The rebrand ran through a lot of ideas. Recording them saves the next person some time.

- **"3am" as a campaign.** A homepage concept with a live clock counting down to the next page. Striking, and a ticking clock in the literal sense. The 3am idea stayed in this document, which is where it belongs: it's how we write, and readers don't need to be told about it.
- **"Calm" as a stated brand value.** Writing "we stay calm" is not calm.
- **A brand mascot.** A small candle character reached one round of sketches. No one who has been on call wanted it near them.
- **First-person customer stories written as diaries.** Moving, and impossible to get approved. Case studies are third person with numbers.

## Before you send it for review

Read it out loud as a handover to the next on-call. If you stumble, or feel you are selling to a colleague, rewrite that part.

Then a few checks that catch most problems:

- Can a stranger tell what happened, what is contained and what is next?
- Does each claim have a figure and a source, or is it a plain description of what the product does?
- Is there an "I" or "we think" outside a signed founder piece?
- Does anything rely on the reader being scared?
- What's the last line doing there?

Copy review goes through #brand-review, and Noor or one of the brand team turns it around in two working days. Claims go to Priit Salonen's team and take the time the approved claims set. If a deadline leans on either of those, say so early.
