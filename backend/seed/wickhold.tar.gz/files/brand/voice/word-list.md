# Word list

Everything here applies to anything a customer, prospect, journalist or candidate can read. Slack can say what it likes.

## Banned terms

There are thirteen. They stay out of headlines, body copy, decks, alt text and speaker notes that leave the building. When one shows up in a draft it usually marks the spot where the writer ran out of facts, so deleting it rarely fixes the sentence. Find the fact.

| Term | Why it is out | What to do instead |
|---|---|---|
| seamless | Putting an eBPF agent on every node has seams: a kernel check, a Helm upgrade, a stretch in observe mode. Platform engineers know this and stop reading when told otherwise. | Say what the rollout takes. |
| robust | Strong against what? The word claims a result and skips the test. | Name the failure the thing survived. |
| leverage | A finance word doing a job that "use" does for free. | Use "use". |
| best-in-class | No class, no judge, no source. It cannot pass "say the number, then stop". | Give the figure and where it came from. |
| next-gen | Every product in this market has been next-gen at some point. The word ages the day it ships. | Say what it does on a node today. |
| single pane of glass | Our readers have been sold this pane many times and own several. It also describes watching, and the job here is containing. | Name the screen and what it shows. |
| holistic | Usually covering for a gap. If something spans cloud and cluster, those two words are shorter and checkable. | List what is covered. |
| unlock | Implies the customer's own work was locked up and we hold the key. Drags padlocks into the room as well. | Say what the reader can now do. |
| empower | The readers already have root. Nobody here hands out power. | Say what changed for them, in a verb they would use. |
| cutting-edge | A claim about us, and an undated one. eBPF is well past being new, and that is one reason it is safe to run in production. | Name the technique. |
| game-changing | An incident is nobody's game, and the claim has no number attached. | Give the before and after. |
| prevent all | A promise no security product can keep. Includes "prevents all", which is the same promise with better grammar. | See the verbs below. |
| stop all | Same promise, same problem. A CISO who reads this line once will discount the rest of the page. | See the verbs below. |

The prose test: if a sentence still reads as true after you swap the product for a toaster, it needed a fact and got an adjective.

## Preferred terms

**Workload, not asset.** Customers run workloads, and that is the word they use in their own runbooks. "Asset" comes from inventory spreadsheets and suggests a thing that sits still. A workload moves, restarts and misbehaves, which is why it needs a runtime product. Inside the marketing team "asset" still means a blog post or an image file; that use never reaches a customer.

**Contain, limit and slow, rather than prevent.** This is the company's argument in three verbs. Something will go wrong on a Tuesday night regardless of what anyone buys. Wickhold Quenchline contains what is already running. Wickhold Evenburn limits exposure. Wickhold Leashgate limits what an agent can reach. "Slow" is the honest verb when the action buys time and does not end the problem. Also keep "eliminate" and "eradicate" out of it; they are "prevent" in a bigger coat.

Use "contain" only when a containment action actually happens. Detection on its own is detection.

One exception came out of a release-notes review. A line saying a patch prevents a crash in the agent is describing our own bug, so it can stay. The rule covers promises about what happens to customers, and a changelog entry makes none.

**Customers, not clients.** Clients have an account manager and a lunch. Customers run our agent in production and page us. A "client" in the software sense stays: `kubectl` is a client, an email client is a client. "Users" is fine when you mean the people logged in to the console, because a customer is the whole company.

## Not banned, but expect a comment

Reviewers will ask about these. Sometimes the word survives.

- **solution.** Name the product, or say what it does. The word exists to avoid doing either.
- **visibility.** Seeing isn't the job. If the sentence ends at seeing, ask what happens next.
- **real-time.** Fine with a number next to it. Without one it means nothing.
- **AI-powered.** Tells the reader how something was built and nothing about what it does.
- **comprehensive.** Usually untrue, and a reader will go looking for the gap.
- **threat landscape.** A landscape has no one in it. Say which failure you mean.
- **peace of mind.** Nobody on a rota has ever had this.
- **modern.** Compared with what? Say which setup you mean.
- **mission-critical.** To the person on call, everything is.

## Off the list

- **"Platform".** On the first draft in January, then removed. Half our readers are platform engineers.
- **"Blast radius".** Someone proposed banning it as fear language. It stays, because engineers use it flatly and "blast radius of an agent" is how Leashgate work gets scoped.
- **A Slack bot that flagged banned terms.** Tried for a month in the spring. It flagged `client` in every Kubernetes snippet and nobody read its messages after the first week. Removed. Reviewers catch these now.

To add or remove a term, make the case in #brand-review with a real sentence from a real draft. Kofi Anselm's team has a veto on anything engineers actually say.

Noor Eskelund, May 2026
